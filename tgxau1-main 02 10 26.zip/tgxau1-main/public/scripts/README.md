# GoldCopier Pro — VPS Bridge (super simple)

Two Python scripts run on your Windows VPS and connect your Telegram + MT5 to the web app. **You don't need to edit any code or `.env` file** — your Telegram and MT5 credentials live in the web app and the scripts read them live.

---

## What to download

Download **`goldcopier-vps.zip`** from the app, then right-click it and choose **Extract All**.

Open the extracted folder and double-click **`1_START_HERE.bat`**. That is the only file you need to click.

The ZIP contains:

| File | What it does |
|------|--------------|
| `telegram_listener.py` | Watches your chosen Telegram channels |
| `mt5_bridge.py`        | Talks to MetaTrader 5 and places trades |
| `cloud_client.py`      | Small helper used by both scripts |
| `requirements.txt`     | List of Python libraries to install |
| `.env`                 | Pre-filled cloud connection — don't change |
| `1_START_HERE.bat`     | One-click launcher (click this first) |

Keep **all extracted files in the same folder**, e.g. `C:\GoldCopier\`.

---

## 1) Install Python (one-time, 2 min)

1. Download Python 3.10+ from <https://python.org>
2. **IMPORTANT:** tick the box **"Add Python to PATH"** on the first screen
3. Click *Install*

## 2) Install MetaTrader 5 (one-time)

Install your broker's MT5 terminal and **log in** with your trading account. It must be running for the bridge to trade.

## 3) Start everything (one-click)

Double-click **`1_START_HERE.bat`**.

- The first run installs the Python libraries automatically (1–2 min, only once).
- Two black windows open: *Telegram Listener* and *MT5 Bridge*. Keep them open. They show live logs.
- The Telegram window will ask for your phone + SMS code the **first time for each Telegram account**. After that it remembers that account.

## 4) Done

Go back to the web app. Within ~15 seconds you'll see the **TG** and **MT5** dots turn green in the top bar. The Setup wizard's "Test" step will pass.

Whenever you change Telegram/MT5 credentials in the app, the scripts pick them up automatically — no editing files. Telegram refresh replaces old-account channels, selected channels update within a few seconds, and MT5 reconnects when account details change.

---

## Run 24/7 (optional)

To survive VPS reboots:
- Open **Task Scheduler** → Create Task → Trigger: *At log on* → Action: run `C:\GoldCopier\1_START_HERE.bat`

## Troubleshooting

- **MetaTrader5 install error?** Download the latest ZIP again. The old bundle pinned `MetaTrader5==5.0.45`; the fixed bundle uses a current version that supports Python 3.14.
- **Window closes instantly?** `1_START_HERE.bat` keeps it open and shows the error. Read the last red line — usually it's "MT5 not initialized" (open MT5 and log in) or "credentials missing in settings" (fill them in the web app's Setup screen).
- **`python` not found?** Reinstall Python and tick *Add Python to PATH*.
- **TG/MT5 dot stays red?** The script isn't running, or the VPS lost internet. Check the black window.
- **Signal fetched but no trade opened?** The MT5 Bridge window now prints the broker's exact rejection code and the app marks the queued action as failed instead of hiding it. Common causes: market closed, symbol name differs from `XAUUSD`, invalid SL/TP distance, trading disabled, or broker fill mode rejection.

## Security

The cloud URL + key in `.env` are public — they only let your scripts reach the database, which is locked down by access rules. Your MT5 password and Telegram api_hash live **only on your VPS** and **in the cloud settings table tied to your account**.
