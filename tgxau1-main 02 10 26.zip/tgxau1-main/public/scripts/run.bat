@echo off
setlocal EnableExtensions EnableDelayedExpansion
title GoldCopier Pro - START HERE
cd /d "%~dp0"

echo ============================================================
echo GoldCopier Pro VPS Bridge - One Click Start
echo ============================================================
echo.

for %%F in (bootstrap.py telegram_listener.py mt5_bridge.py start_bridges.py cloud_client.py requirements.txt) do (
  if not exist "%%F" goto missing_files
)
if not exist ".env" if exist ".env.example" copy /Y ".env.example" ".env" >nul

REM [1/5] Find a Python that MetaTrader5 supports (3.10 - 3.13).
echo [1/5] Checking Python...
set "PYTHON_EXE="
for %%V in (3.13 3.12 3.11 3.10) do (
  if not defined PYTHON_EXE (
    for /f "usebackq delims=" %%P in (`py -%%V -c "import sys; print(sys.executable)" 2^>nul`) do set "PYTHON_EXE=%%P"
  )
)
if not defined PYTHON_EXE (
  for /f "usebackq delims=" %%P in (`python -c "import sys; print(sys.executable if (3,10) <= sys.version_info < (3,14) else '')" 2^>nul`) do set "PYTHON_EXE=%%P"
)
if not defined PYTHON_EXE goto no_python
echo Using: "%PYTHON_EXE%"
"%PYTHON_EXE%" --version
echo.

REM [2/5] Install / verify libraries into that SAME Python.
echo [2/5] Installing / verifying required libraries...
"%PYTHON_EXE%" -m ensurepip --upgrade >nul 2>nul
"%PYTHON_EXE%" -m pip install --upgrade pip >nul 2>nul
"%PYTHON_EXE%" -m pip install --upgrade --prefer-binary -r requirements.txt
if errorlevel 1 goto install_failed
"%PYTHON_EXE%" -c "import telethon, MetaTrader5, dotenv, requests; print('All required libraries are ready.')"
if errorlevel 1 goto install_failed
echo.

REM [3/5] + [4/5] Load .env and verify the cloud connection.
echo [3/5] Loading configuration and [4/5] connecting to the cloud...
"%PYTHON_EXE%" bootstrap.py --check
if errorlevel 1 goto cloud_failed
echo.

REM [5/5] Start services. Windows stay open (cmd /k) so errors remain visible.
echo [5/5] Starting Telegram Listener and MT5 Bridge(s)...
start "GoldCopier Telegram Listener" cmd /k ""%PYTHON_EXE%" telegram_listener.py"
timeout /t 2 /nobreak >nul
"%PYTHON_EXE%" start_bridges.py
if errorlevel 1 goto bridges_failed

echo.
echo All services were started. Keep the new black windows open.
echo Return to the web app and wait about 15 seconds for TG and MT5 to turn green.
echo.
pause
exit /b 0

:missing_files
echo ERROR: Some VPS files are missing.
echo Download the latest VPS ZIP from Settings, extract ALL files into one folder,
echo then double-click 1_START_HERE.bat from that folder.
pause
exit /b 1

:no_python
echo ERROR: No supported Python found (needs 3.10, 3.11, 3.12 or 3.13).
echo Python 3.14 does NOT work yet: MetaTrader5 has no build for it.
echo Install Python 3.13 from python.org, tick "Add python.exe to PATH", then run this file again.
pause
exit /b 1

:install_failed
echo.
echo ERROR: Python library installation failed. Check the VPS internet connection,
echo then run 1_START_HERE.bat again.
pause
exit /b 1

:cloud_failed
echo.
echo ERROR: Could not connect to the GoldCopier cloud (see message above).
pause
exit /b 1

:bridges_failed
echo.
echo ERROR: Starting the MT5 bridge(s) failed (see message above).
pause
exit /b 1
