@echo off
REM This is just a friendly alias for run.bat. They do exactly the same thing.
cd /d "%~dp0"
if not exist ".env" (
  if exist ".env.example" copy /Y ".env.example" ".env" >nul
)
call "%~dp0run.bat"
exit /b %errorlevel%
