"""
GoldCopier Pro — Telegram Listener
Watches selected channels for new messages, forwards each one to the
web app's AI parser endpoint, and keeps the channel list / heartbeat
in sync with Supabase.

Run on your Windows VPS:  python telegram_listener.py
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import sys
import time
from typing import Optional

import bootstrap  # checks Python, auto-installs libraries, loads .env, verifies cloud

bootstrap.setup(["requests", "telethon"])

import requests
from cloud_client import CloudClient, create_cloud_client
from telethon import TelegramClient, events
from telethon.tl.types import Channel, Chat

# ---------- Config ----------
CLOUD_URL = (os.environ.get("CLOUD_URL") or os.environ.get("SUPABASE_URL", "")).strip()
CLOUD_KEY = (os.environ.get("CLOUD_KEY") or os.environ.get("SUPABASE_KEY", "")).strip()
APP_URL = os.environ.get("APP_URL", "").strip().rstrip("/")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [TG] %(levelname)s %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("telegram")

if not CLOUD_URL or not CLOUD_KEY:
    log.error("Missing CLOUD_URL / CLOUD_KEY in .env. Re-download the VPS bundle from Settings and extract all files into one folder.")
    input("Press Enter to exit...")
    sys.exit(1)

sb: CloudClient = create_cloud_client(CLOUD_URL, CLOUD_KEY)

# chat_id -> display name, so the message handler never needs a Telegram round-trip.
CHANNEL_NAMES: dict[str, str] = {}


def get_settings() -> dict:
    res = sb.table("settings").select("*").eq("id", 1).single().execute()
    return res.data or {}


def normalize_chat_id(value) -> str:
    """Telethon events can use -100... ids while dialogs use plain positive ids."""
    raw = str(value or "").strip()
    if raw.startswith("-100") and len(raw) > 4:
        return raw[4:]
    if raw.startswith("-"):
        return raw[1:]
    return raw


def session_name(api_id, phone) -> str:
    safe = re.sub(r"[^0-9A-Za-z_-]+", "_", str(phone or "telegram")).strip("_")
    return f"telegram_{api_id}_{safe}.session"


def settings_signature(settings: dict) -> tuple[str, str, str]:
    return (
        str(settings.get("telegram_api_id") or ""),
        str(settings.get("telegram_api_hash") or ""),
        str(settings.get("telegram_phone") or ""),
    )


def heartbeat(status: str = "online", meta: Optional[dict] = None) -> None:
    try:
        sb.table("bridge_heartbeat").upsert({
            "service": "telegram",
            "status": status,
            "last_seen": "now()",
            "meta": meta or {},
        }, on_conflict="service").execute()
    except Exception as e:
        log.warning("heartbeat failed: %s", e)


# Pooled, keep-alive session: avoids a fresh TLS handshake per signal
# (~100-200 ms saved on every message).
_INGEST = requests.Session()
_INGEST.mount("https://", requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0))
_INGEST.mount("http://", requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=8, max_retries=0))
_INGEST.headers.update({"Content-Type": "application/json", "Connection": "keep-alive"})


def warm_ingest_connection() -> None:
    """Open the TLS connection at startup so the first real signal is fast."""
    try:
        _INGEST.get(f"{APP_URL}/api/public/ingest-message", timeout=(3, 5))
    except Exception:
        pass


def post_message(text: str, channel_id: str, channel_name: str, received_at: float) -> None:
    """Forward a Telegram message to the web app's signal parser."""
    try:
        r = _INGEST.post(
            f"{APP_URL}/api/public/ingest-message",
            json={"text": text, "channel_id": channel_id, "channel_name": channel_name},
            timeout=(3, 20),
        )
        elapsed_ms = (time.perf_counter() - received_at) * 1000
        if r.status_code >= 400:
            log.error("ingest failed %s in %.0fms: %s", r.status_code, elapsed_ms, r.text[:200])
        else:
            body = r.json() or {}
            log.info("ingested in %.0fms (queued=%s, parser=%s)",
                     elapsed_ms, body.get("queued"), body.get("parser"))
    except Exception as e:
        log.exception("ingest exception: %s", e)


async def refresh_channels(client: TelegramClient) -> int:
    """Replace the cloud channel list with the current Telegram account's dialogs."""
    selected = set()
    try:
        old = sb.table("channels").select("id").eq("is_selected", True).execute()
        selected = {normalize_chat_id(x["id"]) for x in (old.data or [])}
    except Exception as e:
        log.warning("could not read previous selected channels: %s", e)

    rows = []
    async for dialog in client.iter_dialogs():
        ent = dialog.entity
        if isinstance(ent, (Channel, Chat)):
            channel_id = normalize_chat_id(ent.id)
            rows.append({
                "id": channel_id,
                "name": getattr(ent, "title", None) or getattr(ent, "username", "Unknown"),
                "username": getattr(ent, "username", None),
                "is_selected": channel_id in selected,
                "last_message": (dialog.message.message[:300] if dialog.message and dialog.message.message else None),
                "last_message_at": dialog.message.date.isoformat() if dialog.message else None,
            })
    sb.table("channels").delete().neq("id", "__keep_none__").execute()
    if rows:
        sb.table("channels").upsert(rows, on_conflict="id").execute()
    log.info("refreshed %d channels", len(rows))
    return len(rows)


async def consume_pending_actions(client: TelegramClient) -> None:
    """Background task: react to actions queued by the web UI (e.g. refresh channels)."""
    while True:
        try:
            res = sb.table("pending_actions").select("*").eq("status", "pending").eq("action", "fetch_channels").execute()
            for row in (res.data or []):
                sb.table("pending_actions").update({"status": "processing"}).eq("id", row["id"]).execute()
                try:
                    n = await refresh_channels(client)
                    sb.table("pending_actions").update({"status": "done", "result": {"channels": n}, "processed_at": "now()"}).eq("id", row["id"]).execute()
                except Exception as e:
                    sb.table("pending_actions").update({"status": "failed", "error": str(e), "processed_at": "now()"}).eq("id", row["id"]).execute()
        except Exception as e:
            log.warning("pending poll: %s", e)
        await asyncio.sleep(3)


async def heartbeat_loop() -> None:
    while True:
        heartbeat("online")
        # Re-assert the connection flag so the Settings page stays accurate.
        try:
            sb.table("settings").update({"telegram_connected": True}).eq("id", 1).execute()
        except Exception:
            pass
        await asyncio.sleep(15)



async def main() -> None:
    # Wait until the user fills Telegram credentials in the web app.
    while True:
        try:
            settings = get_settings()
        except Exception as e:
            log.warning("can't read settings yet (%s). Retrying in 15s…", e)
            heartbeat("offline", {"reason": "settings_unreachable"})
            await asyncio.sleep(15)
            continue
        api_id = settings.get("telegram_api_id")
        api_hash = settings.get("telegram_api_hash")
        phone = settings.get("telegram_phone")
        if api_id and api_hash and phone:
            break
        log.warning("Telegram credentials missing in the web app. Open Setup → Telegram and fill api_id / api_hash / phone. Re-checking every 15s…")
        heartbeat("offline", {"reason": "no_credentials"})
        await asyncio.sleep(15)

    client = TelegramClient(session_name(api_id, phone), int(api_id), api_hash)
    await client.start(phone=phone)
    log.info("Telegram connected as %s", phone)
    sb.table("settings").update({"telegram_connected": True}).eq("id", 1).execute()

    # Initial channel sync
    try:
        await refresh_channels(client)
    except Exception as e:
        log.warning("initial channel refresh failed: %s", e)

    # Warm the HTTPS connection to the app so the first signal isn't slowed
    # down by a TLS handshake.
    await asyncio.to_thread(warm_ingest_connection)

    # Determine which channels to monitor (and cache their display names)
    def selected_ids() -> set[str]:
        try:
            r = sb.table("channels").select("id,name").eq("is_selected", True).execute()
            ids = set()
            for x in (r.data or []):
                cid = normalize_chat_id(x["id"])
                ids.add(cid)
                if x.get("name"):
                    CHANNEL_NAMES[cid] = x["name"]
            return ids
        except Exception as e:
            log.warning("selected fetch: %s", e)
            return set()

    monitored: set[str] = selected_ids()
    log.info("monitoring %d channels: %s", len(monitored), monitored)

    @client.on(events.NewMessage())
    async def handler(event):
        received_at = time.perf_counter()
        chat_id = normalize_chat_id(event.chat_id)
        if chat_id not in monitored:
            return
        text = (event.message.message or "").strip()
        if not text:
            return
        # Name comes from the cached channel list — calling event.get_chat()
        # here costs a Telegram round-trip before we can even start parsing.
        name = CHANNEL_NAMES.get(chat_id) or "Unknown"
        log.info("new msg from %s: %s", name, text[:120].replace("\n", " "))
        # Fire-and-forget so back-to-back signals never queue behind each other.
        asyncio.create_task(asyncio.to_thread(post_message, text, chat_id, name, received_at))

    # Periodically refresh which channels are selected (poll cheap)
    async def refresh_selection_loop():
        nonlocal monitored
        while True:
            await asyncio.sleep(3)
            new = selected_ids()
            if new != monitored:
                log.info("monitored channels changed: %s", new)
                monitored = new

    async def monitor_credentials_loop(active_client: TelegramClient, initial_signature: tuple[str, str, str]):
        active_signature = initial_signature
        while True:
            await asyncio.sleep(10)
            try:
                latest = get_settings()
                latest_signature = settings_signature(latest)
                if latest_signature != active_signature and all(latest_signature):
                    log.info("Telegram credentials changed in the app. Restarting listener with the new account...")
                    sb.table("settings").update({"telegram_connected": False}).eq("id", 1).execute()
                    await active_client.disconnect()
                    return
            except Exception as e:
                log.warning("credential monitor failed: %s", e)

    tasks = [
        asyncio.create_task(heartbeat_loop()),
        asyncio.create_task(consume_pending_actions(client)),
        asyncio.create_task(refresh_selection_loop()),
        asyncio.create_task(monitor_credentials_loop(client, settings_signature(settings))),
        asyncio.create_task(client.run_until_disconnected()),
    ]
    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    for task in pending:
        task.cancel()
    for task in done:
        task.result()


if __name__ == "__main__":
    try:
        while True:
            asyncio.run(main())
            log.info("listener restarting in 3s...")
            time.sleep(3)
    except KeyboardInterrupt:
        heartbeat("offline", {"reason": "stopped"})
        log.info("stopped")
    except Exception as e:
        heartbeat("offline", {"reason": str(e)})
        log.exception("fatal: %s", e)
        time.sleep(5)
        raise
