"""
Starts one MT5 bridge window per ENABLED account on the Brokers page.

The account list is read live from the cloud, so this ZIP never goes stale.
The FIRST enabled account uses the normal MT5 installation (no terminal path
needed). Only the 2nd, 3rd... accounts need their own "MT5 terminal path",
because one MT5 installation can only be logged into one account at a time.
Copying ON/OFF is re-checked by each bridge before every new trade.
"""
import os
import subprocess
import sys

import bootstrap

bootstrap.setup(["requests"])

from cloud_client import create_cloud_client

sb = create_cloud_client(os.environ["CLOUD_URL"], os.environ["CLOUD_KEY"])
rows = sb.table("broker_accounts").select("id,label,login,server,terminal_path,is_active").order("created_at").execute().data or []


def spawn(title, extra_env):
    env = {**os.environ, **extra_env}
    cmd = f'start "{title}" cmd /k ""{sys.executable}" mt5_bridge.py"'
    subprocess.Popen(cmd, shell=True, env=env, cwd=str(bootstrap.HERE))


if not rows:
    print("No accounts on the Brokers page yet - starting the bridge with the Setup credentials.")
    spawn("GoldCopier MT5 Bridge", {"BROKER_ACCOUNT_ID": "", "MT5_TERMINAL_PATH": ""})
    sys.exit(0)

started = 0
for r in rows:
    name = r.get("label") or f"#{r['login']}"
    if not r.get("is_active"):
        print(f"Skipping {name}: disabled on the Brokers page.")
        continue
    path = (r.get("terminal_path") or "").strip()
    if started > 0 and not path:
        print(f"Skipping {name}: extra accounts need their own 'MT5 terminal path' on the Brokers page "
              "(a separate MT5 installation folder).")
        continue
    if path and not os.path.exists(path):
        print(f"WARNING {name}: terminal path not found on this VPS: {path}")
        if started > 0:
            continue
        path = ""  # first account falls back to the default MT5 installation
    print(f"Starting bridge for {name} ({r['server']}){' using ' + path if path else ' using default MT5'}")
    spawn(f"GoldCopier MT5 - {name}", {"BROKER_ACCOUNT_ID": str(r["id"]), "MT5_TERMINAL_PATH": path})
    started += 1

if started == 0:
    print("No enabled accounts to start. Turn an account ON (Enabled) on the Brokers page.")
