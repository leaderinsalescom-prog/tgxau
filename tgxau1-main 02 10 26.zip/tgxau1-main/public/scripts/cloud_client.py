"""
Tiny REST client for the GoldCopier cloud database.

This replaces the heavy supabase Python package so the VPS setup installs
fewer dependencies and works reliably on newer Python versions.

Performance notes (latency matters — gold moves fast):
  * A single pooled `requests.Session` is shared by every call, so TLS is
    negotiated once instead of on every request. This alone removes
    ~50-150 ms from each database round-trip.
  * Writes default to `return=minimal` unless the caller needs the row back,
    which cuts response size and parse time.
  * Short, explicit timeouts prevent a slow network from stalling the
    execution loop.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

import requests
from requests.adapters import HTTPAdapter

# One pooled, keep-alive session for the whole process.
_SESSION = requests.Session()
_ADAPTER = HTTPAdapter(pool_connections=8, pool_maxsize=16, max_retries=0)
_SESSION.mount("https://", _ADAPTER)
_SESSION.mount("http://", _ADAPTER)

# (connect, read) timeouts in seconds.
DEFAULT_TIMEOUT = (3.0, 10.0)


@dataclass
class Result:
    data: Any = None
    error: Optional[str] = None


def _clean_value(value: Any) -> Any:
    if value == "now()":
        return datetime.now(timezone.utc).isoformat()
    if isinstance(value, dict):
        return {k: _clean_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean_value(v) for v in value]
    return value


def _filter_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


class CloudTable:
    def __init__(self, base_url: str, headers: dict[str, str], table: str):
        self.base_url = base_url.rstrip("/")
        self.headers = headers
        self.table = table
        self.method = "GET"
        self.payload: Any = None
        self.params: dict[str, str] = {}
        self.extra_headers: dict[str, str] = {}
        self._wants_body = True

    # ---- verbs ----
    def select(self, columns: str = "*") -> "CloudTable":
        self.method = "GET"
        self.params["select"] = columns
        return self

    def insert(self, payload: Any, returning: bool = True) -> "CloudTable":
        self.method = "POST"
        self.payload = _clean_value(payload)
        self._set_prefer(returning)
        return self

    def upsert(self, payload: Any, on_conflict: Optional[str] = None, returning: bool = False,
               ignore_duplicates: bool = False) -> "CloudTable":
        self.method = "POST"
        self.payload = _clean_value(payload)
        self._set_prefer(returning, "resolution=ignore-duplicates" if ignore_duplicates else "resolution=merge-duplicates")
        if on_conflict:
            self.params["on_conflict"] = on_conflict
        return self

    def update(self, payload: dict[str, Any], returning: bool = False) -> "CloudTable":
        self.method = "PATCH"
        self.payload = _clean_value(payload)
        self._set_prefer(returning)
        return self

    def delete(self, returning: bool = False) -> "CloudTable":
        self.method = "DELETE"
        self._set_prefer(returning)
        return self

    def _set_prefer(self, returning: bool, extra: str = "") -> None:
        parts = [p for p in (extra, "return=representation" if returning else "return=minimal") if p]
        self.extra_headers["Prefer"] = ",".join(parts)
        self._wants_body = returning

    # ---- filters ----
    def eq(self, column: str, value: Any) -> "CloudTable":
        self.params[column] = f"eq.{_filter_value(value)}"
        return self

    def neq(self, column: str, value: Any) -> "CloudTable":
        self.params[column] = f"neq.{_filter_value(value)}"
        return self

    def gte(self, column: str, value: Any) -> "CloudTable":
        self.params[column] = f"gte.{_filter_value(value)}"
        return self

    def lte(self, column: str, value: Any) -> "CloudTable":
        self.params[column] = f"lte.{_filter_value(value)}"
        return self

    def in_(self, column: str, values: Iterable[Any]) -> "CloudTable":
        joined = ",".join(_filter_value(v) for v in values)
        self.params[column] = f"in.({joined})"
        return self

    def order(self, column: str, desc: bool = False) -> "CloudTable":
        self.params["order"] = f"{column}.desc" if desc else column
        return self

    def limit(self, count: int) -> "CloudTable":
        self.params["limit"] = str(count)
        return self

    def single(self) -> "CloudTable":
        self.extra_headers["Accept"] = "application/vnd.pgrst.object+json"
        self._wants_body = True
        return self

    # ---- execution ----
    def execute(self, timeout: tuple[float, float] = DEFAULT_TIMEOUT) -> Result:
        url = f"{self.base_url}/rest/v1/{self.table}"
        headers = {**self.headers, **self.extra_headers}
        try:
            response = _SESSION.request(
                self.method,
                url,
                headers=headers,
                params=self.params,
                json=self.payload,
                timeout=timeout,
            )
            if response.status_code == 406 and self.extra_headers.get("Accept", "").endswith("json"):
                return Result(data=None, error=None)
            response.raise_for_status()
            if not response.text:
                return Result(data=None, error=None)
            return Result(data=response.json(), error=None)
        except Exception as exc:
            raise RuntimeError(f"Cloud database request failed for {self.table}: {exc}") from exc


class CloudClient:
    def __init__(self, url: str, key: str):
        self.url = url.rstrip("/")
        self.headers = {
            "apikey": key,
            "Content-Type": "application/json",
            "Accept-Encoding": "gzip",
            "Connection": "keep-alive",
        }
        # Legacy JWT anon keys also go in Authorization; new sb_publishable_ keys
        # are opaque and must only be sent as `apikey`.
        if not key.startswith("sb_"):
            self.headers["Authorization"] = f"Bearer {key}"

    def table(self, name: str) -> CloudTable:
        return CloudTable(self.url, self.headers, name)


def create_cloud_client(url: str, key: str) -> CloudClient:
    return CloudClient(url, key)
