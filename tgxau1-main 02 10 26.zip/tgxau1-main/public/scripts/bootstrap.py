"""
Shared startup helper for every GoldCopier VPS script.

Import it FIRST (`import bootstrap`) in each script. It:
  1. Checks the Python version (MetaTrader5 needs 3.10 - 3.13).
  2. Installs any missing library into THIS SAME Python automatically,
     so double-clicking a .py file works too.
  3. Loads .env (no extra library needed, tolerant of BOM/quotes/spaces).
  4. Verifies the cloud connection and falls back to the built-in keys if
     the .env ones are wrong/old, with a clear message instead of a crash.

Run `python bootstrap.py --check` to test everything without starting trading.
"""
from __future__ import annotations

import importlib
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.chdir(HERE)
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# Built-in PUBLIC defaults (safe to share) — used if .env is missing or stale.
DEFAULT_CLOUD_URL = "https://c--766f14a9-f1a7-41d7-afb4-f3d8ef7b4620-prod.lovable.cloud"
DEFAULT_CLOUD_KEY = "sb_publishable_8H--9ahkLRAyDAHA_973jQ_Hai6XHu0"
DEFAULT_APP_URL = "https://tgxau1.lovable.app"

# import name -> pip package
REQUIRED = {
    "requests": "requests>=2.32.3",
    "dotenv": "python-dotenv>=1.0.1",
    "telethon": "telethon>=1.43.2,<2",
    "MetaTrader5": "MetaTrader5>=5.0.45",
}


def fail(msg: str) -> None:
    print("\n" + "=" * 60 + "\nERROR: " + msg + "\n" + "=" * 60)
    try:
        input("Press Enter to close this window...")
    except Exception:
        pass
    sys.exit(1)


def check_python() -> None:
    v = sys.version_info
    if not ((3, 10) <= (v.major, v.minor) < (3, 14)):
        fail(f"This window is using Python {v.major}.{v.minor} ({sys.executable}).\n"
             "MetaTrader5 only works with Python 3.10 - 3.13.\n"
             "Install Python 3.13 from python.org (tick 'Add python.exe to PATH'),\n"
             "then start with 1_START_HERE.bat instead of double-clicking .py files.")


def ensure_packages(names=None) -> None:
    names = names or list(REQUIRED)
    missing = []
    for mod in names:
        try:
            importlib.import_module(mod)
        except Exception:
            missing.append(REQUIRED[mod])
    if not missing:
        return
    print(f"Installing missing libraries into {sys.executable}: {', '.join(missing)}")
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--prefer-binary", *missing]
    if subprocess.call(cmd) != 0:
        fail("Could not install: " + ", ".join(missing) +
             "\nCheck the VPS internet connection and run 1_START_HERE.bat again.")
    importlib.invalidate_caches()
    for mod in names:
        try:
            importlib.import_module(mod)
        except Exception as exc:
            fail(f"Library '{mod}' still cannot be loaded: {exc}")


def load_env() -> None:
    path = HERE / ".env"
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8-sig", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'").strip()
        # .env in THIS folder wins over stale Windows environment variables,
        # except variables start_bridges.py passes to each bridge window.
        if k in ("BROKER_ACCOUNT_ID", "MT5_TERMINAL_PATH") and os.environ.get(k):
            continue
        os.environ[k] = v


def _probe(url: str, key: str) -> int:
    import requests
    headers = {"apikey": key}
    if not key.startswith("sb_"):
        headers["Authorization"] = f"Bearer {key}"
    try:
        r = requests.get(f"{url.rstrip('/')}/rest/v1/settings", params={"select": "id", "limit": "1"},
                         headers=headers, timeout=(5, 15))
        return r.status_code
    except Exception as exc:
        print(f"  cloud request error: {exc}")
        return 0


def verify_cloud() -> None:
    url = (os.environ.get("CLOUD_URL") or "").strip() or DEFAULT_CLOUD_URL
    key = (os.environ.get("CLOUD_KEY") or "").strip() or DEFAULT_CLOUD_KEY
    code = _probe(url, key)
    if code != 200 and (url, key) != (DEFAULT_CLOUD_URL, DEFAULT_CLOUD_KEY):
        print(f"Cloud keys in .env were rejected (HTTP {code}); using the built-in keys instead.")
        url, key = DEFAULT_CLOUD_URL, DEFAULT_CLOUD_KEY
        code = _probe(url, key)
    if code != 200:
        fail(f"Cannot reach the GoldCopier cloud (HTTP {code or 'no connection'}).\n"
             "Check the VPS internet connection / firewall, or download the latest ZIP\n"
             "from the web app (Settings page) and extract it into a fresh folder.")
    os.environ["CLOUD_URL"], os.environ["CLOUD_KEY"] = url, key
    os.environ.setdefault("APP_URL", DEFAULT_APP_URL)


def _keep_open_on_crash() -> None:
    orig = sys.excepthook

    def hook(t, v, tb):
        orig(t, v, tb)
        if t is not KeyboardInterrupt:
            try:
                input("\nThe script stopped with the error above. Press Enter to close...")
            except Exception:
                pass
    sys.excepthook = hook


def setup(packages=None) -> None:
    check_python()
    ensure_packages(packages)
    load_env()
    verify_cloud()
    _keep_open_on_crash()


if __name__ == "__main__":
    setup()
    if "--check" in sys.argv:
        print(f"Python {sys.version.split()[0]} OK, libraries OK, cloud connection OK.")
