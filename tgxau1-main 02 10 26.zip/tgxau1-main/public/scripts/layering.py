"""
GoldCopier Pro — Layering maths (pure functions, no MT5 / network).

Layering splits the configured Positions per Signal into N layers spread
evenly across the signal's entry zone:
    BUY : first layer = upper entry, walking DOWN to the lower entry
    SELL: first layer = lower entry, walking UP   to the upper entry

Marginal Entry (independent of Layering) lets any entry level trigger when
price comes within `marginal_entry_pips` of it (above on BUY, below on SELL).
"""
from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
from typing import Optional


def snap_to_tick(price: float, tick: float, digits: int) -> float:
    """Round a price to the broker's tick size and digits."""
    if tick and tick > 0:
        t = Decimal(str(tick))
        q = (Decimal(str(price)) / t).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * t
        price = float(q)
    return round(price, max(0, int(digits)))


def dynamic_pip_size(symbol: str, digits: int, point: float, class_pip: Optional[float] = None) -> float:
    """Pip size from the broker's symbol spec.

    Known instrument classes (metals, crypto, JPY, major FX) keep the app's
    existing pip convention (`class_pip`) so pips mean the same thing
    everywhere in the app. For anything else, derive from digits: 3/5-digit
    quotes use 10 points per pip, otherwise 1 point. Never smaller than 1 point.
    """
    point = float(point or 0) or 10 ** (-int(digits or 0))
    if class_pip:
        return max(float(class_pip), point)
    return point * 10 if int(digits or 0) in (3, 5) else point


def compute_layer_prices(entry_a: float, entry_b: float, n: int, side: str,
                         tick: float, digits: int) -> list[float]:
    """N evenly spaced layer prices across the zone, ordered by fill priority."""
    n = max(1, int(n))
    lo, hi = min(entry_a, entry_b), max(entry_a, entry_b)
    start, end = (hi, lo) if side == "BUY" else (lo, hi)
    if n == 1:
        return [snap_to_tick(start, tick, digits)]
    step = (end - start) / (n - 1)
    return [snap_to_tick(start + step * i, tick, digits) for i in range(n)]


def layer_triggered(side: str, current: float, level: float, margin_price: float = 0.0) -> bool:
    """Has price reached this level (or come within the Marginal Entry distance)?

    BUY : current ask <= level + margin     SELL: current bid >= level - margin
    Marginal Entry applies to every level independently of Layering.
    """
    m = max(0.0, float(margin_price or 0.0))
    if side == "BUY":
        return current <= level + m
    return current >= level - m


def pending_limit_price(side: str, level: float, margin_price: float, bid: float, ask: float,
                        min_dist: float, tick: float, digits: int,
                        zone_lo: float, zone_hi: float, sl: Optional[float]) -> Optional[float]:
    """Price for a pending LIMIT order (never a market order).

    Marginal Entry moves the order toward the market by the margin so a fast
    market that stops just short of the entry still fills. The result is
    clamped to the nearest broker-valid limit price (BUY below ask, SELL above
    bid, respecting the stop level). Returns None when no valid limit price
    exists inside the entry zone (+ margin) or when it would sit beyond the SL.
    """
    m = max(0.0, float(margin_price or 0.0))
    step = float(tick or 0) or 10 ** (-int(digits or 0))
    gap = max(float(min_dist or 0), step)
    if side == "BUY":
        p = min(level + m, ask - gap)
        p = snap_to_tick(p, tick, digits)
        while p > ask - gap + 1e-12:          # snapping must never make it invalid
            p = round(p - step, max(0, int(digits)))
        if p < zone_lo - m - 1e-12 or (sl is not None and p <= sl):
            return None
        return p
    p = max(level - m, bid + gap)
    p = snap_to_tick(p, tick, digits)
    while p < bid + gap - 1e-12:
        p = round(p + step, max(0, int(digits)))
    if p > zone_hi + m + 1e-12 or (sl is not None and p >= sl):
        return None
    return p


def normalize_lot(lot: float, vmin: float, vstep: float, vmax: float) -> float:
    """Round DOWN to the lot step (never increases risk); clamp to broker limits."""
    vstep = float(vstep or 0.01)
    vmin = float(vmin or vstep)
    steps = int((Decimal(str(lot)) / Decimal(str(vstep))).to_integral_value(rounding="ROUND_FLOOR"))
    out = float(Decimal(steps) * Decimal(str(vstep)))
    if vmax:
        out = min(out, float(vmax))
    return max(out, vmin) if out > 0 else vmin


def estimate_group_loss(side: str, prices: list[float], sl: float, lot: float,
                        pip: float, pip_value_per_lot: float) -> float:
    """Total account-currency loss if every layer fills and is stopped out."""
    total = 0.0
    for p in prices:
        dist = (p - sl) if side == "BUY" else (sl - p)
        total += max(0.0, dist) / pip * pip_value_per_lot * lot
    return total
