"""
GoldCopier Pro — MetaTrader 5 Bridge
Connects to the local MT5 terminal, executes orders queued by the web app,
streams account/positions back to Supabase, and manages Quick-100-Pips,
Hybrid and Scalping exit rules.

Run on your Windows VPS:  python mt5_bridge.py
(MetaTrader 5 terminal must be open and logged in.)
"""
from __future__ import annotations

import logging
import os
import re
import sys
import time
import threading
import queue
import datetime as dt
from typing import Optional

import bootstrap  # checks Python, auto-installs libraries, loads .env, verifies cloud

bootstrap.setup(["requests", "MetaTrader5"])

import MetaTrader5 as mt5
from cloud_client import CloudClient, create_cloud_client
import layering
CLOUD_URL = (os.environ.get("CLOUD_URL") or os.environ.get("SUPABASE_URL", "")).strip()
CLOUD_KEY = (os.environ.get("CLOUD_KEY") or os.environ.get("SUPABASE_KEY", "")).strip()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MT5] %(levelname)s %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("mt5")

if not CLOUD_URL or not CLOUD_KEY:
    log.error("Missing CLOUD_URL / CLOUD_KEY in .env. Re-download the VPS bundle from Settings and extract all files into one folder.")
    input("Press Enter to exit...")
    sys.exit(1)

sb: CloudClient = create_cloud_client(CLOUD_URL, CLOUD_KEY)


# Optional: when several MT5 terminals run the copier, each bridge sets
# BROKER_ACCOUNT_ID in its own .env so it only claims the actions addressed to
# it. Left empty (the normal single-account setup) this bridge takes everything.
BROKER_ACCOUNT_ID = (os.environ.get("BROKER_ACCOUNT_ID") or "").strip()
MT5_TERMINAL_PATH = (os.environ.get("MT5_TERMINAL_PATH") or "").strip()

# The Brokers page (broker_accounts table) is the single source of truth for
# MT5 accounts. This bridge serves exactly ONE account:
#   * BROKER_ACCOUNT_ID set  -> that account
#   * not set                -> the main account (oldest row on the Brokers page)
# If no broker account exists yet, it falls back to the Settings credentials.
_MY_ACCOUNT: dict = {}
_MY_ACCOUNT_AT: float = 0.0
IS_PRIMARY: bool = True


def get_my_account(force: bool = False) -> dict:
    global _MY_ACCOUNT, _MY_ACCOUNT_AT, IS_PRIMARY
    if not force and (time.monotonic() - _MY_ACCOUNT_AT) < 2.0:
        return _MY_ACCOUNT
    try:
        res = sb.table("broker_accounts").select(
            "id,login,password_encrypted,server,terminal_path,is_active,copy_enabled,created_at"
        ).order("created_at").execute()
        rows = res.data or []
        primary_id = rows[0]["id"] if rows else None
        if BROKER_ACCOUNT_ID:
            _MY_ACCOUNT = next((r for r in rows if str(r["id"]) == BROKER_ACCOUNT_ID), {}) or {"id": BROKER_ACCOUNT_ID, "missing": True}
        else:
            _MY_ACCOUNT = rows[0] if rows else {}
        IS_PRIMARY = (not BROKER_ACCOUNT_ID) or (BROKER_ACCOUNT_ID == str(primary_id))
        _MY_ACCOUNT_AT = time.monotonic()
    except Exception as e:
        log.warning("broker account refresh failed (%s); using cached copy", e)
    return _MY_ACCOUNT


def my_account_id() -> Optional[str]:
    acc = get_my_account()
    return str(acc["id"]) if acc.get("id") else None


def _action_is_mine(payload: dict) -> bool:
    target = (payload or {}).get("broker_account_id")
    mine = my_account_id()
    if not target:
        # Unrouted action (manual review, position-page ticket actions, or a
        # setup without broker accounts): only the main bridge takes it.
        return IS_PRIMARY
    return mine is not None and str(target) == mine


def copying_allowed() -> tuple[bool, str]:
    """Live re-check right before placing a NEW trade, so toggling copying OFF
    on the Brokers page stops even orders that were already queued."""
    acc = get_my_account(force=True)
    if not acc.get("id"):
        return True, ""                       # legacy single-account setup
    if acc.get("missing"):
        return False, "broker_account_removed"
    if not acc.get("is_active"):
        return False, "account_disabled"
    if not acc.get("copy_enabled"):
        return False, "copying_off"
    return True, ""


def update_my_broker_row(values: dict) -> None:
    acc_id = my_account_id()
    if not acc_id or _MY_ACCOUNT.get("missing"):
        return
    try:
        sb.table("broker_accounts").update(values).eq("id", acc_id).execute()
    except Exception as e:
        log.warning("broker account status update failed: %s", e)


def set_settings_connected(connected: bool, account_type: Optional[str] = None) -> None:
    if not IS_PRIMARY:
        return
    values: dict = {"mt5_connected": connected}
    if account_type is not None:
        values["mt5_account_type"] = account_type
    sb.table("settings").update(values).eq("id", 1).execute()


SYMBOL_DEFAULT = "XAUUSD"
MAGIC = 770001
LAST_TRADE_ERROR: Optional[dict] = None
_SYMBOL_CACHE: dict[str, str] = {}
# In-memory groups by sig8: full context for mode-rule watcher.
_SIGNAL_META: dict[str, dict] = {}
# Tickets we've already announced as "entry_filled" to avoid duplicate audit rows.
_ANNOUNCED_FILLS: set[int] = set()
# Sig8 groups we've already announced target_hit for, until they reopen.
_ANNOUNCED_TARGETS: set[str] = set()
# Hybrid: sig8 groups where remaining half already has SL moved to breakeven.
_HYBRID_BE_DONE: set[str] = set()
# sig8 groups where pendings have been cancelled after target reached.
_PENDINGS_CANCELLED: set[str] = set()
# Signal groups already managed by a channel/manual half-close instruction.
_HALF_MANAGED: set[str] = set()
# sig8 -> highest number of FILLED positions ever observed for that group.
# Shrinkage (a target being hit) is only ever measured against this number.
_PEAK_OPEN: dict[str, int] = {}
# Last set of tickets pushed to public.positions (None = not primed yet).
_LAST_POSITION_TICKETS: Optional[set[int]] = None

# ---- Risk defaults (drawdown control) ----
# Reward:risk used when a channel gives no SL.
DEFAULT_RR = 1.5
# Never place an SL tighter than this (pips) — avoids spread-noise stop-outs.
MIN_SL_PIPS_FLOOR = 15.0
# Fallback TP distance (pips) when neither the mode nor the channel gives one.
DEFAULT_TP_PIPS = 60.0
# Hard cap on account equity risked per signal group.
RISK_PCT_CAP = 1.0


def max_sl_pips_for(symbol: str) -> float:
    """Hard cap on stop distance per instrument. Over-wide channel stops are the
    single biggest driver of drawdown, so they get clamped here."""
    s = (symbol or "").upper()
    if "XAU" in s or "GOLD" in s:
        return 350.0          # 35.00 price move on gold
    if any(c in s for c in ("BTC", "ETH", "XBT", "LTC", "XRP", "SOL", "DOGE", "BNB")):
        return 1500.0
    if "JPY" in s:
        return 80.0
    return 80.0


def _pip_value_per_lot(symbol: str) -> float:
    """Approximate account-currency value of 1 pip for 1.00 lot."""
    info = mt5.symbol_info(symbol)
    if not info or not info.trade_tick_size:
        return 10.0
    try:
        return float(info.trade_tick_value) * (pip_size(symbol) / float(info.trade_tick_size))
    except Exception:
        return 10.0


def cap_lot_by_risk(symbol: str, lot: float, sl_pips: float, count: int, settings: dict) -> float:
    """Shrink the per-position lot so the whole group risks at most RISK_PCT_CAP
    of equity if every position is stopped out. Never increases the lot."""
    try:
        acc = mt5.account_info()
        if not acc or sl_pips <= 0 or count <= 0:
            return lot
        pct = float(settings.get("risk_percent_cap") or RISK_PCT_CAP)
        budget = float(acc.equity) * (pct / 100.0)
        per_pip = _pip_value_per_lot(symbol)
        if per_pip <= 0:
            return lot
        max_total_lots = budget / (sl_pips * per_pip)
        max_each = max_total_lots / count
        info = mt5.symbol_info(symbol)
        step = float(getattr(info, "volume_step", 0.01) or 0.01)
        min_lot = float(getattr(info, "volume_min", 0.01) or 0.01)
        if max_each >= lot:
            return lot
        capped = max(min_lot, round(max_each / step) * step)
        capped = round(capped, 2)
        if capped < lot:
            log.info("lot capped by risk: %.2f -> %.2f (sl=%.0f pips, %d pos)", lot, capped, sl_pips, count)
        return capped
    except Exception as e:
        log.warning("risk sizing failed (%s); using requested lot", e)
        return lot




# Non-critical cloud writes (audit rows, status updates) go through one FIFO
# background thread so they never sit between a signal and its MT5 order.
_BG_Q: "queue.Queue" = queue.Queue()


def _bg_worker() -> None:
    while True:
        fn, args, kwargs = _BG_Q.get()
        try:
            fn(*args, **kwargs)
        except Exception as e:  # never let a failed write kill the thread
            log.warning("background write failed: %s", e)


threading.Thread(target=_bg_worker, name="cloud-writer", daemon=True).start()


def bg(fn, *args, **kwargs) -> None:
    _BG_Q.put((fn, args, kwargs))


def _log_event_sync(event_type, signal_id, sig8, channel, detail) -> None:
    try:
        sb.table("signal_events").insert({
            "signal_id": signal_id or None, "sig8": sig8 or None,
            "channel_name": channel or None, "event_type": event_type, "detail": detail or {},
        }, returning=False).execute()
    except Exception as e:
        log.warning("log_event(%s) failed: %s", event_type, e)


def log_event(event_type: str, signal_id: Optional[str], sig8: Optional[str],
              channel: Optional[str], detail: Optional[dict] = None) -> None:
    """Queue an audit row for public.signal_events. Non-blocking, never raises."""
    bg(_log_event_sync, event_type, signal_id, sig8, channel, dict(detail or {}))



# ---------------- symbol / pip helpers ----------------

def resolve_symbol(requested: str) -> Optional[str]:
    """Return the broker's actual symbol name (handles XAUUSDm, XAUUSD.r, XAUUSD-ECN, etc.)."""
    if not requested:
        return None
    if requested in _SYMBOL_CACHE:
        return _SYMBOL_CACHE[requested]
    if mt5.symbol_info(requested):
        _SYMBOL_CACHE[requested] = requested
        mt5.symbol_select(requested, True)
        return requested
    base = requested.upper().rstrip(".").rstrip("-").rstrip("_")
    candidates = mt5.symbols_get() or []
    matches = [s.name for s in candidates if s.name.upper().startswith(base)]
    if not matches:
        matches = [s.name for s in candidates if base in s.name.upper()]
    if not matches:
        log.error("No broker symbol matches %s. Available count=%d", requested, len(candidates))
        return None
    matches.sort(key=len)
    chosen = matches[0]
    mt5.symbol_select(chosen, True)
    _SYMBOL_CACHE[requested] = chosen
    log.info("Resolved broker symbol %s -> %s", requested, chosen)
    return chosen


def pip_size(symbol: str) -> float:
    """
    Universal pip convention:
      XAU*  → 0.10   (10 pips = 1.00 price move)
      BTC*/ETH*/crypto → 1.00  (1 pip = 1.00 price move)
      *JPY  → 0.01
      other forex → 0.0001
    """
    s = (symbol or "").upper()
    if "XAU" in s or "GOLD" in s:
        return 0.10
    if any(c in s for c in ("BTC", "ETH", "XBT", "LTC", "XRP", "SOL", "DOGE", "BNB")):
        return 1.00
    if "JPY" in s:
        return 0.01
    return 0.0001


def pip_multiplier(symbol: str) -> float:
    """Inverse of pip_size: how many pips per 1.0 price difference."""
    ps = pip_size(symbol)
    return 1.0 / ps if ps else 0.0


def price_to_pips(symbol: str, delta: float) -> float:
    return delta * pip_multiplier(symbol)


def pips_to_price(symbol: str, pips: float) -> float:
    return pips * pip_size(symbol)


def current_price(symbol: str, side: str) -> Optional[float]:
    tick = mt5.symbol_info_tick(symbol)
    if not tick:
        return None
    return tick.ask if side == "BUY" else tick.bid


# ---------------- supabase helpers ----------------

def heartbeat(status: str = "online", meta: Optional[dict] = None) -> None:
    update_my_broker_row({"health_status": status, "last_seen_at": "now()"})
    if not IS_PRIMARY:
        return
    try:
        sb.table("bridge_heartbeat").upsert({
            "service": "mt5",
            "status": status,
            "last_seen": "now()",
            "meta": meta or {},
        }, on_conflict="service").execute()
    except Exception as e:
        log.warning("heartbeat failed: %s", e)


_SETTINGS_CACHE: dict = {}
_SETTINGS_AT: float = 0.0
SETTINGS_TTL = 2.0


def get_settings(force: bool = False) -> dict:
    """Cached settings read. Order execution must never wait on a network
    round-trip just to learn the trading mode."""
    global _SETTINGS_CACHE, _SETTINGS_AT
    if not force and _SETTINGS_CACHE and (time.monotonic() - _SETTINGS_AT) < SETTINGS_TTL:
        return _SETTINGS_CACHE
    try:
        res = sb.table("settings").select("*").eq("id", 1).single().execute()
        _SETTINGS_CACHE = res.data or {}
        _SETTINGS_AT = time.monotonic()
    except Exception as e:
        if not _SETTINGS_CACHE:
            raise
        log.warning("settings refresh failed (%s); using cached copy", e)
    return _SETTINGS_CACHE


def current_credentials() -> tuple[str, str, str, str]:
    acc = get_my_account()
    if acc.get("id") and not acc.get("missing"):
        return (str(acc.get("login") or ""), str(acc.get("password_encrypted") or ""),
                str(acc.get("server") or ""), MT5_TERMINAL_PATH if "MT5_TERMINAL_PATH" in os.environ else str(acc.get("terminal_path") or ""))
    s = get_settings()
    return (str(s.get("mt5_login") or ""), str(s.get("mt5_password") or ""),
            str(s.get("mt5_server") or ""), MT5_TERMINAL_PATH)


def credentials_signature(settings: dict) -> tuple[str, str, str, str]:
    return current_credentials()


def account_type_name(trade_mode: int) -> str:
    if trade_mode == 2: return "live"
    if trade_mode == 1: return "contest"
    return "demo"


def trade_result(res) -> dict:
    if res is None:
        return {"result": None, "last_error": mt5.last_error()}
    if hasattr(res, "_asdict"):
        data = res._asdict()
        return {k: str(v) if k == "request" else v for k, v in data.items()}
    return {"result": str(res), "last_error": mt5.last_error()}


_FILLING_OK: dict = {}   # symbol -> filling mode the broker accepted last time
_REQUOTE_CODES = {getattr(mt5, "TRADE_RETCODE_REQUOTE", 10004), getattr(mt5, "TRADE_RETCODE_PRICE_CHANGED", 10020),
                  getattr(mt5, "TRADE_RETCODE_PRICE_OFF", 10021)}


def send_order_with_fallback(req: dict, ok_codes: set[int]):
    """Send with the broker's known-good filling mode first (no wasted
    rejected attempts), one fast re-price retry on requotes, then fall back
    through the other filling modes."""
    global LAST_TRADE_ERROR
    LAST_TRADE_ERROR = None
    sym = req.get("symbol", "")
    fillings = ([_FILLING_OK[sym]] if sym in _FILLING_OK else []) + \
        [req.get("type_filling"), mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_RETURN, None]
    seen = set()
    for filling in fillings:
        if filling in seen: continue
        seen.add(filling)
        attempt = {**req}
        if filling is None: attempt.pop("type_filling", None)
        else: attempt["type_filling"] = filling
        for _try in range(2):
            res = mt5.order_send(attempt)
            if res is not None and res.retcode in ok_codes:
                LAST_TRADE_ERROR = None
                _FILLING_OK[sym] = filling
                return res
            LAST_TRADE_ERROR = trade_result(res)
            if (res is not None and res.retcode in _REQUOTE_CODES and _try == 0
                    and attempt.get("action") == mt5.TRADE_ACTION_DEAL):
                tick = mt5.symbol_info_tick(sym)
                if tick:
                    attempt["price"] = tick.ask if attempt.get("type") == mt5.ORDER_TYPE_BUY else tick.bid
                    continue
            break
        log.error("order_send failed with filling=%s: %s", filling, LAST_TRADE_ERROR)
    return None


# ---------------- connection ----------------

def connect_mt5() -> bool:
    get_my_account(force=True)
    login, password, server, terminal = current_credentials()
    if not (login and password and server):
        log.warning("MT5 credentials missing. Add the account on the Setup or Brokers page.")
        set_settings_connected(False)
        update_my_broker_row({"health_status": "no_credentials"})
        return False
    try:
        login_number = int(str(login).strip())
    except ValueError:
        log.error("MT5 login must be a number. Current value: %s", login)
        set_settings_connected(False)
        heartbeat("offline", {"reason": "login_not_numeric"})
        return False
    mt5.shutdown()
    init_kwargs = {"login": login_number, "password": password, "server": server}
    if terminal:
        init_kwargs["path"] = terminal
    if not mt5.initialize(**init_kwargs):
        err = mt5.last_error()
        log.error("MT5 init failed: %s", err)
        set_settings_connected(False)
        heartbeat("offline", {"reason": f"init_failed: {err}"})
        return False
    info = mt5.account_info()
    if not info:
        log.error("No account info; not logged in")
        return False
    account_type = account_type_name(info.trade_mode)
    set_settings_connected(True, account_type)
    update_my_broker_row({"health_status": "online", "account_type": account_type,
                          "current_balance": float(info.balance), "current_equity": float(info.equity)})
    log.info("MT5 connected: #%s %s [%s]", info.login, info.server, account_type)
    return True


# ---------------- sync ----------------

def sync_account() -> None:
    info = mt5.account_info()
    if not info: return
    account_type = account_type_name(info.trade_mode)
    update_my_broker_row({"current_balance": float(info.balance), "current_equity": float(info.equity),
                          "account_type": account_type, "health_status": "online", "last_seen_at": "now()"})
    if not IS_PRIMARY:
        return
    sb.table("account").update({
        "balance": float(info.balance), "equity": float(info.equity),
        "margin": float(info.margin), "free_margin": float(info.margin_free),
        "currency": info.currency, "login": str(info.login),
        "server": info.server, "account_type": account_type,
    }).eq("id", 1).execute()
    set_settings_connected(True, account_type)


def parse_comment(c: str) -> tuple[Optional[str], Optional[str]]:
    """Extract (channel_name, sig8) from our comment format 'CHAN|sig8' or legacy 'GC_sig_x'."""
    if not c: return (None, None)
    if "|" in c:
        chan, sig = c.split("|", 1)
        return (chan.strip() or None, sig.strip()[:8] or None)
    return (None, None)


def sync_positions() -> list[dict]:
    if not IS_PRIMARY:
        return []  # shared dashboard tables are owned by the main account bridge
    positions = mt5.positions_get() or []
    rows = []
    for p in positions:
        side = "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL"
        cur = current_price(p.symbol, "SELL" if side == "BUY" else "BUY") or p.price_current
        delta = (cur - p.price_open) if side == "BUY" else (p.price_open - cur)
        pips = price_to_pips(p.symbol, delta)
        chan, sig = parse_comment(p.comment)
        rows.append({
            "mt5_ticket": int(p.ticket),
            "instrument": p.symbol,
            "direction": side,
            "lot_size": float(p.volume),
            "entry_price": float(p.price_open),
            "current_price": float(cur),
            "sl": float(p.sl) if p.sl else None,
            "tp": float(p.tp) if p.tp else None,
            "pnl_usd": float(p.profit),
            "pnl_pips": round(pips, 2),
            "opened_at": _ts(p.time),
            "channel_name": chan,
            "comment": p.comment,
        })
    # Incremental sync: only delete tickets that actually disappeared. Wiping the
    # whole table every second made the UI flicker and burned latency budget.
    global _LAST_POSITION_TICKETS
    live = {r["mt5_ticket"] for r in rows}
    if _LAST_POSITION_TICKETS is None:
        # First pass after start: reconcile against whatever is stale in the app.
        sb.table("positions").delete().neq("mt5_ticket", 0).execute()
    else:
        gone = _LAST_POSITION_TICKETS - live
        if gone:
            sb.table("positions").delete().in_("mt5_ticket", list(gone)).execute()
    if rows:
        sb.table("positions").upsert(rows, on_conflict="mt5_ticket").execute()
    _LAST_POSITION_TICKETS = live
    return rows


def sync_history() -> None:
    if not IS_PRIMARY:
        return None  # shared dashboard tables are owned by the main account bridge
    now = time.time()
    deals = mt5.history_deals_get(now - 86400 * 14, now) or []
    rows = []
    by_pos: dict[int, list] = {}
    for d in deals:
        by_pos.setdefault(d.position_id, []).append(d)
    for pos_id, ds in by_pos.items():
        ds.sort(key=lambda x: x.time)
        opens = [d for d in ds if d.entry == mt5.DEAL_ENTRY_IN]
        closes = [d for d in ds if d.entry == mt5.DEAL_ENTRY_OUT]
        if not opens or not closes: continue
        op = opens[0]; cl = closes[-1]
        side = "BUY" if op.type == mt5.DEAL_TYPE_BUY else "SELL"
        pnl = sum(d.profit + d.swap + d.commission for d in ds)
        delta = (cl.price - op.price) if side == "BUY" else (op.price - cl.price)
        chan, _sig = parse_comment(op.comment or cl.comment)
        rows.append({
            "mt5_ticket": int(pos_id),
            "instrument": op.symbol,
            "direction": side,
            "lot_size": float(op.volume),
            "entry_price": float(op.price),
            "close_price": float(cl.price),
            "pnl_usd": round(pnl, 2),
            "pnl_pips": round(price_to_pips(op.symbol, delta), 2),
            "close_reason": classify_close_reason(cl.comment),
            "opened_at": _ts(op.time),
            "closed_at": _ts(cl.time),
            "status": "closed",
            "channel_name": chan,
            "comment": op.comment,
        })
    if rows:
        sb.table("trades").upsert(rows, on_conflict="mt5_ticket").execute()


def classify_close_reason(comment: str) -> str:
    """Map broker close comment to a user-facing reason.
    Returns one of: TP1 | TP2 | 100 Pips | Scalp Target | Manual | SL | Cancelled | BREAKEVEN.
    """
    c = (comment or "").lower()
    if "cancel" in c: return "Cancelled"
    if "sl" in c or "stop" in c: return "SL"
    if "scalp" in c: return "Scalp Target"
    if "100" in c or "quick" in c: return "100 Pips"
    if "tp2" in c or "tp_2" in c: return "TP2"
    if "tp1" in c or "tp_1" in c or "tp " in c or c.endswith("tp") or "[tp]" in c: return "TP1"
    if "be" in c or "breakeven" in c: return "BREAKEVEN"
    if "manual" in c: return "Manual"
    return "Manual"


def _ts(epoch: int) -> str:
    import datetime as dt
    return dt.datetime.utcfromtimestamp(int(epoch)).isoformat() + "Z"


# ---------------- order execution ----------------

def _sanitize_comment(channel: Optional[str], sig8: Optional[str]) -> str:
    chan = re.sub(r"[^A-Za-z0-9_]+", "", (channel or "GC"))[:20] or "GC"
    sig = (sig8 or "")[:8]
    base = f"{chan}|{sig}" if sig else chan
    return base[:31]


def open_position(symbol: str, side: str, volume: float, sl: Optional[float], tp: Optional[float], comment: str) -> Optional[int]:
    if sl is None or tp is None or float(sl) <= 0 or float(tp) <= 0:
        log.error("refusing naked market order: %s %s requires both SL and TP", side, symbol)
        return None
    info = mt5.symbol_info(symbol)
    if not info:
        log.error("symbol not found: %s", symbol); return None
    if not info.visible:
        mt5.symbol_select(symbol, True); info = mt5.symbol_info(symbol)
    tick = mt5.symbol_info_tick(symbol)
    if not tick:
        log.error("no quote for %s", symbol); return None
    price = tick.ask if side == "BUY" else tick.bid
    req = {
        "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": float(volume),
        "type": mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL,
        "price": price, "sl": float(sl) if sl else 0.0, "tp": float(tp) if tp else 0.0,
        "deviation": 20, "magic": MAGIC, "comment": comment[:31], "type_time": mt5.ORDER_TIME_GTC,
    }
    res = send_order_with_fallback(req, {mt5.TRADE_RETCODE_DONE})
    if res is None: return None
    return int(res.order or res.deal)


def place_limit(symbol: str, side: str, volume: float, price: float, sl: Optional[float], tp: Optional[float], comment: str) -> Optional[int]:
    if sl is None or tp is None or float(sl) <= 0 or float(tp) <= 0:
        log.error("refusing naked pending order: %s %s requires both SL and TP", side, symbol)
        return None
    info = mt5.symbol_info(symbol)
    if not info:
        log.error("symbol not found: %s", symbol); return None
    if not info.visible: mt5.symbol_select(symbol, True)
    req = {
        "action": mt5.TRADE_ACTION_PENDING, "symbol": symbol, "volume": float(volume),
        "type": mt5.ORDER_TYPE_BUY_LIMIT if side == "BUY" else mt5.ORDER_TYPE_SELL_LIMIT,
        "price": float(price), "sl": float(sl) if sl else 0.0, "tp": float(tp) if tp else 0.0,
        "magic": MAGIC, "comment": comment[:31], "type_time": mt5.ORDER_TIME_GTC,
    }
    res = send_order_with_fallback(req, {mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED})
    if res is None: return None
    return int(res.order or res.deal)


def close_ticket(ticket: int) -> bool:
    pos = mt5.positions_get(ticket=ticket)
    if not pos: return False
    p = pos[0]
    side = "SELL" if p.type == mt5.POSITION_TYPE_BUY else "BUY"
    tick = mt5.symbol_info_tick(p.symbol)
    if not tick: return False
    price = tick.bid if side == "SELL" else tick.ask
    req = {
        "action": mt5.TRADE_ACTION_DEAL, "position": int(ticket), "symbol": p.symbol,
        "volume": p.volume,
        "type": mt5.ORDER_TYPE_SELL if side == "SELL" else mt5.ORDER_TYPE_BUY,
        "price": price, "deviation": 20, "magic": MAGIC,
        "comment": (p.comment or "GC_manual")[:31], "type_filling": mt5.ORDER_FILLING_IOC,
    }
    r = mt5.order_send(req)
    return r is not None and r.retcode == mt5.TRADE_RETCODE_DONE


def cancel_pending_order(order_ticket: int) -> bool:
    r = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": int(order_ticket)})
    return r is not None and r.retcode in (mt5.TRADE_RETCODE_DONE, mt5.TRADE_RETCODE_PLACED)


def modify_ticket(ticket: int, sl: Optional[float] = None, tp: Optional[float] = None) -> bool:
    pos = mt5.positions_get(ticket=ticket)
    if not pos: return False
    p = pos[0]
    req = {
        "action": mt5.TRADE_ACTION_SLTP, "position": int(ticket), "symbol": p.symbol,
        "sl": float(sl) if sl is not None else (p.sl or 0.0),
        "tp": float(tp) if tp is not None else (p.tp or 0.0),
    }
    r = mt5.order_send(req)
    return r is not None and r.retcode == mt5.TRADE_RETCODE_DONE


# ---------------- layering ----------------
# Every layer is a row in public.signal_layers, unique per (signal, account,
# layer number). That row is the single record of whether a layer was sent, so
# restarts, reconnects and re-delivered actions can never re-open a layer.

LAYER_WATCH_MAX_HOURS = 24.0     # instant-mode layers that never trigger expire
LAYER_REFRESH_SEC = 5.0
DUP_SIGNAL_WINDOW_SEC = 120      # identical layered signal twice in 2 min = duplicate
_LAYER_WATCH: list[dict] = []
_LAYER_WATCH_AT: float = 0.0
_LAYER_RECONCILE_AT: float = 0.0


def _account_key() -> str:
    return my_account_id() or "legacy"


def entry_config(payload: dict, settings: dict) -> tuple[bool, bool, float]:
    """(layering_on, marginal_on, marginal_pips). Layering and Marginal Entry are
    independent settings. Live settings first (so a change applies without a
    new ZIP), queued payload snapshot as fallback."""
    def pick(k, default):
        v = settings.get(k)
        if v is None:
            v = payload.get(k)
        return default if v is None else v
    layer_on = bool(pick("layering_enabled", False))
    marg_on = bool(pick("marginal_entry_enabled", False))
    try:
        marg = max(0.0, min(500.0, float(pick("marginal_entry_pips", 0) or 0)))
    except (TypeError, ValueError):
        marg = 0.0
    return layer_on, marg_on and marg > 0, marg


def _class_pip(symbol: str) -> Optional[float]:
    s = (symbol or "").upper()
    if "XAU" in s or "GOLD" in s or "XAG" in s or "SILVER" in s:
        return pip_size(symbol) if "XAG" not in s and "SILVER" not in s else 0.01
    if any(c in s for c in ("BTC", "ETH", "XBT", "LTC", "XRP", "SOL", "DOGE", "BNB")):
        return pip_size(symbol)
    fx = ("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD")
    if sum(1 for c in fx if c in s) >= 2:
        return pip_size(symbol)
    return None  # indices, oils, exotics → derived from broker digits


def layer_pip_size(symbol: str) -> float:
    info = mt5.symbol_info(symbol)
    if not info:
        return pip_size(symbol)
    return layering.dynamic_pip_size(symbol, int(info.digits), float(info.point), _class_pip(symbol))


def _layer_comment(channel: Optional[str], sig8: str, layer_no: int) -> str:
    chan = re.sub(r"[^A-Za-z0-9_]+", "", (channel or "GC"))[:16] or "GC"
    return f"{chan}|{sig8[:8]}|L{layer_no:02d}"[:31]


def _layer_update(row_id: str, values: dict, only_if_status: Optional[str] = None) -> bool:
    """Update a layer row. With only_if_status the update is a compare-and-set
    claim: it succeeds only if the row is still in that status."""
    try:
        q = sb.table("signal_layers").update(values, returning=True).eq("id", row_id)
        if only_if_status:
            q = q.eq("status", only_if_status)
        res = q.execute()
        return bool(res.data)
    except Exception as e:
        log.warning("layer update failed (%s): %s", row_id, e)
        return False


def _position_fill(ticket: int) -> tuple[Optional[float], Optional[float], Optional[int]]:
    """(fill price, filled volume, position ticket) for a market order ticket."""
    pos = mt5.positions_get(ticket=ticket) or []
    if pos:
        return float(pos[0].price_open), float(pos[0].volume), int(pos[0].ticket)
    return None, None, ticket


def _register_fill(sig8: str, tk: int, first_target: bool) -> None:
    _ANNOUNCED_FILLS.add(tk)
    meta = _SIGNAL_META.get(sig8)
    if not meta:
        return
    meta.setdefault("filled_tickets", set()).add(tk)
    if first_target:
        meta.setdefault("first_target_filled", set()).add(tk)
        meta.setdefault("first_target_tickets", set()).add(tk)


_RECENT_SIGNALS: dict[tuple, tuple[str, float]] = {}


def _duplicate_signal(signal_id: str, channel: str, symbol: str, side: str,
                      lo: float, hi: float, sl: float) -> Optional[str]:
    """In-memory, zero-latency duplicate guard (same channel re-posting the same
    trade within 2 minutes, or the same signal delivered twice)."""
    now = time.time()
    for k, (_sid, t) in list(_RECENT_SIGNALS.items()):
        if now - t > DUP_SIGNAL_WINDOW_SEC:
            _RECENT_SIGNALS.pop(k, None)
    key = ((channel or "").lower(), symbol, side, round(lo, 5), round(hi, 5), round(float(sl), 5))
    prev = _RECENT_SIGNALS.get(key)
    if prev:
        return "already_processed" if prev[0] == signal_id else "duplicate_signal"
    _RECENT_SIGNALS[key] = (signal_id, now)
    return None


def execute_plan(*, signal_id: str, sig8: str, channel: str, symbol: str, side: str,
                 levels: list, layered: bool, lot: float, sl: float, tp: float, cur: float,
                 exec_mode: str, mode: str, market_signal: bool, marg_on: bool, marg_pips: float,
                 zone_lo: float, zone_hi: float) -> dict:
    """Execute one signal on THIS account.

    levels = [(entry_price, leg)], one per position. Every order gets the same
    signal SL and the same signal TP. Decision per position:
      * market signal (no entry price)       -> market now
      * Limit mode                           -> pending LIMIT order now (never market)
      * Instant, Layering OFF, Marginal OFF  -> market now
      * Instant otherwise                    -> market now if the level (+ marginal
                                                distance) is reached, else watched
    """
    info = mt5.symbol_info(symbol)
    tick_q = mt5.symbol_info_tick(symbol)
    if not info or not tick_q:
        return {"error": f"symbol_not_ready:{symbol}"}
    digits = int(info.digits)
    tick = float(info.trade_tick_size or info.point)
    point = float(info.point or tick)
    min_dist = float(getattr(info, "trade_stops_level", 0) or 0) * point
    lpip = layer_pip_size(symbol)
    m = marg_pips * lpip if marg_on else 0.0
    bid, ask = float(tick_q.bid), float(tick_q.ask)
    edge = zone_hi if side == "BUY" else zone_lo   # first entry price reached

    decisions = []   # (action, price, level, leg, reason)
    for level, leg in levels:
        if market_signal:
            decisions.append(("market", cur, level, leg, None)); continue
        if exec_mode == "limit":
            lp = layering.pending_limit_price(side, level, m, bid, ask, min_dist, tick, digits, zone_lo, zone_hi, sl)
            decisions.append(("limit", lp, level, leg, None) if lp else ("skip", None, level, leg, "entry_passed_no_valid_limit_price"))
            continue
        if not layered and not marg_on:
            decisions.append(("market", cur, level, leg, None)); continue
        target = level if layered else edge
        if layering.layer_triggered(side, cur, target, m):
            decisions.append(("market", cur, target, leg, None))
        else:
            decisions.append(("watch", None, target, leg, None))

    for i, d in enumerate(decisions):
        if d[0] == "market" and ((side == "BUY" and cur >= tp) or (side == "SELL" and cur <= tp)):
            decisions[i] = ("skip", None, d[2], d[3], "price_past_target")

    n = len(decisions)
    acct = my_account_id()
    tracked = bool(signal_id)
    status0 = {"market": "sending", "limit": "sending", "watch": "watching", "skip": "skipped"}
    rows = [{
        "signal_id": signal_id, "sig8": sig8, "account_key": _account_key(), "broker_account_id": acct,
        "channel_name": channel, "symbol": symbol, "direction": side,
        "entry_low": zone_lo, "entry_high": zone_hi, "layer_no": i + 1, "total_layers": n,
        "layer_price": float(d[2]), "lot_size": lot, "sl": sl, "tp": tp,
        "tolerance_pips": marg_pips if marg_on else None,
        "execution_mode": exec_mode, "trading_mode": mode, "status": status0[d[0]], "error": d[4],
    } for i, d in enumerate(decisions)]

    saved: dict[int, dict] = {}
    needs_claim = tracked and any(d[0] in ("limit", "watch") for d in decisions)
    if needs_claim:
        # The insert IS the claim: unique (signal, account, layer) means a
        # re-delivered signal gets nothing back and places nothing.
        try:
            res = sb.table("signal_layers").upsert(rows, on_conflict="signal_id,account_key,layer_no",
                                                   ignore_duplicates=True, returning=True).execute()
            saved = {int(r["layer_no"]): r for r in (res.data or [])}
        except Exception as e:
            return {"error": f"layer_store_failed:{e}"}
        if not saved:
            return {"skipped": "already_processed"}

    log_event("execution_plan", signal_id, sig8, channel, {
        "positions": n, "layered": layered, "execution_mode": exec_mode, "mode": mode,
        "marginal_entry_pips": marg_pips if marg_on else 0, "pip_size": lpip,
        "actions": [d[0] for d in decisions], "levels": [d[2] for d in decisions],
        "lot": lot, "sl": sl, "tp": tp,
    })

    out = {"tickets": [], "market": [], "pending": [], "ticket_meta": {}, "plan": [], "watching": 0}
    filled_rows: list[dict] = []
    for i, (act, price, level, leg, reason) in enumerate(decisions):
        no = i + 1
        row = saved.get(no) if needs_claim else rows[i]
        if needs_claim and not row:
            continue
        out["plan"].append([float(price if price is not None else level), 1, act == "market"])
        comment = _layer_comment(channel, sig8, no) if tracked else _sanitize_comment(channel, sig8)
        if act == "skip":
            log_event("entry_skipped", signal_id, sig8, channel, {"reason": reason, "layer": no, "level": level})
            continue
        if act == "watch":
            out["watching"] += 1
            if row.get("id"):
                _LAYER_WATCH.append(row)
            continue
        tk = (open_position(symbol, side, lot, sl, tp, comment) if act == "market"
              else place_limit(symbol, side, lot, float(price), sl, tp, comment))
        if not tk:
            err = str(LAST_TRADE_ERROR)[:500]
            row["status"] = "failed"; row["error"] = err
            if needs_claim: bg(_layer_update, row["id"], {"status": "failed", "error": err})
            log_event("entry_failed", signal_id, sig8, channel, {"layer": no, "kind": act, "price": price, "error": err})
            continue
        out["tickets"].append(tk)
        meta = {"entry": float(level), "tp": tp, "idx": i, "leg": leg, "kind": act, "layer": no}
        out["ticket_meta"][tk] = meta
        if act == "market":
            fp, vol, ptk = _position_fill(tk)
            out["market"].append(tk); _ANNOUNCED_FILLS.add(tk)
            upd = {"status": "filled", "order_ticket": tk, "position_ticket": ptk, "fill_price": fp, "filled_volume": vol}
            log_event("entry_filled", signal_id, sig8, channel, {"ticket": tk, "layer": no, "fill_price": fp,
                      "lot": vol or lot, "sl": sl, "tp": tp, "kind": "market"})
        else:
            out["pending"].append(tk)
            upd = {"status": "placed", "order_ticket": tk}
            log_event("entry_placed", signal_id, sig8, channel, {"ticket": tk, "layer": no, "price": price,
                      "entry": level, "lot": lot, "sl": sl, "tp": tp, "kind": "limit"})
        if needs_claim:
            bg(_layer_update, row["id"], upd)
        else:
            row.update(upd); filled_rows.append(row)
    if tracked and not needs_claim and rows:
        # Pure market execution: orders first, durable record right after (background).
        bg(lambda rs=rows: sb.table("signal_layers").upsert(rs, on_conflict="signal_id,account_key,layer_no",
                                                         ignore_duplicates=True).execute())
    return out


_LAYER_CLAIMED: set[str] = set()   # row ids this process already sent (pending cloud update)


def refresh_layer_watch(force: bool = False) -> None:
    global _LAYER_WATCH, _LAYER_WATCH_AT
    if not force and time.monotonic() - _LAYER_WATCH_AT < LAYER_REFRESH_SEC:
        return
    _LAYER_WATCH_AT = time.monotonic()
    try:
        res = (sb.table("signal_layers").select("*").eq("account_key", _account_key())
               .eq("status", "watching").order("created_at").limit(200).execute())
        _LAYER_WATCH = [r for r in (res.data or []) if r["id"] not in _LAYER_CLAIMED]
    except Exception as e:
        log.warning("layer watch refresh failed: %s", e)


def cancel_watchers(sigs: set, reason: str) -> int:
    n = 0
    for r in list(_LAYER_WATCH):
        if (r.get("sig8") or "") in sigs:
            _LAYER_WATCH.remove(r); _LAYER_CLAIMED.add(r["id"]); n += 1
            bg(_layer_update, r["id"], {"status": "cancelled", "error": reason}, "watching")
    return n


def _parse_ts(s: str) -> float:
    try:
        return dt.datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return time.time()


def watch_layers() -> None:
    """Instant-mode watcher (Layering and/or Marginal Entry). Local ticks only;
    a triggered row is claimed in memory and sent immediately — the cloud
    status update follows in the background."""
    refresh_layer_watch()
    if not _LAYER_WATCH:
        return
    keep: list[dict] = []
    allowed = None
    for r in _LAYER_WATCH:
        if r["id"] in _LAYER_CLAIMED:
            continue
        sym, side, sig8 = r["symbol"], r["direction"], r.get("sig8") or ""
        n = int(r["layer_no"]); price = float(r["layer_price"])
        sl = float(r["sl"]) if r.get("sl") is not None else None
        tp = float(r["tp"]) if r.get("tp") is not None else None
        def drop(status, err):
            _LAYER_CLAIMED.add(r["id"])
            bg(_layer_update, r["id"], {"status": status, "error": err}, "watching")
        if time.time() - _parse_ts(r["created_at"]) > LAYER_WATCH_MAX_HOURS * 3600:
            drop("expired", "not_reached"); continue
        if sig8 in _PENDINGS_CANCELLED or sig8 in _ANNOUNCED_TARGETS:
            drop("cancelled", "target_hit"); continue
        cur = current_price(sym, side)
        if cur is None:
            keep.append(r); continue
        if sl is not None and ((side == "BUY" and cur <= sl) or (side == "SELL" and cur >= sl)):
            drop("cancelled", "price_past_sl"); continue
        margin = float(r.get("tolerance_pips") or 0) * layer_pip_size(sym)
        if not layering.layer_triggered(side, cur, price, margin):
            keep.append(r); continue
        if tp is not None and ((side == "BUY" and cur >= tp) or (side == "SELL" and cur <= tp)):
            drop("skipped", "price_past_target"); continue
        if allowed is None:
            allowed, _why = copying_allowed()
        if not allowed:
            keep.append(r); continue  # copying switched OFF: hold, do not open
        _LAYER_CLAIMED.add(r["id"])
        tk = open_position(sym, side, float(r["lot_size"]), sl, tp, _layer_comment(r.get("channel_name"), sig8, n))
        if not tk:
            bg(_layer_update, r["id"], {"status": "failed", "error": str(LAST_TRADE_ERROR)[:500]}); continue
        fp, vol, ptk = _position_fill(tk)
        bg(_layer_update, r["id"], {"status": "filled", "order_ticket": tk, "position_ticket": ptk,
                                    "fill_price": fp, "filled_volume": vol})
        _register_fill(sig8, tk, first_target=True)
        log_event("entry_filled", r.get("signal_id"), sig8, r.get("channel_name"),
                  {"ticket": tk, "layer": n, "level": price, "fill_price": fp, "lot": vol,
                   "sl": sl, "tp": tp, "kind": "watched_market"})
    _LAYER_WATCH[:] = keep


def reconcile_layers(startup: bool = False) -> None:
    """Keep layer statuses true to MT5: limit filled/cancelled, position closed,
    and recover rows left in 'sending' by a crash (never re-sent)."""
    global _LAYER_RECONCILE_AT
    if not startup and time.monotonic() - _LAYER_RECONCILE_AT < LAYER_REFRESH_SEC:
        return
    _LAYER_RECONCILE_AT = time.monotonic()
    try:
        rows = (sb.table("signal_layers").select("id,sig8,layer_no,status,order_ticket,position_ticket")
                .eq("account_key", _account_key()).in_("status", ["sending", "placed", "filled"])
                .limit(300).execute().data or [])
    except Exception as e:
        log.warning("layer reconcile failed: %s", e); return
    if not rows:
        return
    positions = {int(p.ticket): p for p in (mt5.positions_get() or []) if p.magic == MAGIC}
    orders = {int(o.ticket): o for o in (mt5.orders_get() or []) if o.magic == MAGIC}
    for r in rows:
        st = r["status"]
        if st == "sending":
            tag = f"|{(r.get('sig8') or '')[:8]}|L{int(r['layer_no']):02d}"
            p = next((p for p in positions.values() if (p.comment or "").endswith(tag)), None)
            o = next((o for o in orders.values() if (o.comment or "").endswith(tag)), None)
            if p:
                _layer_update(r["id"], {"status": "filled", "order_ticket": int(p.ticket), "position_ticket": int(p.ticket),
                                        "fill_price": float(p.price_open), "filled_volume": float(p.volume)})
            elif o:
                _layer_update(r["id"], {"status": "placed", "order_ticket": int(o.ticket)})
            elif startup:
                # Outcome unknown and nothing live in MT5 — never retry blindly.
                _layer_update(r["id"], {"status": "failed", "error": "interrupted_before_confirmation"})
        elif st == "placed" and r.get("order_ticket"):
            tk = int(r["order_ticket"])
            if tk in orders:
                continue
            p = positions.get(tk) or next((p for p in positions.values() if int(getattr(p, "identifier", 0) or 0) == tk), None)
            if p:
                _layer_update(r["id"], {"status": "filled", "position_ticket": int(p.ticket),
                                        "fill_price": float(p.price_open), "filled_volume": float(p.volume)})
            else:
                hist = mt5.history_orders_get(ticket=tk) or []
                filled = bool(hist) and hist[0].state == mt5.ORDER_STATE_FILLED
                _layer_update(r["id"], {"status": "closed" if filled else "cancelled"})
        elif st == "filled" and r.get("position_ticket"):
            if int(r["position_ticket"]) not in positions:
                _layer_update(r["id"], {"status": "closed"})


def handle_open(payload: dict) -> dict:
    """Execute a parsed signal payload according to the active trading mode.

    Universal pip rule (see pip_size): XAU 0.10, BTC/crypto 1.00, JPY 0.01, forex 0.0001.
    TP price is computed from EACH position's own entry price:
        BUY  TP = entry + (pip_target * pip_size)
        SELL TP = entry - (pip_target * pip_size)

    Modes:
      scalping        – all N at first entry; TP = mode pip target; ignore channel TPs.
      quick_100       – split N across both entries; each pos TP = own entry ± pip target.
      hybrid          – split N across both entries; first 50% TP = pip target from own
                        entry, remaining 50% TP = channel final TP.
      channel_follow  – split N across both entries; first 50% TP = channel TP1,
                        remaining 50% TP = channel final TP. SL from channel.
    """
    settings = get_settings()
    mode = (payload.get("trading_mode") or settings.get("trading_mode") or "quick_100").lower()
    if mode not in ("scalping", "quick_100", "hybrid", "channel_follow"):
        mode = "quick_100"
    exec_mode = str(payload.get("execution_mode") or settings.get("execution_mode") or "limit").lower()
    if exec_mode not in ("instant", "limit"):
        exec_mode = "limit"
    requested_symbol = payload.get("symbol") or settings.get("instrument") or SYMBOL_DEFAULT
    symbol = resolve_symbol(requested_symbol)
    if not symbol:
        return {"error": f"symbol_not_found:{requested_symbol}",
                "hint": "Open the broker's Market Watch and confirm the symbol name (e.g. XAUUSDm)."}
    side: str = payload["direction"]
    entries: list[float] = [float(x) for x in (payload.get("entry") or [])]
    zone_entries: list[float] = list(entries)  # full entry zone, kept for layering
    entry_type = payload.get("entry_type")
    sl = payload.get("sl")
    tps: list[float] = [float(x) for x in (payload.get("tp") or [])]
    tp_type = payload.get("tp_type")
    signal_id = str(payload.get("signal_id") or "")
    sig8 = signal_id.replace("-", "")[:8] if signal_id else ""
    channel = payload.get("channel_name") or "GC"

    ps = pip_size(symbol)

    # Mode-driven sizing + pip targets
    if mode == "scalping":
        lot = float(payload.get("scalping_lot_size") or settings.get("lot_size") or 0.01)
        total_count = int(payload.get("scalping_position_count") or settings.get("scalping_position_count") or 10)
        target_pips = float(payload.get("scalping_pip_target") or settings.get("scalping_pip_target") or 50)
        entries = entries[:1]  # ignore any 2nd entry entirely
    elif mode == "hybrid":
        lot = float(payload.get("lot_size") or settings.get("lot_size") or 0.01)
        total_count = int(payload.get("position_count") or settings.get("position_count") or 2)
        target_pips = float(payload.get("hybrid_pip_target") or settings.get("hybrid_pip_target") or 100)
    elif mode == "channel_follow":
        lot = float(payload.get("lot_size") or settings.get("lot_size") or 0.01)
        total_count = int(payload.get("position_count") or settings.get("position_count") or 2)
        target_pips = 0.0  # follows channel TPs
    else:  # quick_100
        lot = float(payload.get("lot_size") or settings.get("lot_size") or 0.01)
        total_count = int(payload.get("position_count") or settings.get("position_count") or 2)
        target_pips = float(payload.get("quick_pip_target") or settings.get("quick_pip_target") or 100)

    cur = current_price(symbol, side)
    if cur is None:
        return {"error": "no_quote"}

    # Convert channel-supplied TPs from pips to absolute prices
    if tp_type == "pips" and tps:
        ref = entries[0] if entries else cur
        tps = [ref + t * ps if side == "BUY" else ref - t * ps for t in tps]

    channel_tp1 = tps[0] if tps else None
    channel_final_tp = tps[-1] if tps else None

    # ---- Mandatory + capped stop loss (drawdown control) ----
    ref_entry = entries[0] if entries else cur
    max_sl_pips = max_sl_pips_for(symbol)
    sl_for_open = float(sl) if sl is not None else None
    sl_source = "signal"

    if sl_for_open is None:
        # Derive a synthetic SL so no order is ever naked.
        tp_dist = 0.0
        if channel_final_tp is not None:
            tp_dist = price_to_pips(symbol, abs(channel_final_tp - ref_entry))
        risk_pips = max(target_pips, tp_dist) / DEFAULT_RR if max(target_pips, tp_dist) > 0 else 0.0
        risk_pips = min(max(risk_pips, MIN_SL_PIPS_FLOOR), max_sl_pips)
        sl_for_open = ref_entry - risk_pips * ps if side == "BUY" else ref_entry + risk_pips * ps
        sl_source = "derived"

    # Clamp an over-wide channel SL — this is the main drawdown driver.
    sl_dist_pips = price_to_pips(symbol, abs(ref_entry - sl_for_open))
    if sl_dist_pips > max_sl_pips:
        sl_for_open = ref_entry - max_sl_pips * ps if side == "BUY" else ref_entry + max_sl_pips * ps
        sl_source = "clamped"
        log_event("sl_clamped", signal_id, sig8, channel,
                  {"original_pips": round(sl_dist_pips, 1), "capped_pips": max_sl_pips,
                   "new_sl": round(sl_for_open, 5), "mode": mode})
        sl_dist_pips = max_sl_pips

    # Pre-flight: price already past SL → skip
    if (side == "BUY" and cur <= sl_for_open) or (side == "SELL" and cur >= sl_for_open):
        log_event("entry_skipped", signal_id, sig8, channel,
                  {"reason": "price_past_sl", "current": cur, "sl": sl_for_open})
        return {"skipped": "price_past_sl"}

    # ================= Execution hierarchy =================
    # signal -> validation (above) -> trading mode (sizing) -> account (bridge)
    # -> position count -> Layering -> Marginal Entry -> Execution Mode
    # -> ONE signal TP + signal SL -> risk cap -> MT5.
    total_count = max(1, int(total_count))
    layer_on, marg_on, marg_pips = entry_config(payload, settings)
    market_signal = (not entries) or entry_type == "market"
    zone_lo = min(zone_entries) if zone_entries and not market_signal else cur
    zone_hi = max(zone_entries) if zone_entries and not market_signal else cur
    edge = zone_hi if side == "BUY" else zone_lo

    # ---- ONE authoritative TP for every position (signal TP; never per layer) ----
    tp_source = "signal"
    signal_tp = None
    if tps:
        far = max(tps) if side == "BUY" else min(tps)
        if (side == "BUY" and far > edge) or (side == "SELL" and far < edge):
            signal_tp = far
        else:
            log_event("tp_rejected", signal_id, sig8, channel, {"reason": "tp_wrong_side_of_entry", "tps": tps, "entry_edge": edge})
    if signal_tp is None:
        # No usable TP in the signal: mandatory-TP rule, one derived value for all.
        fb = target_pips if target_pips > 0 else DEFAULT_TP_PIPS
        signal_tp = ref_entry + fb * ps if side == "BUY" else ref_entry - fb * ps
        tp_source = "derived"
    signal_tp = float(signal_tp)

    layered = (layer_on and not market_signal and len(zone_entries) >= 2 and zone_hi > zone_lo)
    info = mt5.symbol_info(symbol)
    if layered:
        prices = layering.compute_layer_prices(zone_entries[0], zone_entries[1], total_count, side,
                                               float(info.trade_tick_size or info.point), int(info.digits))
        first_half = max(1, total_count // 2)
        levels = [(p, 0 if i < first_half else 1) for i, p in enumerate(prices)]
    elif market_signal:
        levels = [(cur, 0)] * total_count
    elif mode == "scalping" or len(entries) < 2 or total_count < 2:
        levels = [(entries[0], 0)] * total_count
    else:
        half = total_count // 2
        levels = [(entries[0], 0)] * half + [(entries[1], 1)] * (total_count - half)

    dup = _duplicate_signal(signal_id or str(time.time()), channel, symbol, side, zone_lo, zone_hi, sl_for_open)
    if dup:
        log_event("entry_skipped", signal_id, sig8, channel, {"reason": dup})
        return {"skipped": dup, "tickets": []}

    # ---- Risk / capital protection: size against the worst entry, never larger ----
    worst_pips = max(price_to_pips(symbol, abs((cur if market_signal else p) - sl_for_open)) for p, _ in levels)
    lot = cap_lot_by_risk(symbol, lot, worst_pips, len(levels), settings)
    if info:
        lot = layering.normalize_lot(lot, info.volume_min, info.volume_step, info.volume_max)

    total_planned = len(levels)
    single_target = True       # one TP for every position
    half_cutoff = total_planned

    lr = execute_plan(signal_id=signal_id, sig8=sig8, channel=channel, symbol=symbol, side=side,
                      levels=levels, layered=layered, lot=lot, sl=float(sl_for_open), tp=signal_tp, cur=cur,
                      exec_mode=exec_mode, mode=mode, market_signal=market_signal,
                      marg_on=marg_on, marg_pips=marg_pips, zone_lo=zone_lo, zone_hi=zone_hi)
    if lr.get("skipped") or lr.get("error"):
        return {**lr, "tickets": [], "layered": layered, "sig8": sig8}
    tickets, market_tickets, pending_tickets = lr["tickets"], lr["market"], lr["pending"]
    ticket_meta = lr["ticket_meta"]
    plan = lr["plan"]
    layers_watching = int(lr.get("watching") or 0)
    tps = [signal_tp]

    # Remember group for mode-rule watcher
    if sig8:
        _ANNOUNCED_TARGETS.discard(sig8)
        _HYBRID_BE_DONE.discard(sig8)
        _PENDINGS_CANCELLED.discard(sig8)
        _HALF_MANAGED.discard(sig8)
        # Peak = highest number of *filled* positions ever observed for this group.
        # Shrinkage is measured against this, never against the planned/pending
        # count — otherwise unfilled limit orders look like "target already hit".
        # A retried/duplicate dispatch must never reset the observed filled
        # peak downward and re-arm first-target housekeeping incorrectly.
        _PEAK_OPEN[sig8] = max(_PEAK_OPEN.get(sig8, 0), len(market_tickets))
        _SIGNAL_META[sig8] = {
            "channel": channel, "symbol": symbol, "direction": side,
            "mode": mode, "signal_id": signal_id,
            "target_pips": target_pips,
            "channel_tp1": channel_tp1,
            "channel_final_tp": channel_final_tp,
            "initial_count": len(market_tickets),
            "pending_count": len(pending_tickets),
            "pending_tickets": pending_tickets,
            "sl_original": sl_for_open,
            "sl_source": sl_source,
            "ticket_meta": ticket_meta,
            "filled_tickets": set(market_tickets),
            "first_target_tickets": {tk for tk, tm in ticket_meta.items() if tm.get("idx", 0) < half_cutoff},
            "first_target_filled": {tk for tk in market_tickets if ticket_meta.get(tk, {}).get("idx", 0) < half_cutoff},
            "first_target_tp_prices": [
                float(tm["tp"]) for tm in ticket_meta.values()
                if tm.get("idx", 0) < half_cutoff and tm.get("tp") is not None
            ],
            "first_target_count": 1 if single_target else half_cutoff,
            "single_target": single_target,
            "execution_mode": exec_mode,
            "half_close_mode": str(payload.get("half_close_mode") or settings.get("half_close_mode") or "auto").lower(),
            "half_close_pips": float(payload.get("half_close_pips") or settings.get("half_close_pips") or 40),
            "breakeven_enabled": bool(payload.get("breakeven_enabled", settings.get("breakeven_enabled", True))),
            "breakeven_offset_pips": float(payload.get("breakeven_offset_pips") if payload.get("breakeven_offset_pips") is not None else settings.get("breakeven_offset_pips", 5)),
            "opened_at": time.time(),
            "layered": layered,
            "layer_half_cutoff": half_cutoff,
            "signal_tp": signal_tp, "tp_source": tp_source,
        }

    result = {"tickets": tickets, "plan": [list(x) for x in plan], "tps": tps, "symbol": symbol,
              "current_price": cur, "mode": mode, "sig8": sig8,
              "execution_mode": exec_mode,
              "target_pips": target_pips}
    result["layered"] = layered
    result["layers_watching"] = layers_watching
    result["tp"] = signal_tp
    result["sl"] = sl_for_open
    if not tickets and not layers_watching:
        result["error"] = "no_orders_accepted"
        result["last_trade_error"] = LAST_TRADE_ERROR
    return result


def close_all() -> int:
    pos = mt5.positions_get() or []
    n = 0
    for p in pos:
        if close_ticket(int(p.ticket)): n += 1
    return n


# ---------------- mode management rules ----------------

def _group_open_positions_by_sig() -> dict[str, list]:
    out: dict[str, list] = {}
    for p in (mt5.positions_get() or []):
        if p.magic != MAGIC: continue
        _chan, sig = parse_comment(p.comment)
        out.setdefault(sig or "_", []).append(p)
    return out


def _pending_orders_for_sig(sig8: str) -> list:
    res = []
    for o in (mt5.orders_get() or []):
        if o.magic != MAGIC: continue
        _chan, s = parse_comment(o.comment)
        if s == sig8: res.append(o)
    return res


def _position_side(position) -> str:
    """Works for positions (0 BUY / 1 SELL) and pending orders (2 BUY_LIMIT,
    3 SELL_LIMIT, 4 BUY_STOP, 5 SELL_STOP, ...): even = buy, odd = sell."""
    return "BUY" if int(position.type) % 2 == 0 else "SELL"


def _chan_key(name) -> str:
    return re.sub(r"[^a-z0-9_]+", "", str(name or "").lower())


def _matches_manage_filter(position, payload: dict) -> bool:
    """Scope a Telegram instruction to its channel/symbol/direction."""
    if position.magic != MAGIC:
        return False
    channel, _sig = parse_comment(position.comment)
    wanted = _chan_key(payload.get("channel_name"))
    have = _chan_key(channel)
    # Comments carry a sanitised, truncated channel name — compare the same form.
    if wanted and not (have and wanted.startswith(have)):
        return False
    wanted_symbol = str(payload.get("symbol") or "").upper()
    if wanted_symbol:
        actual = position.symbol.upper()
        if wanted_symbol not in actual and actual not in wanted_symbol:
            return False
    wanted_side = str(payload.get("direction") or "").upper()
    if wanted_side and _position_side(position) != wanted_side:
        return False
    return position.magic == MAGIC


def _improves_stop(position, new_sl: float) -> bool:
    side = _position_side(position)
    old_sl = float(position.sl or 0)
    current = current_price(position.symbol, "SELL" if side == "BUY" else "BUY")
    if current is None:
        return False
    if side == "BUY":
        return new_sl < current and (old_sl <= 0 or new_sl > old_sl)
    return new_sl > current and (old_sl <= 0 or new_sl < old_sl)


def _first_leg_positions(sig: str, positions: list) -> list:
    """Find filled first-entry positions; fall back to half of the live group.

    MT5 position IDs can differ from pending-order IDs, so price proximity is
    used when ticket metadata cannot identify the filled leg directly.
    """
    if not positions:
        return []
    meta = _SIGNAL_META.get(sig, {})
    ticket_meta = meta.get("ticket_meta") or {}
    direct = [p for p in positions if ticket_meta.get(int(p.ticket), {}).get("leg") == 0]
    if direct and len(direct) < len(positions):
        return direct
    first_entries = [float(v.get("entry")) for v in ticket_meta.values()
                     if v.get("leg") == 0 and v.get("entry") is not None]
    second_entries = [float(v.get("entry")) for v in ticket_meta.values()
                      if v.get("leg") == 1 and v.get("entry") is not None]
    if first_entries and second_entries:
        first_entry = first_entries[0]
        second_entry = second_entries[0]
        by_price = [p for p in positions
                    if abs(float(p.price_open) - first_entry) <= abs(float(p.price_open) - second_entry)]
        if by_price and len(by_price) < len(positions):
            return by_price
    count = max(1, len(positions) // 2)
    return sorted(positions, key=lambda p: int(p.ticket))[:count]


def _apply_half_management(sig: str, positions: list, source: str,
                           close_first_leg: bool = True,
                           set_breakeven: bool = True) -> dict:
    """Close the first leg (or half of one filled leg) and protect runners."""
    if sig in _HALF_MANAGED:
        return {"signal": sig, "already_managed": True}
    meta = _SIGNAL_META.get(sig, {})
    signal_id = meta.get("signal_id")
    channel = meta.get("channel")
    closed: list[int] = []
    targets = _first_leg_positions(sig, positions) if close_first_leg else []
    for position in targets:
        ticket = int(position.ticket)
        if close_ticket(ticket):
            closed.append(ticket)

    # Refresh after closes; never try to modify a position that just disappeared.
    remaining = [p for p in (mt5.positions_get() or [])
                 if p.magic == MAGIC and parse_comment(p.comment)[1] == sig]
    moved: list[dict] = []
    enabled = bool(meta.get("breakeven_enabled", get_settings().get("breakeven_enabled", True)))
    offset_pips = float(meta.get("breakeven_offset_pips", get_settings().get("breakeven_offset_pips", 5)) or 0)
    if set_breakeven and enabled:
        for position in remaining:
            side = _position_side(position)
            offset = offset_pips * pip_size(position.symbol)
            new_sl = float(position.price_open) + offset if side == "BUY" else float(position.price_open) - offset
            if _improves_stop(position, new_sl) and modify_ticket(int(position.ticket), sl=new_sl):
                moved.append({"ticket": int(position.ticket), "new_sl": new_sl})
                log_event("breakeven_set", signal_id, sig, channel,
                          {"ticket": int(position.ticket), "new_sl": new_sl,
                           "offset_pips": offset_pips, "source": source})
    _HALF_MANAGED.add(sig)
    detail = {"source": source, "closed": closed, "remaining": len(remaining),
              "breakeven": moved, "offset_pips": offset_pips}
    log_event("half_collected", signal_id, sig, channel, detail)
    return {"signal": sig, **detail}


def handle_manage(payload: dict) -> dict:
    """Apply a Telegram management instruction to THIS account's own live
    trades. Every account runs this independently on its own tickets."""
    ops = payload.get("ops") or []
    names = {str(op.get("op")) for op in ops if isinstance(op, dict)}
    positions = [p for p in (mt5.positions_get() or []) if _matches_manage_filter(p, payload)]
    orders = [o for o in (mt5.orders_get() or []) if _matches_manage_filter(o, payload)]
    grouped: dict[str, list] = {}
    for position in positions:
        _channel, sig = parse_comment(position.comment)
        if sig:
            grouped.setdefault(sig, []).append(position)
    order_sigs = {parse_comment(o.comment)[1] for o in orders} - {None}
    results: list[dict] = []
    full_close = "close_all" in names
    for sig, live in grouped.items():
        meta = _SIGNAL_META.get(sig, {})
        signal_id = meta.get("signal_id")
        channel = meta.get("channel") or payload.get("channel_name")
        if full_close:
            closed, failed = [], []
            for p in live:
                ok = close_ticket(int(p.ticket)) or close_ticket(int(p.ticket))  # one fast retry
                (closed if ok else failed).append(int(p.ticket))
            _ANNOUNCED_TARGETS.add(sig)
            results.append({"signal": sig, "closed": closed, "failed": failed})
            log_event("instruction_close_all", signal_id, sig, channel, {"closed": closed, "failed": failed, "raw": payload.get("raw")})
            continue
        if "collect_half" in names or "set_breakeven" in names:
            results.append(_apply_half_management(
                sig, live, "channel_instruction",
                close_first_leg="collect_half" in names,
                set_breakeven="set_breakeven" in names,
            ))
        fresh = [p for p in (mt5.positions_get() or [])
                 if p.magic == MAGIC and parse_comment(p.comment)[1] == sig]
        for op in ops:
            if not isinstance(op, dict):
                continue
            name = op.get("op")
            if name not in ("set_sl", "set_tp"):
                continue
            price = float(op.get("price") or 0)
            if price <= 0:
                continue
            changed = []
            for position in fresh:
                ok = modify_ticket(int(position.ticket),
                                   sl=price if name == "set_sl" else None,
                                   tp=price if name == "set_tp" else None)
                if ok:
                    changed.append(int(position.ticket))
            results.append({"signal": sig, "operation": name, "price": price, "tickets": changed})
            log_event("sltp_modified", signal_id, sig, channel,
                      {"operation": name, "price": price, "tickets": changed,
                       "source": "channel_instruction"})
    if full_close or "cancel_pending" in names:
        sigs = set(grouped) | order_sigs
        cancelled = [int(o.ticket) for o in orders if cancel_pending_order(int(o.ticket))]
        watchers = cancel_watchers(sigs, "channel_instruction")
        for sg in sigs:
            _PENDINGS_CANCELLED.add(sg)
        results.append({"cancelled": cancelled, "watchers_cancelled": watchers})
    return {"account": my_account_id(), "matched_signals": len(grouped), "pending_orders": len(orders), "results": results}


def _ticket_closed_by_tp(ticket: int, opened_at: float) -> bool:
    """Only a broker-confirmed TP deal may drive group target housekeeping.

    A position can disappear because of SL, a manual close, reconnection, or a
    transient terminal response. Treating any disappearance as TP caused valid
    pending entries to be cancelled while price was still in their entry zone.
    """
    try:
        deals = mt5.history_deals_get(position=int(ticket)) or []
        for deal in reversed(deals):
            if float(getattr(deal, "time", 0) or 0) + 2 < opened_at:
                continue
            if getattr(deal, "entry", None) != mt5.DEAL_ENTRY_OUT:
                continue
            return getattr(deal, "reason", None) == mt5.DEAL_REASON_TP
    except Exception as exc:
        log.debug("could not confirm TP close for %s: %s", ticket, exc)
    return False


def _avg_pips_for_group(ps: list) -> float:
    if not ps: return 0.0
    total = 0.0
    for p in ps:
        side = "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL"
        cur = current_price(p.symbol, "SELL" if side == "BUY" else "BUY") or p.price_current
        delta = (cur - p.price_open) if side == "BUY" else (p.price_open - cur)
        total += price_to_pips(p.symbol, delta)
    return total / len(ps)


_SCALP_TRAIL_ACTIVATED: set[int] = set()
_SCALP_BE_DONE: set[int] = set()
_SCALP_TIME_EXITED: set[str] = set()


def _atr_pips(symbol: str, period: int = 14) -> float:
    """Simple ATR (in pips) over the last `period` M1 candles."""
    try:
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 1, period + 1)
        if rates is None or len(rates) < 2: return 0.0
        trs = []
        for i in range(1, len(rates)):
            h, l, pc = rates[i]["high"], rates[i]["low"], rates[i - 1]["close"]
            trs.append(max(h - l, abs(h - pc), abs(l - pc)))
        if not trs: return 0.0
        return price_to_pips(symbol, sum(trs) / len(trs))
    except Exception:
        return 0.0


def _ema_value(symbol: str, period: int) -> float:
    try:
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 1, period * 3)
        if rates is None or len(rates) < period + 2: return 0.0
        closes = [r["close"] for r in rates]
        k = 2 / (period + 1)
        ema = sum(closes[:period]) / period
        for c in closes[period:]:
            ema = c * k + ema * (1 - k)
        return float(ema)
    except Exception:
        return 0.0


def _recent_swing(symbol: str, side: str, lookback: int = 20) -> Optional[float]:
    """Structure: for BUY return the most recent higher-low; for SELL, lower-high."""
    try:
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 1, lookback + 3)
        if rates is None or len(rates) < 5: return None
        if side == "BUY":
            lows = [(i, rates[i]["low"]) for i in range(1, len(rates) - 1)
                    if rates[i]["low"] < rates[i - 1]["low"] and rates[i]["low"] < rates[i + 1]["low"]]
            if not lows: return None
            return float(lows[-1][1])
        else:
            highs = [(i, rates[i]["high"]) for i in range(1, len(rates) - 1)
                     if rates[i]["high"] > rates[i - 1]["high"] and rates[i]["high"] > rates[i + 1]["high"]]
            if not highs: return None
            return float(highs[-1][1])
    except Exception:
        return None


def _apply_scalping_management(sig: str, meta: dict, ps_list: list, settings: dict) -> None:
    """Time-based exit + trailing stop for Scalping mode positions only."""
    if not ps_list: return
    symbol = meta.get("symbol")
    side = meta.get("direction")
    opened_at = float(meta.get("opened_at") or 0)
    chan = meta.get("channel"); signal_id = meta.get("signal_id")
    target_pips = float(meta.get("target_pips") or 0)
    ps = pip_size(symbol) if symbol else 0.10

    # --- Time-based exit ---
    time_exit_min = float(settings.get("scalping_time_exit_minutes") or 10)
    if opened_at and time_exit_min > 0 and sig not in _SCALP_TIME_EXITED:
        if time.time() - opened_at >= time_exit_min * 60:
            closed = []
            for p in ps_list:
                if close_ticket(int(p.ticket)): closed.append(int(p.ticket))
            log_event("time_exit", signal_id, sig, chan,
                      {"minutes": time_exit_min, "closed": closed, "mode": "scalping"})
            _SCALP_TIME_EXITED.add(sig)
            return

    # --- Trailing stop ---
    if not settings.get("scalping_trail_enabled", True): return
    style = (settings.get("scalping_trail_style") or "structure").lower()
    ema_period = int(settings.get("scalping_trail_ema_period") or 21)
    aggr_mult = float(settings.get("scalping_trail_aggressive_multiplier") or 3)
    be_offset_pips = float(settings.get("scalping_trail_be_offset_pips") or 10)

    for p in ps_list:
        tk = int(p.ticket)
        entry = float(p.price_open)
        cur = current_price(p.symbol, "SELL" if side == "BUY" else "BUY") or float(p.price_current)
        move_pips = price_to_pips(p.symbol, (cur - entry) if side == "BUY" else (entry - cur))
        # initial risk in pips (fallback to target if no SL)
        if p.sl:
            risk_pips = price_to_pips(p.symbol, abs(entry - float(p.sl)))
        else:
            risk_pips = target_pips or 20.0
        if risk_pips <= 0: risk_pips = target_pips or 20.0

        # 1st move: break-even after >= 1x risk in profit
        if tk not in _SCALP_BE_DONE and move_pips >= risk_pips:
            be_sl = entry + be_offset_pips * ps if side == "BUY" else entry - be_offset_pips * ps
            improved = (side == "BUY" and (not p.sl or be_sl > p.sl)) or (side == "SELL" and (not p.sl or be_sl < p.sl))
            if improved and modify_ticket(tk, sl=float(be_sl)):
                log_event("breakeven_set", signal_id, sig, chan,
                          {"ticket": tk, "new_sl": float(be_sl), "mode": "scalping"})
                _SCALP_BE_DONE.add(tk)
            continue

        if tk not in _SCALP_BE_DONE: continue  # don't trail before BE

        # Aggressive mode when profit >= aggr_mult * risk
        aggressive = move_pips >= aggr_mult * risk_pips
        new_sl: Optional[float] = None

        if aggressive:
            # Trail behind last completed candle high/low
            try:
                rates = mt5.copy_rates_from_pos(p.symbol, mt5.TIMEFRAME_M1, 1, 2)
                if rates is not None and len(rates) >= 1:
                    last = rates[-1]
                    new_sl = float(last["low"]) if side == "BUY" else float(last["high"])
            except Exception:
                new_sl = None
        elif style == "atr":
            atr = _atr_pips(p.symbol, 14)
            if atr > 0:
                new_sl = cur - atr * ps if side == "BUY" else cur + atr * ps
        elif style == "ema":
            ema = _ema_value(p.symbol, ema_period)
            if ema > 0:
                new_sl = ema  # SL sits at EMA line
        else:  # structure (default)
            sw = _recent_swing(p.symbol, side)
            if sw is not None:
                new_sl = sw

        if new_sl is None: continue
        # Only tighten in profit direction
        improved = (side == "BUY" and (not p.sl or new_sl > p.sl) and new_sl < cur) or \
                   (side == "SELL" and (not p.sl or new_sl < p.sl) and new_sl > cur)
        if improved and modify_ticket(tk, sl=float(new_sl)):
            log_event("trail_moved", signal_id, sig, chan,
                      {"ticket": tk, "new_sl": float(new_sl), "style": style,
                       "aggressive": aggressive, "mode": "scalping"})


def apply_mode_rules(default_mode: str) -> None:
    """Watcher run every second.

    TP prices for each mode are set on-order at open time (broker closes when
    reached). This loop does the post-TP housekeeping:
      * Detect newly-filled limit orders → log entry_filled.
      * Confirm TP closures from broker deal history → target hit:
          - scalping / quick_100: close any remaining + cancel pendings.
          - hybrid / channel_follow: at first shrinkage, cancel pendings + move
            SL of remaining positions to breakeven ± 10 pips.
      * Manual position management: collect half at the configured pip profit.
      * Scalping-only: time-based exit and trailing SL management.
    """
    settings = get_settings()
    groups = _group_open_positions_by_sig()

    # 1) Log newly-filled limit orders.
    for sig, ps in groups.items():
        meta = _SIGNAL_META.get(sig, {})
        for p in ps:
            tk = int(p.ticket)
            if tk in _ANNOUNCED_FILLS: continue
            _ANNOUNCED_FILLS.add(tk)
            if meta:
                meta.setdefault("filled_tickets", set()).add(tk)
                first_tps = meta.get("first_target_tp_prices") or []
                if any(abs(float(p.tp or 0) - float(tp)) <= pip_size(p.symbol) for tp in first_tps):
                    meta.setdefault("first_target_filled", set()).add(tk)
            chan, _ = parse_comment(p.comment)
            log_event("entry_filled", meta.get("signal_id"), sig, chan or meta.get("channel"),
                      {"ticket": tk, "price": float(p.price_open), "lot": float(p.volume),
                       "kind": "limit_filled"})

    # 2) Housekeeping per known signal group.
    known_sigs = set(_SIGNAL_META.keys()) | set(groups.keys())
    for sig in known_sigs:
        if not sig or sig == "_": continue
        meta = _SIGNAL_META.get(sig, {})
        if not meta: continue
        ps = groups.get(sig, [])
        mode = (meta.get("mode") or default_mode or "quick_100").lower()
        chan = meta.get("channel"); signal_id = meta.get("signal_id")
        target_pips = float(meta.get("target_pips") or 0)

        # --- Shrinkage detection (BUGFIX) ---
        # Track the peak number of positions that were actually FILLED. A limit
        # order that has not triggered yet is NOT a closed position, so it must
        # never count towards "a target was hit". Previously `initial_count`
        # included pending orders, so a signal whose limits had not filled looked
        # like every position had already closed, which instantly cancelled the
        # pendings with reason "<mode>_first_half_hit".
        open_now = len(ps)
        peak = _PEAK_OPEN.get(sig, 0)
        if open_now > peak:
            peak = open_now
            _PEAK_OPEN[sig] = peak
        shrunk = peak > 0 and open_now < peak
        initial = peak
        open_tickets = {int(p.ticket) for p in ps}
        filled_tickets = set(meta.get("filled_tickets") or set())
        missing_filled = filled_tickets - open_tickets
        tp_closed = {
            tk for tk in missing_filled
            if _ticket_closed_by_tp(tk, float(meta.get("opened_at") or 0))
        }

        half_mode = str(meta.get("half_close_mode") or settings.get("half_close_mode") or "auto").lower()
        if half_mode == "manual" and sig not in _HALF_MANAGED and ps:
            trigger_pips = float(meta.get("half_close_pips") or settings.get("half_close_pips") or 40)
            avg_pips = _avg_pips_for_group(ps)
            if avg_pips >= trigger_pips:
                _apply_half_management(sig, ps, "manual_pip_trigger")
                ps = _group_open_positions_by_sig().get(sig, [])

        # Every position carries the signal TP; the mode's pip targets act as
        # group-level profit management on top of it (they never rewrite TPs).
        if mode == "hybrid" and target_pips and ps and sig not in _HALF_MANAGED:
            if _avg_pips_for_group(ps) >= target_pips:
                _apply_half_management(sig, ps, "hybrid_pip_target")
                ps = _group_open_positions_by_sig().get(sig, [])
        if mode == "channel_follow" and ps and sig not in _HALF_MANAGED:
            tp1, tpf = meta.get("channel_tp1"), meta.get("channel_final_tp")
            if tp1 is not None and tpf is not None and abs(float(tp1) - float(tpf)) > 1e-9:
                side0 = meta.get("direction")
                px = current_price(ps[0].symbol, "SELL" if side0 == "BUY" else "BUY")
                if px is not None and ((side0 == "BUY" and px >= float(tp1)) or (side0 == "SELL" and px <= float(tp1))):
                    _apply_half_management(sig, ps, "channel_tp1_reached")
                    ps = _group_open_positions_by_sig().get(sig, [])

        if mode == "scalping":
            avg_pips = _avg_pips_for_group(ps) if ps else 0.0
            triggered = shrunk or (target_pips and avg_pips >= target_pips)
            if triggered and sig not in _ANNOUNCED_TARGETS:
                _ANNOUNCED_TARGETS.add(sig)
                closed = []
                for p in ps:
                    if close_ticket(int(p.ticket)): closed.append(int(p.ticket))
                log_event("target_hit", signal_id, sig, chan,
                          {"mode": mode, "target_pips": target_pips,
                           "avg_pips_remaining": round(avg_pips, 2),
                           "closed_by_watcher": closed})
                for o in _pending_orders_for_sig(sig):
                    cancel_pending_order(int(o.ticket))
                _PENDINGS_CANCELLED.add(sig)
            else:
                _apply_scalping_management(sig, meta, ps, settings)

        elif mode == "quick_100":
            avg_pips = _avg_pips_for_group(ps) if ps else 0.0
            triggered = shrunk or (target_pips and avg_pips >= target_pips)
            if triggered and sig not in _PENDINGS_CANCELLED:
                cancelled = []
                for o in _pending_orders_for_sig(sig):
                    if cancel_pending_order(int(o.ticket)):
                        cancelled.append(int(o.ticket))
                if cancelled:
                    log_event("pending_cancelled", signal_id, sig, chan,
                              {"orders": cancelled, "reason": "quick100_first_hit"})
                _PENDINGS_CANCELLED.add(sig)
            if triggered and sig not in _ANNOUNCED_TARGETS:
                _ANNOUNCED_TARGETS.add(sig)
                closed = [int(p.ticket) for p in ps if close_ticket(int(p.ticket))]
                log_event("target_hit", signal_id, sig, chan,
                          {"mode": mode, "target_pips": target_pips, "initial": initial,
                           "remaining": len(ps), "closed_by_watcher": closed})

        elif mode in ("hybrid", "channel_follow"):
            first_target_tickets = set(meta.get("first_target_filled") or set())
            first_target_count = int(meta.get("first_target_count") or 1)
            confirmed_first_hit = (
                len(tp_closed & first_target_tickets) >= first_target_count
                and first_target_count > 0
            )
            if confirmed_first_hit and sig not in _HYBRID_BE_DONE:
                log_event("target_hit", signal_id, sig, chan,
                          {"mode": mode, "target_pips": target_pips,
                           "initial": initial, "remaining": len(ps),
                           "confirmed_tp_tickets": sorted(tp_closed & first_target_tickets)})
                cancelled = []
                for o in _pending_orders_for_sig(sig):
                    if cancel_pending_order(int(o.ticket)):
                        cancelled.append(int(o.ticket))
                if cancelled:
                    log_event("pending_cancelled", signal_id, sig, chan,
                              {"orders": cancelled, "reason": f"{mode}_first_half_hit"})
                enabled = bool(meta.get("breakeven_enabled", settings.get("breakeven_enabled", True)))
                offset_pips = float(meta.get("breakeven_offset_pips", settings.get("breakeven_offset_pips", 5)) or 0)
                if enabled:
                    for p in ps:
                        offset = offset_pips * pip_size(p.symbol)
                        new_sl = p.price_open + offset if p.type == mt5.POSITION_TYPE_BUY else p.price_open - offset
                        if _improves_stop(p, new_sl) and modify_ticket(int(p.ticket), sl=float(new_sl)):
                            log_event("breakeven_set", signal_id, sig, chan,
                                      {"ticket": int(p.ticket), "new_sl": float(new_sl),
                                       "offset_pips": offset_pips, "mode": mode})
                _HYBRID_BE_DONE.add(sig)




# ---------------- action queue ----------------

def _fetch_my_actions() -> list:
    """Only this account's actions (plus unrouted ones for the main bridge), so an
    offline account's backlog can never block the others."""
    mine = my_account_id()
    q = sb.table("pending_actions").select("*").eq("status", "pending").neq("action", "fetch_channels")
    try:
        if mine and IS_PRIMARY:
            q.params["or"] = f"(payload->>broker_account_id.is.null,payload->>broker_account_id.eq.{mine})"
        elif mine:
            q = q.eq("payload->>broker_account_id", mine)
        return q.order("created_at").limit(20).execute().data or []
    except Exception as e:
        log.warning("filtered action poll failed (%s); using full poll", e)
        rows = (sb.table("pending_actions").select("*").eq("status", "pending")
                .order("created_at").limit(100).execute().data or [])
        return [r for r in rows if r["action"] != "fetch_channels" and _action_is_mine(r.get("payload") or {})]


def _finish(row_id: str, values: dict) -> None:
    bg(lambda: sb.table("pending_actions").update({**values, "processed_at": "now()"}).eq("id", row_id).execute())


def process_actions() -> None:
    rows = _fetch_my_actions()
    # Commands (manage/close) jump the queue: protecting open trades comes first.
    rows.sort(key=lambda r: 0 if r["action"] in ("manage", "close_all", "close") else 1)
    for row in rows:
        if not _action_is_mine(row.get("payload") or {}):
            continue
        claim = (sb.table("pending_actions").update({"status": "processing"}, returning=True)
                 .eq("id", row["id"]).eq("status", "pending").execute())
        if not claim.data:
            continue  # already taken
        try:
            action = row["action"]
            payload = row.get("payload") or {}
            result: dict
            if action == "open":
                allowed, why = copying_allowed()
                if not allowed:
                    log.info("Skipping signal: %s (Brokers page)", why)
                    _finish(row["id"], {"status": "failed", "result": {"skipped": why}, "error": why})
                    continue
                result = handle_open(payload)
                signal_id = payload.get("signal_id")
                if result.get("tickets") and signal_id:
                    bg(lambda sid=signal_id: sb.table("signals").update({"executed": True}).eq("id", sid).execute())
                if not result.get("tickets") and not result.get("layers_watching"):
                    _finish(row["id"], {"status": "failed", "result": result, "error": str(result)[:1000]})
                    log.warning("open produced no orders: %s", result)
                    continue
            elif action == "close":
                ticket = int(payload["ticket"])
                pos = mt5.positions_get(ticket=ticket)
                chan, sig = (None, None)
                if pos: chan, sig = parse_comment(pos[0].comment)
                ok = close_ticket(ticket)
                result = {"closed": ok}
                log_event("manual_close", _SIGNAL_META.get(sig or "", {}).get("signal_id"),
                          sig, chan, {"ticket": ticket, "ok": ok})
            elif action == "close_all":
                n = close_all()
                result = {"closed": n}
                log_event("manual_close_all", None, None, None, {"count": n})
            elif action == "modify":
                ticket = int(payload["ticket"])
                pos = mt5.positions_get(ticket=ticket)
                chan, sig = (None, None)
                if pos: chan, sig = parse_comment(pos[0].comment)
                ok = modify_ticket(ticket, sl=payload.get("sl"), tp=payload.get("tp"))
                result = {"modified": ok}
                log_event("sltp_modified", _SIGNAL_META.get(sig or "", {}).get("signal_id"),
                          sig, chan,
                          {"ticket": ticket, "sl": payload.get("sl"), "tp": payload.get("tp"), "ok": ok})
            elif action == "manage":
                result = handle_manage(payload)
            elif action == "test_signal":
                result = {"dry_run": True}
            elif action == "fetch_symbols":
                syms = mt5.symbols_get() or []
                names = sorted({s.name for s in syms})
                result = {"symbols": names[:500], "count": len(names)}
            else:
                result = {"warning": f"unknown action {action}"}
            _finish(row["id"], {"status": "done", "result": result})
            log.info("action %s done: %s", action, result)
        except Exception as e:
            log.exception("action failed")
            _finish(row["id"], {"status": "failed", "error": str(e)[:1000]})


# ---------------- price feed ----------------

def _utc_now_iso() -> str:
    """PostgREST needs a real ISO timestamp — the string "now()" is not parsed
    by Postgres for a timestamptz column and silently rejects the whole upsert
    (which is why the dashboard price tile stopped updating)."""
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + f".{int((time.time() % 1) * 1000):03d}Z"


def publish_price(symbol: str) -> None:
    if not IS_PRIMARY:
        return None  # shared dashboard tables are owned by the main account bridge
    """Push the live bid/ask of the active instrument to the app (dashboard tile)."""
    tick = mt5.symbol_info_tick(symbol)
    if not tick:
        return
    day_open = day_high = day_low = None
    try:
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_D1, 0, 1)
        if rates is not None and len(rates):
            day_open = float(rates[0]["open"]); day_high = float(rates[0]["high"]); day_low = float(rates[0]["low"])
    except Exception:
        pass
    mid = (float(tick.bid) + float(tick.ask)) / 2
    change_pct = ((mid - day_open) / day_open * 100.0) if day_open else None
    try:
        sb.table("market_prices").upsert({
            "symbol": symbol,
            "bid": float(tick.bid),
            "ask": float(tick.ask),
            "spread_pips": round(price_to_pips(symbol, float(tick.ask) - float(tick.bid)), 2),
            "day_open": day_open, "day_high": day_high, "day_low": day_low,
            "change_pct": round(change_pct, 3) if change_pct is not None else None,
            "tick_at": _utc_now_iso(),
        }, on_conflict="symbol").execute()
    except Exception as e:
        log.debug("price publish failed: %s", e)


# ---------------- main loop ----------------

# Fast lane: how often we look for new orders to execute (seconds).
ACTION_POLL_SEC = 0.05
# Slow lane cadences (seconds).
SYNC_POSITIONS_SEC = 1.0
SYNC_ACCOUNT_SEC = 3.0
PRICE_PUBLISH_SEC = 0.5
HEARTBEAT_SEC = 10.0
HISTORY_SEC = 60.0


def main() -> None:
    while not connect_mt5():
        log.info("Retrying MT5 connect in 30s…")
        heartbeat("offline", {"reason": "no_creds_or_init"})
        time.sleep(30)

    settings = get_settings()
    last_credentials = credentials_signature(settings)
    try:
        reconcile_layers(startup=True)  # recover layers interrupted by a restart, never re-send
    except Exception as e:
        log.warning("startup layer reconcile failed: %s", e)
    now = time.monotonic()
    t_positions = t_account = t_price = t_heartbeat = t_history = t_settings = 0.0

    while True:
        try:
            now = time.monotonic()

            # --- Fast lane: execute queued orders with minimum latency ---
            process_actions()
            try:
                watch_layers()      # instant-mode layers: fill when price reaches them
                reconcile_layers()  # keep layer statuses in step with MT5
            except Exception as e:
                log.warning("layer loop: %s", e)

            # --- Slow lanes ---
            if now - t_settings >= 2.0:
                t_settings = now
                settings = get_settings()
                current_credentials = credentials_signature(settings)
                if current_credentials != last_credentials:
                    log.info("MT5 credentials changed in the app. Reconnecting...")
                    last_credentials = current_credentials
                    if not connect_mt5():
                        time.sleep(5); continue

            if now - t_price >= PRICE_PUBLISH_SEC:
                t_price = now
                sym = resolve_symbol(settings.get("instrument") or SYMBOL_DEFAULT)
                if sym:
                    publish_price(sym)

            if now - t_positions >= SYNC_POSITIONS_SEC:
                t_positions = now
                sync_positions()
                apply_mode_rules(settings.get("trading_mode", "quick_100"))

            if now - t_account >= SYNC_ACCOUNT_SEC:
                t_account = now
                sync_account()

            if now - t_heartbeat >= HEARTBEAT_SEC:
                t_heartbeat = now
                heartbeat("online")

            if now - t_history >= HISTORY_SEC:
                t_history = now
                sync_history()
        except Exception as e:
            log.exception("loop error: %s", e)
            heartbeat("online", {"warning": str(e)})
            time.sleep(1)
        time.sleep(ACTION_POLL_SEC)



if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        heartbeat("offline", {"reason": "stopped"})
        mt5.shutdown()
        log.info("stopped")
    except Exception as e:
        heartbeat("offline", {"reason": str(e)})
        raise
