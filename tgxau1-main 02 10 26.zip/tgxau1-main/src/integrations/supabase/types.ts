export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account: {
        Row: {
          account_type: string | null
          balance: number | null
          currency: string | null
          equity: number | null
          free_margin: number | null
          id: number
          login: string | null
          margin: number | null
          server: string | null
          updated_at: string
        }
        Insert: {
          account_type?: string | null
          balance?: number | null
          currency?: string | null
          equity?: number | null
          free_margin?: number | null
          id?: number
          login?: string | null
          margin?: number | null
          server?: string | null
          updated_at?: string
        }
        Update: {
          account_type?: string | null
          balance?: number | null
          currency?: string | null
          equity?: number | null
          free_margin?: number | null
          id?: number
          login?: string | null
          margin?: number | null
          server?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      account_stats_daily: {
        Row: {
          balance_close: number | null
          broker_account_id: string
          created_at: string
          equity_close: number | null
          id: string
          losses: number | null
          realized_pnl: number | null
          stat_date: string
          trades: number | null
          user_id: string
          wins: number | null
        }
        Insert: {
          balance_close?: number | null
          broker_account_id: string
          created_at?: string
          equity_close?: number | null
          id?: string
          losses?: number | null
          realized_pnl?: number | null
          stat_date: string
          trades?: number | null
          user_id: string
          wins?: number | null
        }
        Update: {
          balance_close?: number | null
          broker_account_id?: string
          created_at?: string
          equity_close?: number | null
          id?: string
          losses?: number | null
          realized_pnl?: number | null
          stat_date?: string
          trades?: number | null
          user_id?: string
          wins?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "account_stats_daily_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      backtest_runs: {
        Row: {
          channel_ids: string[]
          channel_labels: string[] | null
          completed_at: string | null
          created_at: string
          error_message: string | null
          from_date: string
          id: string
          losses: number | null
          signal_count: number | null
          status: string
          to_date: string
          total_pips: number | null
          user_id: string
          win_rate: number | null
          wins: number | null
        }
        Insert: {
          channel_ids?: string[]
          channel_labels?: string[] | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          from_date: string
          id?: string
          losses?: number | null
          signal_count?: number | null
          status?: string
          to_date: string
          total_pips?: number | null
          user_id: string
          win_rate?: number | null
          wins?: number | null
        }
        Update: {
          channel_ids?: string[]
          channel_labels?: string[] | null
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          from_date?: string
          id?: string
          losses?: number | null
          signal_count?: number | null
          status?: string
          to_date?: string
          total_pips?: number | null
          user_id?: string
          win_rate?: number | null
          wins?: number | null
        }
        Relationships: []
      }
      backtest_signals: {
        Row: {
          closed_at: string | null
          created_at: string
          direction: string
          duration_seconds: number | null
          entry: number | null
          events: Json | null
          id: string
          opened_at: string | null
          outcome: string | null
          pips: number | null
          rr: number | null
          run_id: string
          sl: number | null
          symbol: string
          tps: number[] | null
          user_id: string
        }
        Insert: {
          closed_at?: string | null
          created_at?: string
          direction: string
          duration_seconds?: number | null
          entry?: number | null
          events?: Json | null
          id?: string
          opened_at?: string | null
          outcome?: string | null
          pips?: number | null
          rr?: number | null
          run_id: string
          sl?: number | null
          symbol: string
          tps?: number[] | null
          user_id: string
        }
        Update: {
          closed_at?: string | null
          created_at?: string
          direction?: string
          duration_seconds?: number | null
          entry?: number | null
          events?: Json | null
          id?: string
          opened_at?: string | null
          outcome?: string | null
          pips?: number | null
          rr?: number | null
          run_id?: string
          sl?: number | null
          symbol?: string
          tps?: number[] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "backtest_signals_run_id_fkey"
            columns: ["run_id"]
            isOneToOne: false
            referencedRelation: "backtest_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      bridge_heartbeat: {
        Row: {
          last_seen: string
          meta: Json | null
          service: string
          status: string | null
        }
        Insert: {
          last_seen?: string
          meta?: Json | null
          service: string
          status?: string | null
        }
        Update: {
          last_seen?: string
          meta?: Json | null
          service?: string
          status?: string | null
        }
        Relationships: []
      }
      broker_accounts: {
        Row: {
          account_type: string | null
          broker_name: string | null
          copy_enabled: boolean
          created_at: string
          current_balance: number | null
          current_equity: number | null
          health_status: string | null
          id: string
          initial_balance: number | null
          is_active: boolean
          label: string | null
          last_seen_at: string | null
          login: string
          password_encrypted: string | null
          platform: string
          server: string
          terminal_path: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          account_type?: string | null
          broker_name?: string | null
          copy_enabled?: boolean
          created_at?: string
          current_balance?: number | null
          current_equity?: number | null
          health_status?: string | null
          id?: string
          initial_balance?: number | null
          is_active?: boolean
          label?: string | null
          last_seen_at?: string | null
          login: string
          password_encrypted?: string | null
          platform?: string
          server: string
          terminal_path?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          account_type?: string | null
          broker_name?: string | null
          copy_enabled?: boolean
          created_at?: string
          current_balance?: number | null
          current_equity?: number | null
          health_status?: string | null
          id?: string
          initial_balance?: number | null
          is_active?: boolean
          label?: string | null
          last_seen_at?: string | null
          login?: string
          password_encrypted?: string | null
          platform?: string
          server?: string
          terminal_path?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      channel_broker_config: {
        Row: {
          add_new_trade_existing: boolean
          be_enabled: boolean
          be_offset_pips: number
          be_trigger_kind: string
          be_trigger_value: number
          be_type: string
          broker_account_id: string
          channel_id: string
          close_on_opposite_signal: boolean
          created_at: string
          days_filter: Json | null
          dynamic_percent: number
          fixed_lot: number
          id: string
          instruction_map: Json
          max_loss: Json | null
          news_filter: Json | null
          order_comments_enabled: boolean
          override_sl: boolean
          override_tps: boolean
          pending_expiry_hours: number
          profit_targets: Json | null
          reverse_signal: boolean
          risk_mode: string
          rr_fallback_sl: boolean
          rr_fallback_tp: boolean
          single_tp_target: string
          symbol_prefix: string | null
          symbol_suffix: string | null
          symbols_allow: string[] | null
          symbols_avoid: string[] | null
          time_filter: Json | null
          tp_distribution: Json
          trade_style: string
          trailing_stop_enabled: boolean
          updated_at: string
          use_signal_entry: boolean
          user_id: string | null
        }
        Insert: {
          add_new_trade_existing?: boolean
          be_enabled?: boolean
          be_offset_pips?: number
          be_trigger_kind?: string
          be_trigger_value?: number
          be_type?: string
          broker_account_id: string
          channel_id: string
          close_on_opposite_signal?: boolean
          created_at?: string
          days_filter?: Json | null
          dynamic_percent?: number
          fixed_lot?: number
          id?: string
          instruction_map?: Json
          max_loss?: Json | null
          news_filter?: Json | null
          order_comments_enabled?: boolean
          override_sl?: boolean
          override_tps?: boolean
          pending_expiry_hours?: number
          profit_targets?: Json | null
          reverse_signal?: boolean
          risk_mode?: string
          rr_fallback_sl?: boolean
          rr_fallback_tp?: boolean
          single_tp_target?: string
          symbol_prefix?: string | null
          symbol_suffix?: string | null
          symbols_allow?: string[] | null
          symbols_avoid?: string[] | null
          time_filter?: Json | null
          tp_distribution?: Json
          trade_style?: string
          trailing_stop_enabled?: boolean
          updated_at?: string
          use_signal_entry?: boolean
          user_id?: string | null
        }
        Update: {
          add_new_trade_existing?: boolean
          be_enabled?: boolean
          be_offset_pips?: number
          be_trigger_kind?: string
          be_trigger_value?: number
          be_type?: string
          broker_account_id?: string
          channel_id?: string
          close_on_opposite_signal?: boolean
          created_at?: string
          days_filter?: Json | null
          dynamic_percent?: number
          fixed_lot?: number
          id?: string
          instruction_map?: Json
          max_loss?: Json | null
          news_filter?: Json | null
          order_comments_enabled?: boolean
          override_sl?: boolean
          override_tps?: boolean
          pending_expiry_hours?: number
          profit_targets?: Json | null
          reverse_signal?: boolean
          risk_mode?: string
          rr_fallback_sl?: boolean
          rr_fallback_tp?: boolean
          single_tp_target?: string
          symbol_prefix?: string | null
          symbol_suffix?: string | null
          symbols_allow?: string[] | null
          symbols_avoid?: string[] | null
          time_filter?: Json | null
          tp_distribution?: Json
          trade_style?: string
          trailing_stop_enabled?: boolean
          updated_at?: string
          use_signal_entry?: boolean
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "channel_broker_config_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "channel_broker_config_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      channel_brokers: {
        Row: {
          broker_account_id: string
          channel_id: string
          created_at: string
          enabled: boolean
          id: string
          user_id: string | null
        }
        Insert: {
          broker_account_id: string
          channel_id: string
          created_at?: string
          enabled?: boolean
          id?: string
          user_id?: string | null
        }
        Update: {
          broker_account_id?: string
          channel_id?: string
          created_at?: string
          enabled?: boolean
          id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "channel_brokers_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "channel_brokers_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      channel_config_presets: {
        Row: {
          config: Json
          created_at: string
          id: string
          name: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          config?: Json
          created_at?: string
          id?: string
          name: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          config?: Json
          created_at?: string
          id?: string
          name?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      channels: {
        Row: {
          created_at: string
          id: string
          is_selected: boolean
          last_message: string | null
          last_message_at: string | null
          name: string
          username: string | null
        }
        Insert: {
          created_at?: string
          id: string
          is_selected?: boolean
          last_message?: string | null
          last_message_at?: string | null
          name: string
          username?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_selected?: boolean
          last_message?: string | null
          last_message_at?: string | null
          name?: string
          username?: string | null
        }
        Relationships: []
      }
      copier_engine_events: {
        Row: {
          broker_account_id: string | null
          channel_id: string | null
          created_at: string
          id: string
          message: string | null
          status: string
          type: string
          user_id: string
        }
        Insert: {
          broker_account_id?: string | null
          channel_id?: string | null
          created_at?: string
          id?: string
          message?: string | null
          status: string
          type: string
          user_id: string
        }
        Update: {
          broker_account_id?: string | null
          channel_id?: string | null
          created_at?: string
          id?: string
          message?: string | null
          status?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "copier_engine_events_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "copier_engine_events_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      copier_log_events: {
        Row: {
          broker_account_id: string | null
          channel_id: string | null
          created_at: string
          id: string
          message: string | null
          reason: string | null
          status: string
          symbol: string | null
          type: string | null
          user_id: string
        }
        Insert: {
          broker_account_id?: string | null
          channel_id?: string | null
          created_at?: string
          id?: string
          message?: string | null
          reason?: string | null
          status: string
          symbol?: string | null
          type?: string | null
          user_id: string
        }
        Update: {
          broker_account_id?: string | null
          channel_id?: string | null
          created_at?: string
          id?: string
          message?: string | null
          reason?: string | null
          status?: string
          symbol?: string | null
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "copier_log_events_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "copier_log_events_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      execution_audit: {
        Row: {
          broker_account_id: string | null
          broker_login: string | null
          channel_name: string | null
          created_at: string
          detail: Json
          direction: string | null
          error: string | null
          execution_mode: string | null
          id: string
          lot_size: number | null
          order_tickets: number[] | null
          outcome: string | null
          pnl_pips: number | null
          pnl_usd: number | null
          position_tickets: number[] | null
          requested_entry: number[] | null
          sig8: string | null
          signal_id: string | null
          sl: number | null
          status: string
          symbol: string | null
          tps: number[] | null
          trading_mode: string | null
          updated_at: string
        }
        Insert: {
          broker_account_id?: string | null
          broker_login?: string | null
          channel_name?: string | null
          created_at?: string
          detail?: Json
          direction?: string | null
          error?: string | null
          execution_mode?: string | null
          id?: string
          lot_size?: number | null
          order_tickets?: number[] | null
          outcome?: string | null
          pnl_pips?: number | null
          pnl_usd?: number | null
          position_tickets?: number[] | null
          requested_entry?: number[] | null
          sig8?: string | null
          signal_id?: string | null
          sl?: number | null
          status?: string
          symbol?: string | null
          tps?: number[] | null
          trading_mode?: string | null
          updated_at?: string
        }
        Update: {
          broker_account_id?: string | null
          broker_login?: string | null
          channel_name?: string | null
          created_at?: string
          detail?: Json
          direction?: string | null
          error?: string | null
          execution_mode?: string | null
          id?: string
          lot_size?: number | null
          order_tickets?: number[] | null
          outcome?: string | null
          pnl_pips?: number | null
          pnl_usd?: number | null
          position_tickets?: number[] | null
          requested_entry?: number[] | null
          sig8?: string | null
          signal_id?: string | null
          sl?: number | null
          status?: string
          symbol?: string | null
          tps?: number[] | null
          trading_mode?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "execution_audit_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      market_prices: {
        Row: {
          ask: number | null
          bid: number | null
          change_pct: number | null
          day_high: number | null
          day_low: number | null
          day_open: number | null
          spread_pips: number | null
          symbol: string
          tick_at: string
          updated_at: string
        }
        Insert: {
          ask?: number | null
          bid?: number | null
          change_pct?: number | null
          day_high?: number | null
          day_low?: number | null
          day_open?: number | null
          spread_pips?: number | null
          symbol: string
          tick_at?: string
          updated_at?: string
        }
        Update: {
          ask?: number | null
          bid?: number | null
          change_pct?: number | null
          day_high?: number | null
          day_low?: number | null
          day_open?: number | null
          spread_pips?: number | null
          symbol?: string
          tick_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      pending_actions: {
        Row: {
          action: string
          broker_account_id: string | null
          created_at: string
          error: string | null
          id: string
          payload: Json
          processed_at: string | null
          result: Json | null
          status: string
        }
        Insert: {
          action: string
          broker_account_id?: string | null
          created_at?: string
          error?: string | null
          id?: string
          payload?: Json
          processed_at?: string | null
          result?: Json | null
          status?: string
        }
        Update: {
          action?: string
          broker_account_id?: string | null
          created_at?: string
          error?: string | null
          id?: string
          payload?: Json
          processed_at?: string | null
          result?: Json | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "pending_actions_broker_account_id_fkey"
            columns: ["broker_account_id"]
            isOneToOne: false
            referencedRelation: "broker_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      positions: {
        Row: {
          channel_name: string | null
          comment: string | null
          current_price: number | null
          direction: string
          entry_price: number
          instrument: string
          lot_size: number
          mt5_ticket: number
          opened_at: string
          pnl_pips: number | null
          pnl_usd: number | null
          signal_id: string | null
          sl: number | null
          tp: number | null
          updated_at: string
        }
        Insert: {
          channel_name?: string | null
          comment?: string | null
          current_price?: number | null
          direction: string
          entry_price: number
          instrument: string
          lot_size: number
          mt5_ticket: number
          opened_at: string
          pnl_pips?: number | null
          pnl_usd?: number | null
          signal_id?: string | null
          sl?: number | null
          tp?: number | null
          updated_at?: string
        }
        Update: {
          channel_name?: string | null
          comment?: string | null
          current_price?: number | null
          direction?: string
          entry_price?: number
          instrument?: string
          lot_size?: number
          mt5_ticket?: number
          opened_at?: string
          pnl_pips?: number | null
          pnl_usd?: number | null
          signal_id?: string | null
          sl?: number | null
          tp?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      settings: {
        Row: {
          breakeven_enabled: boolean
          breakeven_offset_pips: number
          created_at: string
          execution_mode: string
          half_close_mode: string
          half_close_pips: number
          hybrid_pip_target: number
          id: number
          instrument: string
          layer_tolerance_enabled: boolean
          layer_tolerance_pips: number
          layering_enabled: boolean
          live_enabled: boolean
          lot_size: number
          marginal_entry_enabled: boolean
          marginal_entry_pips: number
          min_confidence: number
          mt5_account_type: string | null
          mt5_connected: boolean
          mt5_login: string | null
          mt5_password: string | null
          mt5_server: string | null
          notifications_enabled: boolean
          position_count: number
          quick_pip_target: number
          scalping_pip_target: number
          scalping_position_count: number
          scalping_time_exit_minutes: number
          scalping_trail_aggressive_multiplier: number
          scalping_trail_be_offset_pips: number
          scalping_trail_ema_period: number
          scalping_trail_enabled: boolean
          scalping_trail_style: string
          setup_completed: boolean
          telegram_api_hash: string | null
          telegram_api_id: string | null
          telegram_connected: boolean
          telegram_phone: string | null
          trading_mode: string
          updated_at: string
          weekly_goal_usd: number
        }
        Insert: {
          breakeven_enabled?: boolean
          breakeven_offset_pips?: number
          created_at?: string
          execution_mode?: string
          half_close_mode?: string
          half_close_pips?: number
          hybrid_pip_target?: number
          id?: number
          instrument?: string
          layer_tolerance_enabled?: boolean
          layer_tolerance_pips?: number
          layering_enabled?: boolean
          live_enabled?: boolean
          lot_size?: number
          marginal_entry_enabled?: boolean
          marginal_entry_pips?: number
          min_confidence?: number
          mt5_account_type?: string | null
          mt5_connected?: boolean
          mt5_login?: string | null
          mt5_password?: string | null
          mt5_server?: string | null
          notifications_enabled?: boolean
          position_count?: number
          quick_pip_target?: number
          scalping_pip_target?: number
          scalping_position_count?: number
          scalping_time_exit_minutes?: number
          scalping_trail_aggressive_multiplier?: number
          scalping_trail_be_offset_pips?: number
          scalping_trail_ema_period?: number
          scalping_trail_enabled?: boolean
          scalping_trail_style?: string
          setup_completed?: boolean
          telegram_api_hash?: string | null
          telegram_api_id?: string | null
          telegram_connected?: boolean
          telegram_phone?: string | null
          trading_mode?: string
          updated_at?: string
          weekly_goal_usd?: number
        }
        Update: {
          breakeven_enabled?: boolean
          breakeven_offset_pips?: number
          created_at?: string
          execution_mode?: string
          half_close_mode?: string
          half_close_pips?: number
          hybrid_pip_target?: number
          id?: number
          instrument?: string
          layer_tolerance_enabled?: boolean
          layer_tolerance_pips?: number
          layering_enabled?: boolean
          live_enabled?: boolean
          lot_size?: number
          marginal_entry_enabled?: boolean
          marginal_entry_pips?: number
          min_confidence?: number
          mt5_account_type?: string | null
          mt5_connected?: boolean
          mt5_login?: string | null
          mt5_password?: string | null
          mt5_server?: string | null
          notifications_enabled?: boolean
          position_count?: number
          quick_pip_target?: number
          scalping_pip_target?: number
          scalping_position_count?: number
          scalping_time_exit_minutes?: number
          scalping_trail_aggressive_multiplier?: number
          scalping_trail_be_offset_pips?: number
          scalping_trail_ema_period?: number
          scalping_trail_enabled?: boolean
          scalping_trail_style?: string
          setup_completed?: boolean
          telegram_api_hash?: string | null
          telegram_api_id?: string | null
          telegram_connected?: boolean
          telegram_phone?: string | null
          trading_mode?: string
          updated_at?: string
          weekly_goal_usd?: number
        }
        Relationships: []
      }
      signal_events: {
        Row: {
          channel_name: string | null
          created_at: string
          detail: Json
          event_type: string
          id: string
          sig8: string | null
          signal_id: string | null
        }
        Insert: {
          channel_name?: string | null
          created_at?: string
          detail?: Json
          event_type: string
          id?: string
          sig8?: string | null
          signal_id?: string | null
        }
        Update: {
          channel_name?: string | null
          created_at?: string
          detail?: Json
          event_type?: string
          id?: string
          sig8?: string | null
          signal_id?: string | null
        }
        Relationships: []
      }
      signal_layers: {
        Row: {
          account_key: string
          broker_account_id: string | null
          channel_name: string | null
          created_at: string
          direction: string
          entry_high: number
          entry_low: number
          error: string | null
          execution_mode: string
          fill_price: number | null
          filled_volume: number | null
          id: string
          layer_no: number
          layer_price: number
          lot_size: number
          order_ticket: number | null
          position_ticket: number | null
          sig8: string | null
          signal_id: string
          sl: number | null
          status: string
          symbol: string
          tolerance_pips: number | null
          total_layers: number
          tp: number | null
          trading_mode: string | null
          updated_at: string
        }
        Insert: {
          account_key: string
          broker_account_id?: string | null
          channel_name?: string | null
          created_at?: string
          direction: string
          entry_high: number
          entry_low: number
          error?: string | null
          execution_mode: string
          fill_price?: number | null
          filled_volume?: number | null
          id?: string
          layer_no: number
          layer_price: number
          lot_size: number
          order_ticket?: number | null
          position_ticket?: number | null
          sig8?: string | null
          signal_id: string
          sl?: number | null
          status?: string
          symbol: string
          tolerance_pips?: number | null
          total_layers: number
          tp?: number | null
          trading_mode?: string | null
          updated_at?: string
        }
        Update: {
          account_key?: string
          broker_account_id?: string | null
          channel_name?: string | null
          created_at?: string
          direction?: string
          entry_high?: number
          entry_low?: number
          error?: string | null
          execution_mode?: string
          fill_price?: number | null
          filled_volume?: number | null
          id?: string
          layer_no?: number
          layer_price?: number
          lot_size?: number
          order_ticket?: number | null
          position_ticket?: number | null
          sig8?: string | null
          signal_id?: string
          sl?: number | null
          status?: string
          symbol?: string
          tolerance_pips?: number | null
          total_layers?: number
          tp?: number | null
          trading_mode?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      signals: {
        Row: {
          channel_id: string | null
          channel_name: string | null
          confidence: number | null
          created_at: string
          direction: string | null
          entry: number[] | null
          entry_type: string | null
          executed: boolean
          id: string
          manual_review: boolean
          parse_reason: string | null
          raw_message: string
          risk: string | null
          sl: number | null
          source_format: string | null
          tp: number[] | null
          tp_type: string | null
          valid: boolean
        }
        Insert: {
          channel_id?: string | null
          channel_name?: string | null
          confidence?: number | null
          created_at?: string
          direction?: string | null
          entry?: number[] | null
          entry_type?: string | null
          executed?: boolean
          id?: string
          manual_review?: boolean
          parse_reason?: string | null
          raw_message: string
          risk?: string | null
          sl?: number | null
          source_format?: string | null
          tp?: number[] | null
          tp_type?: string | null
          valid?: boolean
        }
        Update: {
          channel_id?: string | null
          channel_name?: string | null
          confidence?: number | null
          created_at?: string
          direction?: string | null
          entry?: number[] | null
          entry_type?: string | null
          executed?: boolean
          id?: string
          manual_review?: boolean
          parse_reason?: string | null
          raw_message?: string
          risk?: string | null
          sl?: number | null
          source_format?: string | null
          tp?: number[] | null
          tp_type?: string | null
          valid?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "signals_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      trades: {
        Row: {
          channel_name: string | null
          close_price: number | null
          close_reason: string | null
          closed_at: string | null
          comment: string | null
          direction: string
          entry_price: number
          id: string
          instrument: string
          lot_size: number
          mt5_ticket: number | null
          opened_at: string
          pnl_pips: number | null
          pnl_usd: number | null
          signal_id: string | null
          sl: number | null
          status: string
          tp: number | null
        }
        Insert: {
          channel_name?: string | null
          close_price?: number | null
          close_reason?: string | null
          closed_at?: string | null
          comment?: string | null
          direction: string
          entry_price: number
          id?: string
          instrument?: string
          lot_size: number
          mt5_ticket?: number | null
          opened_at?: string
          pnl_pips?: number | null
          pnl_usd?: number | null
          signal_id?: string | null
          sl?: number | null
          status?: string
          tp?: number | null
        }
        Update: {
          channel_name?: string | null
          close_price?: number | null
          close_reason?: string | null
          closed_at?: string | null
          comment?: string | null
          direction?: string
          entry_price?: number
          id?: string
          instrument?: string
          lot_size?: number
          mt5_ticket?: number | null
          opened_at?: string
          pnl_pips?: number | null
          pnl_usd?: number | null
          signal_id?: string | null
          sl?: number | null
          status?: string
          tp?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trades_signal_id_fkey"
            columns: ["signal_id"]
            isOneToOne: false
            referencedRelation: "signals"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
