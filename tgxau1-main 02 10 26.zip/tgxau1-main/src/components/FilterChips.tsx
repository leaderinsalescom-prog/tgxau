export function FilterChips<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  label?: string;
}) {
  return (
    <div className="flex items-center gap-1.5 text-xs overflow-x-auto pb-1 -mx-1 px-1" role="group" aria-label={label}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          aria-pressed={value === o.value}
          className={`shrink-0 px-3 py-1.5 rounded-full border transition-colors ${
            value === o.value ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function ImpactDot({ impact }: { impact: string }) {
  const cls =
    impact === "High" ? "bg-destructive" : impact === "Medium" ? "bg-warning" : impact === "Holiday" ? "bg-muted-foreground/40" : "bg-success";
  return <span className={`inline-block size-2 rounded-full ${cls}`} title={`${impact} impact`} aria-label={`${impact} impact`} />;
}

export function FeedStatus({
  fetchedAt,
  stale,
  sources,
  isFetching,
  onRefresh,
}: {
  fetchedAt?: string;
  stale?: boolean;
  sources?: { name: string; ok: boolean }[];
  isFetching: boolean;
  onRefresh: () => void;
}) {
  const down = (sources ?? []).filter((s) => !s.ok);
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
      <span className="inline-flex items-center gap-1.5">
        <span className={`size-1.5 rounded-full ${stale ? "bg-warning" : "bg-success"} ${isFetching ? "animate-pulse" : ""}`} />
        {fetchedAt ? `Updated ${new Date(fetchedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "Loading…"}
      </span>
      <button onClick={onRefresh} disabled={isFetching} className="px-2.5 py-1 rounded-md border border-border hover:text-foreground disabled:opacity-50">
        {isFetching ? "Refreshing…" : "Refresh"}
      </button>
      {stale && <span className="text-warning">Sources unavailable — showing last saved data</span>}
      {!stale && down.length > 0 && <span className="text-warning">{down.length} source(s) temporarily unavailable</span>}
    </div>
  );
}
