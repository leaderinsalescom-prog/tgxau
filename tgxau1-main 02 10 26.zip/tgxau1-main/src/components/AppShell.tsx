import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  LineChart,
  History,

  Building2,
  Activity,
  Radio,
  FlaskConical,
  Cpu,
  ScrollText,
  ListChecks,
  BarChart3,
  Newspaper,
  CalendarClock,
  Search,
  Bell,
  Sun,
  Moon,
  Menu,
  ChevronLeft,
  Settings as SettingsIcon,
  Circle,
  CheckCircle2,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useBridgeStatus } from "@/lib/hooks";
import { useTheme } from "@/lib/theme";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type NavItem = { to: string; label: string; icon: any };
type NavGroup = { title: string; items: NavItem[] };

const NAV: NavGroup[] = [
  {
    title: "General",
    items: [
      { to: "/", label: "Dashboard", icon: LayoutDashboard },
      { to: "/brokers", label: "Brokers", icon: Building2 },
      { to: "/trades", label: "Trades", icon: Activity },
      { to: "/positions", label: "Positions", icon: LineChart },
      { to: "/history", label: "History", icon: History },

    ],
  },
  {
    title: "Signals",
    items: [
      { to: "/channels", label: "Channels", icon: Radio },
      { to: "/backtest", label: "Backtest", icon: FlaskConical },
      { to: "/copier-engine", label: "Copier Engine", icon: Cpu },
      { to: "/copier-logs", label: "Copier Logs", icon: ScrollText },
      { to: "/manage-signals", label: "Manage Signals", icon: ListChecks },
      { to: "/performance", label: "Performance", icon: BarChart3 },
    ],
  },
  {
    title: "Trading Tools",
    items: [
      { to: "/market-news", label: "Market News", icon: Newspaper },
      { to: "/economic-calendar", label: "Economic Calendar", icon: CalendarClock },
    ],
  },
];

const STORAGE_KEY = "gc.sidebar";

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    try {
      const v = localStorage.getItem(STORAGE_KEY);
      if (v === "0") setOpen(false);
    } catch {}
  }, []);
  useEffect(() => { setMobileOpen(false); }, [path]);

  const toggle = () => {
    setOpen((o) => {
      const next = !o;
      try { localStorage.setItem(STORAGE_KEY, next ? "1" : "0"); } catch {}
      return next;
    });
  };

  const isActive = (to: string) => (to === "/" ? path === "/" : path === to || path.startsWith(to + "/"));

  return (
    <div className="min-h-dvh flex bg-background">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "hidden md:flex flex-col border-r border-border bg-surface/60 backdrop-blur transition-[width] duration-200",
          open ? "w-64" : "w-16"
        )}
      >
        <SidebarBrand collapsed={!open} onToggle={toggle} />
        <SidebarNav collapsed={!open} isActive={isActive} />
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 flex flex-col border-r border-border bg-surface">
            <SidebarBrand collapsed={false} onToggle={() => setMobileOpen(false)} mobile />
            <SidebarNav collapsed={false} isActive={isActive} />
          </aside>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onMenu={() => setMobileOpen(true)} />
        <main className="flex-1 px-4 md:px-6 py-4 md:py-6 max-w-[1400px] w-full mx-auto">{children}</main>
      </div>
    </div>
  );
}

function SidebarBrand({ collapsed, onToggle, mobile }: { collapsed: boolean; onToggle: () => void; mobile?: boolean }) {
  return (
    <div className="h-14 px-3 flex items-center gap-2 border-b border-border">
      <div className="size-8 rounded-md bg-gold-gradient flex items-center justify-center font-bold text-primary-foreground text-sm shrink-0">GC</div>
      {!collapsed && (
        <div className="flex-1 min-w-0">
          <div className="font-display font-bold text-sm tracking-tight">GoldCopier</div>
          <div className="text-[10px] text-muted-foreground">Pro</div>
        </div>
      )}
      <button
        onClick={onToggle}
        className="ml-auto size-7 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground flex items-center justify-center"
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {mobile ? <ChevronLeft className="size-4" /> : collapsed ? <Menu className="size-4" /> : <ChevronLeft className="size-4" />}
      </button>
    </div>
  );
}

function SidebarNav({ collapsed, isActive }: { collapsed: boolean; isActive: (to: string) => boolean }) {
  return (
    <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-5">
      {NAV.map((group) => (
        <div key={group.title}>
          {!collapsed && (
            <div className="px-2 mb-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground/80 font-medium">{group.title}</div>
          )}
          <ul className="space-y-0.5">
            {group.items.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.to);
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={cn(
                      "group flex items-center gap-3 rounded-md px-2 py-2 text-sm transition-colors",
                      active
                        ? "bg-gold/10 text-gold ring-1 ring-gold/20"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/60",
                      collapsed && "justify-center"
                    )}
                    title={collapsed ? item.label : undefined}
                  >
                    <Icon className={cn("size-4 shrink-0", active && "drop-shadow-[0_0_6px_var(--color-gold)]")} />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
      <div className="pt-2 border-t border-border">
        <Link
          to="/settings"
          className={cn(
            "flex items-center gap-3 rounded-md px-2 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/60",
            collapsed && "justify-center"
          )}
          title={collapsed ? "Settings" : undefined}
        >
          <SettingsIcon className="size-4" />
          {!collapsed && <span>Settings</span>}
        </Link>
      </div>
    </nav>
  );
}

function TopBar({ onMenu }: { onMenu: () => void }) {
  const { theme, toggle } = useTheme();
  const { telegram, mt5 } = useBridgeStatus();
  const running = telegram && mt5;
  const [user, setUser] = useState<{ email?: string | null } | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user ? { email: data.user.email } : null));
  }, []);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data } = await (supabase as any).from("signal_events").select("*").eq("event_type", "entry_filled").order("created_at", { ascending: false }).limit(20);
      if (alive && data) setNotifications(data);
    };
    load();
    const channel = supabase.channel(`filled-notifications-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes" as any, { event: "INSERT", schema: "public", table: "signal_events", filter: "event_type=eq.entry_filled" }, (payload: any) => {
        if (!alive) return;
        setNotifications((current) => [payload.new, ...current].slice(0, 20));
      }).subscribe();
    return () => { alive = false; supabase.removeChannel(channel); };
  }, []);

  return (
    <header className="sticky top-0 z-30 h-14 border-b border-border bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <div className="h-full px-4 md:px-6 flex items-center gap-3">
        <button
          onClick={onMenu}
          className="md:hidden size-9 rounded-md hover:bg-muted text-muted-foreground flex items-center justify-center"
          aria-label="Open menu"
        >
          <Menu className="size-5" />
        </button>

        <StatusPill running={running} />

        <div className="hidden sm:flex flex-1 max-w-md ml-2">
          <div className="relative w-full">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <input
              type="search"
              placeholder="Search…"
              className="w-full h-9 pl-8 pr-3 rounded-md bg-muted/40 border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-gold/40"
            />
          </div>
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          <ConnDot label="TG" on={telegram} />
          <ConnDot label="MT" on={mt5} />
          <button
            onClick={toggle}
            className="size-9 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground flex items-center justify-center"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </button>
          <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setNotificationsOpen((value) => !value)}
            className="relative text-muted-foreground hover:text-foreground"
            aria-label="Notifications"
          >
            <Bell className="size-4" />
            {notifications.length > 0 && <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-success ring-2 ring-background" />}
          </Button>
          {notificationsOpen && (
            <div className="absolute right-0 top-11 z-50 w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-xl">
              <div className="flex items-center justify-between border-b border-border px-4 py-3">
                <div><div className="text-sm font-semibold">Executed signals</div><div className="text-[10px] text-muted-foreground">Latest MT5 fills</div></div>
                <span className="text-xs tabular text-muted-foreground">{notifications.length}</span>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? <div className="p-6 text-center text-sm text-muted-foreground">No executed signals yet.</div> : notifications.map((item) => (
                  <div key={item.id} className="border-b border-border/60 px-4 py-3 last:border-0">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2"><span className="truncate text-xs font-semibold">{item.channel_name ?? "Signal executed"}</span><span className="shrink-0 text-[10px] text-muted-foreground">{new Date(item.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span></div>
                        <div className="mt-1 text-[11px] text-muted-foreground tabular">#{item.detail?.ticket ?? "—"} · {item.detail?.kind ?? "filled"} · {item.detail?.lot ?? "—"} lot</div>
                        <div className="mt-0.5 text-[10px] text-muted-foreground tabular">SL {item.detail?.sl ?? "—"} · TP {item.detail?.tp ?? "—"}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
          <div className="hidden sm:flex items-center gap-2 pl-2 ml-1 border-l border-border">
            <div className="size-8 rounded-full bg-gold-gradient flex items-center justify-center text-xs font-bold text-primary-foreground">
              {(user?.email?.[0] ?? "G").toUpperCase()}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

function StatusPill({ running }: { running: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium border",
        running
          ? "border-success/40 bg-success/10 text-success"
          : "border-warning/40 bg-warning/10 text-warning"
      )}
    >
      <Circle className={cn("size-2 fill-current", running && "animate-pulse")} />
      Copier {running ? "Running" : "Idle"}
    </span>
  );
}

function ConnDot({ label, on }: { label: string; on: boolean }) {
  return (
    <span className="hidden md:flex items-center gap-1 text-[10px] text-muted-foreground px-1.5">
      <span className={cn("size-1.5 rounded-full", on ? "bg-success shadow-[0_0_6px_var(--color-success)]" : "bg-destructive/70")} />
      {label}
    </span>
  );
}
