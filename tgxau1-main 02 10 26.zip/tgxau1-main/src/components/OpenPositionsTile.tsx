import { Link } from "@tanstack/react-router";
import { useRealtimeRows } from "@/lib/hooks";
import type { Position } from "@/lib/types";
import { fmtUSD, fmtPips, pnlClass, fmtDateAST } from "@/lib/format";
import { ArrowRight, LineChart } from "lucide-react";

/** Compact open-positions tile for the dashboard. */
export function OpenPositionsTile() {
  const positions = useRealtimeRows<Position>("positions", { col: "opened_at" });
  const totalPnl = positions.reduce((s, p) => s + (p.pnl_usd ?? 0), 0);
  const totalPips = positions.reduce((s, p) => s + (p.pnl_pips ?? 0), 0);

  return (
    <div className="surface-card p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold flex items-center gap-2">
          <LineChart className="size-4 text-gold" /> Open Positions
          <span className="text-[10px] text-muted-foreground">({positions.length})</span>
        </h2>
        <Link to="/positions" className="text-xs text-gold flex items-center gap-1">Manage <ArrowRight className="size-3" /></Link>
      </div>

      {positions.length === 0 ? (
        <div className="text-center text-sm text-muted-foreground py-6">No open positions right now.</div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 mb-3">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Open P&L</div>
              <div className={`text-2xl font-bold tabular ${pnlClass(totalPnl)}`}>{fmtUSD(totalPnl, { sign: true })}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Combined Pips</div>
              <div className={`text-2xl font-bold tabular ${pnlClass(totalPips)}`}>{fmtPips(totalPips)}</div>
            </div>
          </div>
          <ul className="space-y-1.5 max-h-64 overflow-auto">
            {positions.map((p) => (
              <li key={p.mt5_ticket} className="flex items-center justify-between gap-2 rounded-md border border-border/70 bg-background/40 px-2.5 py-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-xs">
                    <span className={`font-semibold ${p.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg"}`}>{p.direction}</span>
                    <span className="tabular">{p.instrument}</span>
                    <span className="text-[10px] text-muted-foreground">{p.lot_size} lot</span>
                  </div>
                  <div className="text-[10px] text-muted-foreground tabular truncate">
                    @{p.entry_price.toFixed(2)} · SL {p.sl?.toFixed(2) ?? "—"} · TP {p.tp?.toFixed(2) ?? "—"} · {fmtDateAST(p.opened_at)}
                  </div>
                </div>
                <div className={`text-right tabular shrink-0 ${pnlClass(p.pnl_usd)}`}>
                  <div className="text-xs font-bold">{fmtUSD(p.pnl_usd, { sign: true })}</div>
                  <div className="text-[10px]">{fmtPips(p.pnl_pips)}</div>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
