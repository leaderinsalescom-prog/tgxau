import { AppShell } from "@/components/AppShell";
import type { LucideIcon } from "lucide-react";

export function StubPage({
  title,
  description,
  icon: Icon,
  children,
}: {
  title: string;
  description?: string;
  icon: LucideIcon;
  children?: React.ReactNode;
}) {
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20">
            <Icon className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">{title}</h1>
            {description && <p className="text-sm text-muted-foreground mt-0.5">{description}</p>}
          </div>
        </div>
        {children ?? (
          <div className="surface-card p-10 text-center">
            <p className="text-sm text-muted-foreground">Coming soon.</p>
            <p className="text-xs text-muted-foreground/70 mt-1">This section is scaffolded and will be built next.</p>
          </div>
        )}
      </div>
    </AppShell>
  );
}
