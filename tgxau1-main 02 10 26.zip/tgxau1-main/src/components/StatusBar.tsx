import { useEffect, useState } from "react";
import { currentSession, fmtAST } from "@/lib/format";
import { useBridgeStatus } from "@/lib/hooks";

export function StatusBar() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const session = currentSession(now ?? new Date(0));
  const { telegram, mt5 } = useBridgeStatus();
  return (
    <header className="sticky top-0 z-20 backdrop-blur bg-background/80 border-b border-border">
      <div className="max-w-3xl mx-auto px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 font-display">
          <span className="font-bold tracking-tight text-base bg-gold-gradient px-2 py-0.5 rounded-md">GC</span>
          <span className="text-foreground/90 font-semibold hidden sm:inline">GoldCopier Pro</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 text-muted-foreground tabular">
          {now && <SessionPill name={session.name} open={session.open} />}
          <Dot label="TG" on={telegram} />
          <Dot label="MT5" on={mt5} />
          <span suppressHydrationWarning className="hidden xs:inline text-[10px]">{now ? fmtAST(now) : ""}</span>
        </div>
      </div>
    </header>
  );
}

function SessionPill({ name, open }: { name: string; open: boolean }) {
  return (
    <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${open ? "border-success/40 text-success bg-success/5" : "border-border text-muted-foreground bg-muted/30"}`}>
      {open ? "● " : "○ "}{name}
    </span>
  );
}
function Dot({ label, on }: { label: string; on: boolean }) {
  return (
    <span className="flex items-center gap-1 text-[10px]">
      <span className={`size-1.5 rounded-full ${on ? "bg-success shadow-[0_0_6px_var(--color-success)]" : "bg-destructive/70"}`} />
      {label}
    </span>
  );
}
