import { useMemo, useState } from "react";
import { useRealtimeRows } from "@/lib/hooks";
import { fmtDateAST } from "@/lib/format";
import type { Signal } from "@/lib/types";
import { RangeTabs } from "@/components/RangeTabs";
import { inRange, type Range } from "@/lib/range";
import { ChevronDown } from "lucide-react";

type Kind = "EXECUTED" | "REVIEW" | "UPDATE" | "SKIPPED";

function kindOf(s: Signal): Kind {
  if (s.executed) return "EXECUTED";
  if (s.valid && s.manual_review) return "REVIEW";
  if (!s.valid && (s.parse_reason ?? "").startsWith("management_command")) return "UPDATE";
  if (s.valid) return "REVIEW";
  return "SKIPPED";
}

const KIND_CLS: Record<Kind, string> = {
  EXECUTED: "bg-success/15 text-success",
  REVIEW: "bg-gold/15 text-gold",
  UPDATE: "bg-blue-500/15 text-blue-400",
  SKIPPED: "bg-muted text-muted-foreground",
};

/** Recent signals feed (all channels) with Today / 7d / 30d / All-time filters. */
export function SignalsFeed() {
  const signals = useRealtimeRows<Signal>("signals", { col: "created_at" }, 2000);
  const [range, setRange] = useState<Range>("today");
  const [kind, setKind] = useState<Kind | "ALL">("ALL");
  const [openId, setOpenId] = useState<string | null>(null);

  const visible = useMemo(() => {
    const inWindow = signals.filter((s) => inRange(s.created_at, range));
    return kind === "ALL" ? inWindow : inWindow.filter((s) => kindOf(s) === kind);
  }, [signals, range, kind]);

  const counts = useMemo(() => {
    const inWindow = signals.filter((s) => inRange(s.created_at, range));
    const c: Record<Kind, number> = { EXECUTED: 0, REVIEW: 0, UPDATE: 0, SKIPPED: 0 };
    inWindow.forEach((s) => { c[kindOf(s)]++; });
    return { ...c, total: inWindow.length };
  }, [signals, range]);

  return (
    <div className="space-y-4">
      <RangeTabs value={range} onChange={setRange} />

      <div className="surface-card p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
        <Metric label="Signals" value={String(counts.total)} />
        <Metric label="Executed" value={String(counts.EXECUTED)} cls="text-success" />
        <Metric label="Updates" value={String(counts.UPDATE)} cls="text-blue-400" />
        <Metric label="Skipped" value={String(counts.SKIPPED)} cls="text-muted-foreground" />
      </div>

      <div className="flex gap-1.5 text-xs overflow-x-auto pb-1 -mx-1 px-1">
        {(["ALL", "EXECUTED", "REVIEW", "UPDATE", "SKIPPED"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setKind(k)}
            className={`shrink-0 px-3 py-1.5 rounded-full border transition-colors ${
              kind === k ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {k === "ALL" ? "All" : k.charAt(0) + k.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="surface-card p-10 text-center text-sm text-muted-foreground">No signals in this range.</div>
      ) : (
        <div className="space-y-2">
          {visible.map((s) => {
            const k = kindOf(s);
            const open = openId === s.id;
            return (
              <div key={s.id} className="surface-card p-3 space-y-2">
                <button className="w-full text-left" onClick={() => setOpenId(open ? null : s.id)}>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${KIND_CLS[k]}`}>{k}</span>
                      {s.direction && (
                        <span className={`text-xs font-semibold ${s.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg"}`}>{s.direction}</span>
                      )}
                      {s.channel_name && (
                        <span className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-medium truncate max-w-[150px]">{s.channel_name}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0">
                      <span>{fmtDateAST(s.created_at)}</span>
                      <ChevronDown className={`size-3 transition-transform ${open ? "rotate-180" : ""}`} />
                    </div>
                  </div>
                  <div className="text-[11px] text-muted-foreground tabular mt-1 line-clamp-1">
                    {s.valid
                      ? `Entry ${s.entry?.join("/") ?? "—"} · SL ${s.sl ?? "—"} · TP ${s.tp?.join("/") ?? "—"}${s.confidence != null ? ` · conf ${s.confidence.toFixed(2)}` : ""}`
                      : s.parse_reason ?? "not a signal"}
                  </div>
                </button>
                {open && (
                  <pre className="text-[11px] whitespace-pre-wrap break-words rounded border border-border/60 bg-muted/30 p-2">{s.raw_message}</pre>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Metric({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className={`text-xl font-bold tabular ${cls ?? ""}`}>{value}</div>
    </div>
  );
}
