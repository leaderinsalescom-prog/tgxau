import { useEffect, useMemo, useRef, useState } from "react";
import { CandlestickChart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const db = supabase as any;
const uid = () => Math.random().toString(36).slice(2, 9);

export type Candle = { t: number; o: number; h: number; l: number; c: number };

const TIMEFRAMES = [
  { key: "10s", label: "10s", ms: 10_000 },
  { key: "1m", label: "1m", ms: 60_000 },
  { key: "5m", label: "5m", ms: 300_000 },
  { key: "15m", label: "15m", ms: 900_000 },
] as const;

type TfKey = (typeof TIMEFRAMES)[number]["key"];

type Tick = { t: number; p: number };

const MAX_TICKS = 4000;

function storageKey(symbol: string) {
  return `gc.ticks.${symbol.toUpperCase()}`;
}

function loadTicks(symbol: string): Tick[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(storageKey(symbol));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const cutoff = Date.now() - 6 * 60 * 60 * 1000;
    return parsed.filter((x: any) => typeof x?.t === "number" && typeof x?.p === "number" && x.t > cutoff).slice(-MAX_TICKS);
  } catch {
    return [];
  }
}

function saveTicks(symbol: string, ticks: Tick[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(storageKey(symbol), JSON.stringify(ticks.slice(-MAX_TICKS)));
  } catch {
    /* quota — ignore */
  }
}

/** Streams mid-price ticks for one symbol straight off the realtime feed. */
export function useLiveTicks(symbol: string) {
  const [ticks, setTicks] = useState<Tick[]>([]);
  const pending = useRef<Tick[]>([]);
  const target = symbol.toUpperCase();

  useEffect(() => {
    let alive = true;
    setTicks(loadTicks(target));

    const push = (row: any) => {
      if (!row) return;
      const sym = String(row.symbol ?? "").toUpperCase();
      if (sym !== target && !sym.startsWith(target)) return;
      const bid = Number(row.bid);
      const ask = Number(row.ask);
      const mid = Number.isFinite(bid) && Number.isFinite(ask) ? (bid + ask) / 2 : Number.isFinite(bid) ? bid : NaN;
      if (!Number.isFinite(mid)) return;
      const t = row.tick_at ? new Date(row.tick_at).getTime() : Date.now();
      if (!Number.isFinite(t)) return;
      pending.current.push({ t, p: mid });
    };

    const flush = () => {
      if (!alive || pending.current.length === 0) return;
      const batch = pending.current;
      pending.current = [];
      setTicks((prev) => {
        const last = prev.length ? prev[prev.length - 1].t : 0;
        const next = prev.concat(batch.filter((x) => x.t >= last)).slice(-MAX_TICKS);
        saveTicks(target, next);
        return next;
      });
    };

    (async () => {
      const { data } = await db.from("market_prices").select("*").limit(30);
      if (!alive) return;
      (data ?? []).forEach(push);
      flush();
    })();

    const interval = window.setInterval(flush, 250);
    const ch = supabase
      .channel(`px-${uid()}`)
      .on("postgres_changes" as any, { event: "*", schema: "public", table: "market_prices" }, (payload: any) =>
        push(payload.new),
      )
      .subscribe();

    return () => {
      alive = false;
      window.clearInterval(interval);
      supabase.removeChannel(ch);
    };
  }, [target]);

  return ticks;
}

export function buildCandles(ticks: Tick[], bucketMs: number, max = 90): Candle[] {
  const out: Candle[] = [];
  for (const tick of ticks) {
    const bucket = Math.floor(tick.t / bucketMs) * bucketMs;
    const last = out[out.length - 1];
    if (last && last.t === bucket) {
      last.h = Math.max(last.h, tick.p);
      last.l = Math.min(last.l, tick.p);
      last.c = tick.p;
    } else {
      out.push({ t: bucket, o: tick.p, h: tick.p, l: tick.p, c: tick.p });
    }
  }
  return out.slice(-max);
}

export function LiveChartTile({ instrument }: { instrument?: string | null }) {
  const symbol = (instrument || "XAUUSD").toUpperCase();
  const ticks = useLiveTicks(symbol);
  const [tf, setTf] = useState<TfKey>("1m");
  const bucketMs = TIMEFRAMES.find((f) => f.key === tf)!.ms;
  const candles = useMemo(() => buildCandles(ticks, bucketMs), [ticks, bucketMs]);

  const last = candles[candles.length - 1];
  const first = candles[0];
  const change = last && first ? last.c - first.o : 0;
  const up = change >= 0;

  return (
    <section className="surface-card p-4" aria-label="Live price chart">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <CandlestickChart className="size-4 text-gold" />
            <h2 className="text-sm font-semibold">{symbol} live chart</h2>
          </div>
          <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
            Built from the MT5 tick stream · {candles.length} bars
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-md bg-muted/40 p-0.5">
          {TIMEFRAMES.map((f) => (
            <button
              key={f.key}
              type="button"
              onClick={() => setTf(f.key)}
              className={`rounded px-2 py-1 text-[11px] font-medium transition ${
                tf === f.key ? "bg-gold/15 text-gold" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <span className="text-2xl font-bold tabular">{last ? last.c.toFixed(last.c >= 100 ? 2 : 5) : "—"}</span>
        <span className={`text-xs font-medium ${up ? "text-success" : "text-destructive"}`}>
          {last && first ? `${up ? "+" : ""}${change.toFixed(2)}` : "waiting for ticks"}
        </span>
      </div>

      <CandleCanvas candles={candles} />

      {candles.length === 0 && (
        <p className="mt-2 text-xs text-muted-foreground">
          No quotes yet — the chart fills in as soon as the MT5 bridge publishes prices.
        </p>
      )}
    </section>
  );
}

function CandleCanvas({ candles }: { candles: Candle[] }) {
  const width = 640;
  const height = 240;
  const padX = 8;
  const padY = 10;

  if (candles.length === 0) {
    return <div className="mt-3 h-[240px] rounded-md border border-dashed border-border/70" aria-hidden />;
  }

  const highs = candles.map((c) => c.h);
  const lows = candles.map((c) => c.l);
  let max = Math.max(...highs);
  let min = Math.min(...lows);
  if (max === min) {
    max += 0.5;
    min -= 0.5;
  }
  const span = max - min;
  const step = (width - padX * 2) / Math.max(candles.length, 1);
  const bodyW = Math.max(1.5, Math.min(10, step * 0.6));
  const y = (v: number) => padY + ((max - v) / span) * (height - padY * 2);

  return (
    <div className="mt-3">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-[240px]" role="img" aria-label="Candlestick chart">
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <line
            key={f}
            x1={0}
            x2={width}
            y1={padY + f * (height - padY * 2)}
            y2={padY + f * (height - padY * 2)}
            stroke="var(--color-border)"
            strokeDasharray="3 3"
            strokeWidth={0.6}
          />
        ))}
        {candles.map((c, i) => {
          const cx = padX + i * step + step / 2;
          const bull = c.c >= c.o;
          const color = bull ? "var(--color-success)" : "var(--color-destructive)";
          const top = y(Math.max(c.o, c.c));
          const bottom = y(Math.min(c.o, c.c));
          return (
            <g key={c.t}>
              <line x1={cx} x2={cx} y1={y(c.h)} y2={y(c.l)} stroke={color} strokeWidth={0.8} />
              <rect
                x={cx - bodyW / 2}
                y={top}
                width={bodyW}
                height={Math.max(1, bottom - top)}
                fill={color}
                rx={0.8}
              />
            </g>
          );
        })}
        <line
          x1={0}
          x2={width}
          y1={y(candles[candles.length - 1].c)}
          y2={y(candles[candles.length - 1].c)}
          stroke="var(--color-gold)"
          strokeWidth={0.8}
          strokeDasharray="4 3"
        />
      </svg>
      <div className="flex justify-between text-[10px] text-muted-foreground">
        <span>{new Date(candles[0].t).toLocaleTimeString()}</span>
        <span>{min.toFixed(2)} – {max.toFixed(2)}</span>
        <span>{new Date(candles[candles.length - 1].t).toLocaleTimeString()}</span>
      </div>
    </div>
  );
}
