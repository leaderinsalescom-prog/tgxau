import { Activity, ArrowDownRight, ArrowUpRight, Clock3 } from "lucide-react";
import { useMemo } from "react";
import { useRealtimeRows } from "@/lib/hooks";

type MarketPrice = {
  symbol: string;
  bid: number | null;
  ask: number | null;
  spread_pips: number | null;
  day_high: number | null;
  day_low: number | null;
  change_pct: number | null;
  tick_at: string;
};

export function LivePriceTile({ instrument }: { instrument?: string | null }) {
  const prices = useRealtimeRows<MarketPrice>("market_prices", { col: "tick_at" }, 30);
  const price = useMemo(() => {
    const requested = (instrument || "XAUUSD").toUpperCase();
    return prices.find((row) => row.symbol.toUpperCase() === requested)
      ?? prices.find((row) => row.symbol.toUpperCase().startsWith(requested))
      ?? prices[0];
  }, [instrument, prices]);
  const fresh = price ? Date.now() - new Date(price.tick_at).getTime() < 5_000 : false;
  const up = (price?.change_pct ?? 0) >= 0;
  const ChangeIcon = up ? ArrowUpRight : ArrowDownRight;

  return (
    <section className="surface-card p-4" aria-label="Live market price">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="size-4 text-gold" />
            <h2 className="text-sm font-semibold">{price?.symbol ?? instrument ?? "XAUUSD"}</h2>
            <span className={`size-1.5 rounded-full ${fresh ? "bg-success animate-pulse" : "bg-warning"}`} />
          </div>
          <p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">Live MT5 quote</p>
        </div>
        <div className={`flex items-center gap-1 text-xs font-medium ${up ? "text-success" : "text-destructive"}`}>
          <ChangeIcon className="size-3.5" />
          {price?.change_pct == null ? "—" : `${price.change_pct >= 0 ? "+" : ""}${price.change_pct.toFixed(2)}%`}
        </div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-4">
        <Quote label="Bid" value={price?.bid} />
        <Quote label="Ask" value={price?.ask} />
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 border-t border-border/70 pt-3 text-xs">
        <SmallStat label="Spread" value={price?.spread_pips == null ? "—" : `${price.spread_pips.toFixed(1)} pips`} />
        <SmallStat label="Low" value={formatPrice(price?.day_low)} />
        <SmallStat label="High" value={formatPrice(price?.day_high)} />
      </div>
      <div className="mt-3 flex items-center gap-1 text-[10px] text-muted-foreground">
        <Clock3 className="size-3" /> {price ? new Date(price.tick_at).toLocaleTimeString() : "Waiting for MT5 quote"}
      </div>
    </section>
  );
}

function formatPrice(value?: number | null) {
  return value == null ? "—" : value.toFixed(value >= 100 ? 2 : 5);
}

function Quote({ label, value }: { label: string; value?: number | null }) {
  return <div><div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1 text-2xl font-bold tabular">{formatPrice(value)}</div></div>;
}

function SmallStat({ label, value }: { label: string; value: string }) {
  return <div><div className="text-[9px] uppercase text-muted-foreground">{label}</div><div className="mt-0.5 tabular">{value}</div></div>;
}