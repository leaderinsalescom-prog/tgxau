import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Channel } from "@/lib/types";
import { CheckCircle2, Loader2, AlertCircle, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const db = supabase as any;

export function ChannelPicker({ compact = false }: { compact?: boolean }) {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [requesting, setRequesting] = useState(false);
  const [note, setNote] = useState("");

  const load = async () => {
    const { data } = await db.from("channels").select("*").order("name");
    setChannels((data as Channel[]) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const ch = db
      .channel(`cp-${Math.random().toString(36).slice(2, 8)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "channels" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const refresh = async () => {
    setRequesting(true);
    setNote("");
    const { data, error } = await db.from("pending_actions").insert({ action: "fetch_channels" }).select("id").single();
    if (error) { setRequesting(false); return toast.error(error.message); }
    toast.info("Asked Telegram listener to refresh channels…");
    const actionId = data?.id;
    for (let i = 0; i < 30; i += 1) {
      await new Promise((r) => setTimeout(r, 2000));
      await load();
      const { data: a } = await db.from("pending_actions").select("status,result,error").eq("id", actionId).maybeSingle();
      if (a?.status === "done") { setNote(`Refreshed ${a.result?.channels ?? channels.length} channels.`); setRequesting(false); return; }
      if (a?.status === "failed") { setRequesting(false); return toast.error(a.error || "Telegram refresh failed."); }
    }
    setRequesting(false);
    setNote("Still waiting — keep the Telegram listener running on the VPS.");
  };

  const toggle = async (c: Channel) => {
    // optimistic
    setChannels((prev) => prev.map((x) => (x.id === c.id ? { ...x, is_selected: !x.is_selected } : x)));
    const { error } = await db.from("channels").update({ is_selected: !c.is_selected }).eq("id", c.id);
    if (error) { toast.error(error.message); load(); }
  };

  const selected = channels.filter((c) => c.is_selected).length;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          {requesting ? "Refreshing…" : `${selected} selected · ${channels.length} total`}
        </span>
        <button
          onClick={refresh}
          disabled={requesting}
          className="text-xs text-primary flex items-center gap-1 disabled:opacity-50"
        >
          <RefreshCw className={`size-3 ${requesting ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>
      {note && <div className="text-[11px] text-muted-foreground">{note}</div>}

      {loading ? (
        <div className="py-6 text-center text-muted-foreground text-sm">
          <Loader2 className="size-5 animate-spin inline" />
        </div>
      ) : channels.length === 0 ? (
        <div className="rounded-lg border border-border/60 bg-muted/40 p-4 text-center text-xs text-muted-foreground">
          <AlertCircle className="size-4 mx-auto mb-1 text-warning" />
          No channels yet. Start the Telegram listener on your VPS.
        </div>
      ) : (
        <ul className={`space-y-1.5 overflow-y-auto ${compact ? "max-h-64" : "max-h-96"}`}>
          {channels.map((c) => (
            <li key={c.id}>
              <button
                onClick={() => toggle(c)}
                className={`w-full text-left p-2.5 rounded-lg border transition-all ${
                  c.is_selected
                    ? "border-primary/60 bg-primary/5"
                    : "border-border bg-card hover:bg-accent"
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`size-4 rounded border-2 flex items-center justify-center ${c.is_selected ? "border-primary bg-primary" : "border-border"}`}>
                    {c.is_selected && <CheckCircle2 className="size-3 text-primary-foreground" />}
                  </div>
                  <span className="font-medium text-sm truncate">{c.name}</span>
                  {c.username && <span className="text-[10px] text-muted-foreground">@{c.username}</span>}
                </div>
                {c.last_message && !compact && (
                  <div className="text-[11px] text-muted-foreground mt-1 line-clamp-1 pl-6">"{c.last_message}"</div>
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
