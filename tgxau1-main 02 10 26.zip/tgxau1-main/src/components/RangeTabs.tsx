import { RANGES, RANGE_LABELS, type Range } from "@/lib/range";

export function RangeTabs({ value, onChange }: { value: Range; onChange: (r: Range) => void }) {
  return (
    <div className="flex gap-1.5 text-xs overflow-x-auto pb-1 -mx-1 px-1">
      {RANGES.map((r) => (
        <button
          key={r}
          onClick={() => onChange(r)}
          className={`shrink-0 px-3 py-1.5 rounded-full border transition-colors ${
            value === r ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          {RANGE_LABELS[r]}
        </button>
      ))}
    </div>
  );
}
