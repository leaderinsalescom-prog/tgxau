import { useRealtimeRows } from "@/lib/hooks";
import { fmtDateAST } from "@/lib/format";
import { useMemo, useState } from "react";
import { CheckCircle2, XCircle, Target, Shield, Hand, Ban, Clock, ChevronRight } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import type { Signal, Trade } from "@/lib/types";
import { RangeTabs } from "@/components/RangeTabs";
import { inRange, type Range } from "@/lib/range";

export type SignalEvent = {
  id: string;
  signal_id: string | null;
  sig8: string | null;
  channel_name: string | null;
  event_type: string;
  detail: Record<string, any>;
  created_at: string;
};

const ICONS: Record<string, any> = {
  entry_filled: CheckCircle2,
  entry_placed: Clock,
  entry_skipped: XCircle,
  target_hit: Target,
  breakeven_set: Shield,
  pending_cancelled: Ban,
  manual_close: Hand,
  manual_close_all: Hand,
  sltp_modified: Shield,
};

const COLORS: Record<string, string> = {
  entry_filled: "text-success",
  entry_placed: "text-muted-foreground",
  entry_skipped: "text-warning",
  target_hit: "text-gold",
  breakeven_set: "text-blue-400",
  pending_cancelled: "text-muted-foreground",
  manual_close: "text-foreground",
  manual_close_all: "text-foreground",
  sltp_modified: "text-foreground",
};

type Group = { key: string; signal_id: string | null; channel: string | null; events: SignalEvent[]; last: string };

/**
 * Full signal audit log (grouped lifecycle events + detail drawer) with
 * Today / 7d / 30d / All-time filtering.
 */
export function AuditLog() {
  const events = useRealtimeRows<SignalEvent>("signal_events", { col: "created_at" }, 3000);
  const signals = useRealtimeRows<Signal>("signals", { col: "created_at" }, 2000);
  const trades = useRealtimeRows<Trade>("trades", { col: "opened_at" }, 2000);
  const [openKey, setOpenKey] = useState<string | null>(null);
  const [range, setRange] = useState<Range>("today");

  const groups = useMemo<Group[]>(() => {
    const map = new Map<string, Group>();
    for (const e of events) {
      const key = e.signal_id || e.sig8 || `_${e.id}`;
      const g = map.get(key) || { key, signal_id: e.signal_id, channel: e.channel_name, events: [], last: e.created_at };
      g.events.push(e);
      if (e.created_at > g.last) g.last = e.created_at;
      g.channel = g.channel || e.channel_name;
      g.signal_id = g.signal_id || e.signal_id;
      map.set(key, g);
    }
    return Array.from(map.values()).sort((a, b) => b.last.localeCompare(a.last));
  }, [events]);

  const visible = useMemo(() => groups.filter((g) => inRange(g.last, range)), [groups, range]);

  const stats = useMemo(() => {
    const ids = new Set(visible.map((g) => g.signal_id).filter(Boolean) as string[]);
    const rel = trades.filter((t) => t.signal_id && ids.has(t.signal_id));
    const pnl = rel.reduce((s, t) => s + (t.pnl_usd ?? 0), 0);
    const filled = visible.filter((g) => g.events.some((e) => e.event_type === "entry_filled")).length;
    const skipped = visible.filter((g) => g.events.some((e) => e.event_type === "entry_skipped")).length;
    return { count: visible.length, filled, skipped, pnl };
  }, [visible, trades]);

  const active = openKey ? groups.find((g) => g.key === openKey) : null;
  const activeSignal = active?.signal_id ? signals.find((s) => s.id === active.signal_id) : null;
  const activeTrades = active
    ? trades.filter((t) => (t.signal_id && t.signal_id === active.signal_id) || (t.comment && active.key && t.comment.includes(active.key.slice(0, 8))))
    : [];

  return (
    <div className="space-y-4">
      <RangeTabs value={range} onChange={setRange} />

      <div className="surface-card p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
        <Metric label="Signals" value={String(stats.count)} />
        <Metric label="Filled" value={String(stats.filled)} cls="text-success" />
        <Metric label="Skipped" value={String(stats.skipped)} cls="text-warning" />
        <Metric
          label="Net P&L"
          value={`${stats.pnl >= 0 ? "+" : ""}${stats.pnl.toFixed(2)}`}
          cls={stats.pnl >= 0 ? "text-success" : "text-destructive"}
        />
      </div>

      <p className="text-xs text-muted-foreground">Tap any signal for full source, fills, target hits, cancellations and outcome.</p>

      {visible.length === 0 ? (
        <div className="surface-card p-10 text-center text-sm text-muted-foreground">No signal events in this range.</div>
      ) : (
        <div className="space-y-3">
          {visible.map((g) => (
            <button key={g.key} onClick={() => setOpenKey(g.key)} className="w-full text-left surface-card p-3 space-y-2 hover:border-gold/40 transition-colors">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  {g.channel && <span className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-medium truncate max-w-[160px]">{g.channel}</span>}
                  <span className="text-[10px] text-muted-foreground tabular truncate">{g.key.slice(0, 8)}</span>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <span>{fmtDateAST(g.last)}</span>
                  <ChevronRight className="size-3" />
                </div>
              </div>
              <div className="space-y-1.5">
                {g.events.slice(0, 4).map((e) => {
                  const Icon = ICONS[e.event_type] || Clock;
                  const cls = COLORS[e.event_type] || "text-muted-foreground";
                  return (
                    <div key={e.id} className="flex items-start gap-2 text-[11px]">
                      <Icon className={`size-3.5 mt-0.5 shrink-0 ${cls}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold ${cls}`}>{e.event_type.replace(/_/g, " ")}</span>
                          <span className="text-[10px] text-muted-foreground">{fmtDateAST(e.created_at)}</span>
                        </div>
                        <div className="text-muted-foreground tabular break-all line-clamp-1">{summarize(e.detail)}</div>
                      </div>
                    </div>
                  );
                })}
                {g.events.length > 4 && (
                  <div className="text-[10px] text-muted-foreground pl-6">+ {g.events.length - 4} more events…</div>
                )}
              </div>
            </button>
          ))}
        </div>
      )}

      <Sheet open={!!active} onOpenChange={(v) => !v && setOpenKey(null)}>
        <SheetContent side="right" className="w-full sm:max-w-lg overflow-y-auto">
          {active && (
            <>
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <span>Signal Details</span>
                  {active.channel && <span className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-[10px]">{active.channel}</span>}
                </SheetTitle>
                <SheetDescription className="tabular text-[11px]">{active.key.slice(0, 8)} · {fmtDateAST(active.last)}</SheetDescription>
              </SheetHeader>

              <div className="mt-4 space-y-4 text-xs">
                <DrawerSection title="Signal Source">
                  {activeSignal ? (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2 tabular">
                        <KV k="Direction" v={activeSignal.direction ?? "—"} />
                        <KV k="Confidence" v={activeSignal.confidence?.toFixed(2) ?? "—"} />
                        <KV k="SL" v={activeSignal.sl?.toString() ?? "—"} />
                        <KV k="Entry type" v={activeSignal.entry_type ?? "—"} />
                        <KV k="Entries" v={activeSignal.entry?.join(", ") ?? "—"} />
                        <KV k="TPs" v={activeSignal.tp?.join(", ") ?? "—"} />
                        <KV k="Format" v={activeSignal.source_format ?? "—"} />
                        <KV k="Valid" v={activeSignal.valid ? "yes" : "no"} />
                      </div>
                      {activeSignal.raw_message && (
                        <details className="rounded border border-border/60 bg-muted/30 p-2">
                          <summary className="cursor-pointer text-[10px] uppercase tracking-wider text-muted-foreground">Raw message</summary>
                          <pre className="mt-2 text-[11px] whitespace-pre-wrap break-words">{activeSignal.raw_message}</pre>
                        </details>
                      )}
                    </div>
                  ) : (
                    <div className="text-muted-foreground text-[11px]">Signal row not found (outside the loaded window).</div>
                  )}
                </DrawerSection>

                <DrawerSection title="Lifecycle Events">
                  <div className="space-y-2">
                    {active.events.map((e) => {
                      const Icon = ICONS[e.event_type] || Clock;
                      const cls = COLORS[e.event_type] || "text-muted-foreground";
                      return (
                        <div key={e.id} className="flex items-start gap-2 border-b border-border/40 pb-2 last:border-0">
                          <Icon className={`size-3.5 mt-0.5 shrink-0 ${cls}`} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <span className={`font-semibold ${cls}`}>{e.event_type.replace(/_/g, " ")}</span>
                              <span className="text-[10px] text-muted-foreground">{fmtDateAST(e.created_at)}</span>
                            </div>
                            <pre className="text-[10px] text-muted-foreground whitespace-pre-wrap break-all mt-0.5">{summarize(e.detail)}</pre>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </DrawerSection>

                {activeTrades.length > 0 && (
                  <DrawerSection title="Trade Outcome">
                    <div className="space-y-1.5">
                      {activeTrades.map((t) => (
                        <div key={t.id} className="flex items-center justify-between border-b border-border/40 pb-1.5 last:border-0">
                          <div className="tabular text-[11px]">
                            #{t.mt5_ticket ?? "—"} · {t.direction} · {t.lot_size} lot
                            {t.close_reason && <span className={`ml-2 px-1.5 py-0.5 rounded text-[9px] font-semibold ${reasonBadgeClass(t.close_reason)}`}>{reasonLabel(t.close_reason)}</span>}
                          </div>
                          <div className="text-right tabular">
                            <div className={`text-[11px] font-semibold ${(t.pnl_usd ?? 0) >= 0 ? "text-success" : "text-destructive"}`}>
                              {t.pnl_usd != null ? `${t.pnl_usd >= 0 ? "+" : ""}${t.pnl_usd.toFixed(2)}` : "—"}
                            </div>
                            <div className="text-[10px] text-muted-foreground">{t.pnl_pips != null ? `${t.pnl_pips.toFixed(1)}p` : ""}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </DrawerSection>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function Metric({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className={`text-xl font-bold tabular ${cls ?? ""}`}>{value}</div>
    </div>
  );
}

function DrawerSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{title}</div>
      <div>{children}</div>
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className="text-[11px] break-all">{v}</div>
    </div>
  );
}

function summarize(d: Record<string, any> | null | undefined): string {
  if (!d) return "";
  const parts: string[] = [];
  for (const [k, v] of Object.entries(d)) {
    if (v == null) continue;
    if (Array.isArray(v)) parts.push(`${k}: [${v.slice(0, 6).join(",")}${v.length > 6 ? "…" : ""}]`);
    else if (typeof v === "object") parts.push(`${k}: ${JSON.stringify(v)}`);
    else parts.push(`${k}: ${v}`);
  }
  return parts.join(" · ");
}

const REASON_MAP: Record<string, { label: string; cls: string }> = {
  TP1: { label: "TP1", cls: "bg-success/15 text-success" },
  TP2: { label: "TP2", cls: "bg-success/15 text-success" },
  TP: { label: "TP", cls: "bg-success/15 text-success" },
  "100 Pips": { label: "100 Pips", cls: "bg-gold/15 text-gold" },
  MODE_TARGET: { label: "100 Pips", cls: "bg-gold/15 text-gold" },
  "Scalp Target": { label: "Scalp Target", cls: "bg-gold/15 text-gold" },
  Manual: { label: "Manual", cls: "bg-muted text-foreground" },
  MANUAL: { label: "Manual", cls: "bg-muted text-foreground" },
  SL: { label: "SL", cls: "bg-destructive/15 text-destructive" },
  Cancelled: { label: "Cancelled", cls: "bg-muted text-muted-foreground" },
  BREAKEVEN: { label: "Breakeven", cls: "bg-blue-500/15 text-blue-400" },
};

function reasonLabel(r: string): string { return REASON_MAP[r]?.label ?? r; }
function reasonBadgeClass(r: string): string { return REASON_MAP[r]?.cls ?? "bg-muted/50 text-muted-foreground"; }
