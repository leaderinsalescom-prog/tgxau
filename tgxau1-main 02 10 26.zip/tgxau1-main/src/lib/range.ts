export type Range = "today" | "7d" | "30d" | "all";

export const RANGE_LABELS: Record<Range, string> = {
  today: "Today",
  "7d": "7 Days",
  "30d": "30 Days",
  all: "All Time",
};

export const RANGES: Range[] = ["today", "7d", "30d", "all"];

/** Epoch ms cutoff for a range. Returns 0 for "all". */
export function rangeCutoff(range: Range): number {
  if (range === "all") return 0;
  if (range === "today") {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }
  const days = range === "7d" ? 7 : 30;
  return Date.now() - days * 86_400_000;
}

export function inRange(iso: string | null | undefined, range: Range): boolean {
  if (range === "all") return true;
  if (!iso) return false;
  const t = new Date(iso).getTime();
  return !isNaN(t) && t >= rangeCutoff(range);
}
