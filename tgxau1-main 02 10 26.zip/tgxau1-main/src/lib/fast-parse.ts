/**
 * Deterministic fast-path signal parser.
 *
 * The AI parser is excellent but costs a network round-trip (~700-2000 ms).
 * Gold moves several pips in that window. This module recognises the common
 * signal layouts in well under a millisecond and only defers to the AI when
 * it cannot produce a confident result.
 *
 * It intentionally errs on the side of returning `null` — a wrong fast parse
 * is far more expensive than a slow correct one.
 */

export type FastParsed = {
  valid: true;
  direction: "BUY" | "SELL";
  entry: number[];
  entry_type: "limit" | "zone" | "market";
  sl: number;
  tp: number[];
  tp_type: "price" | "pips";
  risk: "HIGH" | "NORMAL";
  confidence: number;
  source_format: string;
  parse_reason: null;
};

const BUY_WORDS = /\b(buy|long|bullish|شراء|خرید)\b/i;
const SELL_WORDS = /\b(sell|short|bearish|بيع|فروش)\b/i;
const MARKET_WORDS = /\b(now|market|cmp|instant|@?\s*market)\b/i;

/** Management / status chatter that must never become an order. */
const MANAGEMENT =
  /\b(close (all|half|partial)|book (profit|partial)|move sl|sl to be|breakeven|be now|cancel|delete (order|pending)|running|pips? (running|profit)|tp\d? hit|sl hit)\b/i;

function nums(s: string): number[] {
  return (s.match(/\d+(?:\.\d+)?/g) ?? []).map(Number).filter((n) => !isNaN(n));
}

/** Numbers that plausibly belong to the same instrument as `ref`. */
function plausible(n: number, ref: number): boolean {
  if (!ref) return true;
  const ratio = n / ref;
  return ratio > 0.5 && ratio < 2;
}

export function fastParse(raw: string): FastParsed | null {
  const text = raw.replace(/\u00a0/g, " ").trim();
  if (!text || text.length > 1200) return null;
  if (MANAGEMENT.test(text)) return null;

  const buy = BUY_WORDS.test(text);
  const sell = SELL_WORDS.test(text);
  if (buy === sell) return null; // none, or ambiguous
  const direction: "BUY" | "SELL" = buy ? "BUY" : "SELL";

  // --- Stop loss ---
  const slMatch = text.match(/\b(?:sl|s\/l|stop\s*loss|stoploss|stop)\b\s*[:=@-]?\s*(\d+(?:\.\d+)?)/i);
  if (!slMatch) return null;
  const sl = Number(slMatch[1]);
  if (!isFinite(sl) || sl <= 0) return null;

  // --- Take profits (all tp mentions, in order) ---
  const tp: number[] = [];
  const tpRe = /\b(?:tp|t\/p|take\s*profit|target)\s*\d?\b\s*[:=@-]?\s*(\d+(?:\.\d+)?)/gi;
  let m: RegExpExecArray | null;
  while ((m = tpRe.exec(text)) !== null) {
    const v = Number(m[1]);
    if (isFinite(v) && v > 0) tp.push(v);
  }
  if (tp.length === 0) return null;

  // --- Entry ---
  let entry: number[] = [];
  let entry_type: FastParsed["entry_type"] = "limit";

  const zone = text.match(
    /\b(?:buy|sell|long|short|entry|enter|zone|@)\b[^\d\n]{0,12}(\d+(?:\.\d+)?)\s*(?:-|–|—|to|\/)\s*(\d+(?:\.\d+)?)/i,
  );
  const single = text.match(/\b(?:entry|enter|buy|sell|long|short|@)\b[^\d\n]{0,12}(\d+(?:\.\d+)?)/i);

  if (zone) {
    // Preserve the channel's order. "4413-4409" means first entry 4413,
    // second entry 4409; sorting reversed the intended position legs.
    entry = [Number(zone[1]), Number(zone[2])];
    entry_type = "zone";
  } else if (MARKET_WORDS.test(text)) {
    entry = [];
    entry_type = "market";
  } else if (single) {
    entry = [Number(single[1])];
    entry_type = "limit";
  } else {
    return null;
  }

  // --- TP unit detection: small values next to a large entry mean pips ---
  const ref = entry.length ? entry[0] : sl;
  const tp_type: "price" | "pips" = tp.every((t) => plausible(t, ref)) ? "price" : "pips";

  // --- Sanity: SL and TP must sit on the correct sides of the entry ---
  if (entry.length) {
    const e = entry[0];
    if (!plausible(sl, e)) return null;
    if (direction === "BUY" && sl >= e) return null;
    if (direction === "SELL" && sl <= e) return null;
    if (tp_type === "price") {
      const good = tp.every((t) => (direction === "BUY" ? t > e : t < e));
      if (!good) return null;
    }
  } else if (tp_type === "price" && !plausible(sl, tp[0])) {
    return null;
  }

  // Stray numbers we could not account for make a silent misparse likely.
  const accounted = new Set([...entry, sl, ...tp].map((n) => n.toString()));
  const stray = nums(text).filter((n) => !accounted.has(n.toString()) && n > 100 && plausible(n, ref));
  if (stray.length > 2) return null;

  return {
    valid: true,
    direction,
    entry,
    entry_type,
    sl,
    tp: tp_type === "price" ? Array.from(new Set(tp)).sort((a, b) => (direction === "BUY" ? a - b : b - a)) : tp,
    tp_type,
    risk: /\b(high\s*risk|risky|aggressive)\b/i.test(text) ? "HIGH" : "NORMAL",
    confidence: 0.92,
    source_format: entry_type === "zone" ? "zone" : entry_type === "market" ? "compact" : "clean",
    parse_reason: null,
  };
}
