import { createServerFn } from "@tanstack/react-start";

/* ------------------------------------------------------------------ */
/* Shared types (provider-agnostic — add providers without UI changes) */
/* ------------------------------------------------------------------ */

export type Impact = "High" | "Medium" | "Low" | "Holiday";

export type CalendarEvent = {
  id: string;
  title: string;
  country: string; // currency code as provided by the feed (USD, EUR…)
  date: string; // ISO
  impact: Impact;
  forecast: string;
  previous: string;
  actual: string;
  source: string;
};

export type NewsItem = {
  id: string;
  title: string;
  link: string;
  source: string;
  published: string; // ISO
  currencies: string[]; // USD, EUR, … XAU
  impact: Exclude<Impact, "Holiday">;
};

export type FeedResult<T> = {
  items: T[];
  fetchedAt: string;
  sources: { name: string; ok: boolean }[];
  stale: boolean; // true when served from cache because providers failed
};

/* ------------------------------ Cache ------------------------------ */
// Per-worker memory cache so many users/tabs don't hammer upstream feeds.
type Entry<T> = { at: number; value: FeedResult<T> };
const cache = new Map<string, Entry<unknown>>();

async function cached<T>(key: string, ttlMs: number, load: () => Promise<FeedResult<T>>): Promise<FeedResult<T>> {
  const hit = cache.get(key) as Entry<T> | undefined;
  if (hit && Date.now() - hit.at < ttlMs) return hit.value;
  try {
    const value = await load();
    if (value.items.length === 0 && hit) return { ...hit.value, sources: value.sources, stale: true };
    cache.set(key, { at: Date.now(), value });
    return value;
  } catch (e) {
    console.error(`[market-data] ${key} failed`, e);
    if (hit) return { ...hit.value, stale: true };
    return { items: [], fetchedAt: new Date().toISOString(), sources: [], stale: true };
  }
}

async function fetchWithTimeout(url: string, init: RequestInit = {}, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

/* -------------------------- Calendar provider -------------------------- */
// Forex Factory's official public JSON export (nfs.faireconomy.media).
// It is rate limited upstream, so we cache for 5 minutes.
const CALENDAR_PROVIDERS = [
  { name: "Forex Factory (this week)", url: "https://nfs.faireconomy.media/ff_calendar_thisweek.json" },
  { name: "Forex Factory (next week)", url: "https://nfs.faireconomy.media/ff_calendar_nextweek.json" },
];

function normalizeImpact(value: unknown): Impact {
  const v = String(value ?? "").toLowerCase();
  if (v.startsWith("high")) return "High";
  if (v.startsWith("med")) return "Medium";
  if (v.startsWith("holiday")) return "Holiday";
  return "Low";
}

export const getEconomicCalendar = createServerFn({ method: "GET" }).handler(
  async (): Promise<FeedResult<CalendarEvent>> =>
    cached("calendar", 5 * 60_000, async () => {
      const results = await Promise.allSettled(
        CALENDAR_PROVIDERS.map(async (p) => {
          const res = await fetchWithTimeout(p.url, { headers: { accept: "application/json", "user-agent": "GoldCopier/1.0" } });
          if (!res.ok) throw new Error(`${p.name} ${res.status}`);
          const body = await res.json();
          return { p, rows: Array.isArray(body) ? body : [] };
        }),
      );
      const sources = results.map((r, i) => ({ name: CALENDAR_PROVIDERS[i].name, ok: r.status === "fulfilled" }));
      const seen = new Set<string>();
      const items: CalendarEvent[] = [];
      for (const r of results) {
        if (r.status !== "fulfilled") continue;
        for (const raw of r.value.rows as any[]) {
          const date = new Date(String(raw?.date ?? ""));
          const title = String(raw?.title ?? "").trim();
          if (Number.isNaN(date.getTime()) || !title) continue;
          const country = String(raw?.country ?? "").trim().toUpperCase() || "ALL";
          const id = `${country}-${title}-${date.toISOString()}`;
          if (seen.has(id)) continue;
          seen.add(id);
          items.push({
            id,
            title,
            country,
            date: date.toISOString(),
            impact: normalizeImpact(raw?.impact),
            forecast: String(raw?.forecast ?? "").trim(),
            previous: String(raw?.previous ?? "").trim(),
            actual: String(raw?.actual ?? "").trim(),
            source: "Forex Factory",
          });
        }
      }
      items.sort((a, b) => a.date.localeCompare(b.date));
      return { items, fetchedAt: new Date().toISOString(), sources, stale: false };
    }),
);

/* ----------------------------- News providers ----------------------------- */
const g = (q: string) => `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;
const NEWS_PROVIDERS: { name: string; url: string }[] = [
  { name: "ForexLive", url: "https://www.forexlive.com/feed/news" },
  { name: "FXStreet", url: "https://www.fxstreet.com/rss/news" },
  { name: "Google News · Gold", url: g("gold price OR XAUUSD when:2d") },
  { name: "Google News · Fed", url: g("Federal Reserve OR FOMC OR Powell when:2d") },
  { name: "Google News · Central banks", url: g("ECB OR \"Bank of England\" OR \"Bank of Japan\" OR SNB OR RBA OR RBNZ OR \"Bank of Canada\" when:2d") },
  { name: "Google News · Data", url: g("CPI OR inflation OR nonfarm payrolls OR GDP OR unemployment forex when:2d") },
];

const CURRENCY_KEYWORDS: Record<string, RegExp> = {
  USD: /\b(usd|dollar|fed|fomc|powell|treasur|us cpi|nonfarm|nfp|payrolls|jobless|ism|u\.s\.|united states|wall street|dxy)\b/i,
  EUR: /\b(eur|euro|ecb|lagarde|eurozone|euro area|germany|german|france|italy|bund)\b/i,
  GBP: /\b(gbp|pound|sterling|boe|bank of england|bailey|uk|britain|british)\b/i,
  JPY: /\b(jpy|yen|boj|bank of japan|ueda|japan|japanese)\b/i,
  CHF: /\b(chf|franc|snb|swiss|switzerland)\b/i,
  AUD: /\b(aud|aussie|rba|australia|australian)\b/i,
  CAD: /\b(cad|loonie|boc|bank of canada|canada|canadian|macklem)\b/i,
  NZD: /\b(nzd|kiwi|rbnz|new zealand)\b/i,
  XAU: /\b(gold|xau|xauusd|bullion|precious metal)/i,
};
const HIGH_RX = /\b(rate decision|rate cut|rate hike|hikes|cuts rates|raises rates|holds rates|fomc|nonfarm|nfp|payrolls|cpi|inflation|gdp|press conference|emergency|war|invasion|sanction|tariff|intervention)\b/i;
const MED_RX = /\b(ppi|retail sales|pmi|ism|jobless|unemployment|speech|speaks|minutes|testimony|trade balance|sentiment|housing|geopolit|attack|missile)\b/i;

function tagCurrencies(text: string) {
  return Object.entries(CURRENCY_KEYWORDS).filter(([, rx]) => rx.test(text)).map(([c]) => c);
}
function tagImpact(text: string): NewsItem["impact"] {
  if (HIGH_RX.test(text)) return "High";
  if (MED_RX.test(text)) return "Medium";
  return "Low";
}

function decodeEntities(input: string) {
  return input
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;|&#8217;|&#8216;/g, "'")
    .replace(/&#8220;|&#8221;/g, '"')
    .replace(/&#8211;|&#8212;/g, "-")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .trim();
}
function pickTag(block: string, tag: string) {
  const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, "i"));
  return m ? decodeEntities(m[1]) : "";
}
function normTitle(t: string) {
  return t.toLowerCase().replace(/\s+-\s+[^-]+$/, "").replace(/[^a-z0-9]+/g, " ").trim().slice(0, 90);
}

async function fetchFeed(p: { name: string; url: string }): Promise<NewsItem[]> {
  const res = await fetchWithTimeout(p.url, { headers: { "user-agent": "Mozilla/5.0 GoldCopier/1.0", accept: "application/rss+xml, application/xml, text/xml" } });
  if (!res.ok) throw new Error(`${p.name} ${res.status}`);
  const xml = await res.text();
  const blocks = xml.match(/<item[\s\S]*?<\/item>/gi) ?? [];
  return blocks.slice(0, 40).map((block) => {
    const title = pickTag(block, "title");
    const link = pickTag(block, "link");
    const parsed = new Date(pickTag(block, "pubDate"));
    const source = pickTag(block, "source") || p.name.replace(/ ·.*$/, "");
    const text = `${title} ${pickTag(block, "description").slice(0, 300)}`;
    return {
      id: link || title,
      title,
      link,
      source,
      published: Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString(),
      currencies: tagCurrencies(text),
      impact: tagImpact(title),
    };
  });
}

export const getMarketNews = createServerFn({ method: "GET" }).handler(
  async (): Promise<FeedResult<NewsItem>> =>
    cached("news", 2 * 60_000, async () => {
      const results = await Promise.allSettled(NEWS_PROVIDERS.map(fetchFeed));
      const sources = results.map((r, i) => ({ name: NEWS_PROVIDERS[i].name, ok: r.status === "fulfilled" }));
      const seen = new Set<string>();
      const items = results
        .flatMap((r) => (r.status === "fulfilled" ? r.value : []))
        .filter((n) => n.title && /^https?:\/\//.test(n.link))
        .sort((a, b) => b.published.localeCompare(a.published))
        .filter((n) => {
          const k = normTitle(n.title);
          if (seen.has(k) || seen.has(n.link)) return false;
          seen.add(k);
          seen.add(n.link);
          return true;
        })
        .slice(0, 150);
      return { items, fetchedAt: new Date().toISOString(), sources, stale: false };
    }),
);
