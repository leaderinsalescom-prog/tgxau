/**
 * Deterministic parser for channel *management* instructions.
 *
 * These are messages that manage positions already running, e.g.
 *   "COLLECT HALF SET BREAKEVEN-HOLD FOR TP!"
 *   "TP1 HIT 70+ pips — SL moved to Breakeven"
 *   "Close all trades"
 *   "Move SL to 4405"  /  "New TP 4440"
 *
 * Runs in microseconds so instructions are acted on in the same tick the
 * message arrives — no AI round-trip.
 */

export type ManageOp =
  | { op: "collect_half" }
  | { op: "set_breakeven" }
  | { op: "hold" }
  | { op: "close_all" }
  | { op: "cancel_pending" }
  | { op: "set_sl"; price: number }
  | { op: "set_tp"; price: number };

export type ParsedInstruction = {
  instruction: true;
  ops: ManageOp[];
  symbol: string | null;
  direction: "BUY" | "SELL" | null;
  raw: string;
};

const COLLECT_HALF =
  /\b(collect|book|take|secure|close)\s*(the\s*)?(half|50%|partial|partials)\b|\bhalf\s*(closed|booked|collected|out)\b|\bpartial\s*(close|booked|taken)\b|\btp\s*1?\s*[-:]?\s*hit\b|\btp1\s*(is\s*)?(hit|reached|done)\b/i;

const BREAKEVEN =
  /\b(set|move|moved|shift|shifted|bring|put)\s*(the\s*)?(sl|s\/l|stop\s*loss|stops?)?\s*(to\s*)?(break\s*-?\s*even|breakeven|be)\b|\b(sl|s\/l|stop\s*loss)\s*(to|at|=)\s*(break\s*-?\s*even|breakeven|be)\b|\bbreak\s*-?\s*even\b/i;

const HOLD = /\b(hold|run|let\s+it\s+run|leave)\b[^.\n]{0,20}\b(for\s+)?(tp|target|runners?)\b/i;

// "SECURE FULL NOW MAX TP HIT!!", "secure all", "max TP hit", "all TPs hit" →
// close everything for that channel (and cancel its pending orders).
const SECURE_FULL =
  /\b(secure|close|book|collect|take)\s*(the\s*)?(full|all|everything|max)\b(?!\s*(half|50))|\bmax(imum)?\s*tp\s*(is\s*)?(hit|reached|done|smashed)\b|\bfull\s*(tp|target)\s*(is\s*)?(hit|reached|done)\b|\ball\s*(tps|targets)\s*(are\s*)?(hit|reached|done)\b/i;

const CLOSE_ALL =
  /\b(close|exit)\s*(all|full|fully|everything|the\s+trade|trades?|position(s)?)\b(?!\s*half)|\bfull\s*close\b|\bclose\s*now\b/i;

const CANCEL_PENDING =
  /\b(cancel|delete|remove)\s*(all\s*)?(pending|limit)?\s*(orders?|trades?|entries)?\b/i;

const SL_PRICE = /\b(?:sl|s\/l|stop\s*loss)\b\s*(?:to|at|=|:)?\s*(\d+(?:\.\d+)?)/i;
const TP_PRICE = /\b(?:tp|t\/p|take\s*profit|target)\s*\d?\b\s*(?:to|at|=|:)?\s*(\d+(?:\.\d+)?)/i;

const SYMBOL = /\b(xauusd|gold|xau|btcusd|eurusd|gbpusd|usdjpy|us30|nas100)\b/i;

/** A management instruction never contains a fresh entry + SL + TP set. */
export function parseInstruction(raw: string): ParsedInstruction | null {
  const text = (raw || "").replace(/\u00a0/g, " ").trim();
  if (!text || text.length > 800) return null;
  // Hyphens/underscores/dashes between words ("BREAKEVEN-HOLD", "SECURE-FULL").
  const norm = text.replace(/[-_–—]+/g, " ").replace(/\s+/g, " ");

  // A brand-new signal (direction + entry + SL + TP) is never a command.
  const looksLikeNewSignal =
    /\b(buy|sell|long|short)\b/i.test(norm) && /\b(entry|zone|@|now)\b/i.test(norm) && SL_PRICE.test(norm) && TP_PRICE.test(norm);
  if (looksLikeNewSignal) return null;

  const ops: ManageOp[] = [];
  const secureFull = SECURE_FULL.test(norm);
  if (secureFull) {
    return {
      instruction: true,
      ops: [{ op: "close_all" }, { op: "cancel_pending" }],
      symbol: symbolOf(norm),
      direction: directionOf(norm),
      raw: text,
    };
  }
  const halfHit = COLLECT_HALF.test(norm);
  const be = BREAKEVEN.test(norm);

  if (halfHit) ops.push({ op: "collect_half" });
  if (be) ops.push({ op: "set_breakeven" });
  if (HOLD.test(norm)) ops.push({ op: "hold" });

  if (!halfHit && CLOSE_ALL.test(text)) ops.push({ op: "close_all" });
  if (!halfHit && !ops.length && CANCEL_PENDING.test(text) && /\b(pending|limit)\b/i.test(text))
    ops.push({ op: "cancel_pending" });

  // Explicit new SL / TP prices (only when they are clearly a *move*, i.e. no
  // fresh direction+entry set in the same message).
  {
    const slm = text.match(SL_PRICE);
    if (slm && /\b(move|moved|change|new|shift|update)\b/i.test(text)) {
      const p = Number(slm[1]);
      if (isFinite(p) && p > 0) ops.push({ op: "set_sl", price: p });
    }
    const tpm = text.match(TP_PRICE);
    if (tpm && /\b(move|moved|change|new|shift|update)\b/i.test(text) && !halfHit) {
      const p = Number(tpm[1]);
      if (isFinite(p) && p > 0) ops.push({ op: "set_tp", price: p });
    }
  }

  if (!ops.length) return null;

  return {
    instruction: true,
    ops,
    symbol: symbolOf(text),
    direction: directionOf(text),
    raw: text,
  };
}

function symbolOf(text: string): string | null {
  const sym = text.match(SYMBOL);
  return sym ? (/(gold|xau)/i.test(sym[1]) ? "XAUUSD" : sym[1].toUpperCase()) : null;
}

function directionOf(text: string): "BUY" | "SELL" | null {
  return /\bbuy\b|\blong\b/i.test(text) ? "BUY" : /\bsell\b|\bshort\b/i.test(text) ? "SELL" : null;
}
