import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
// Tables are typed as `never` until types regenerate; cast through any.
const db = supabase as any;

// Unique channel name per mount — supabase-js throws
// "cannot add 'postgres_changes' callbacks for realtime:<name> after subscribe()"
// when the same channel name is re-used (StrictMode double-mount / HMR).
const uid = () => Math.random().toString(36).slice(2, 9);

export function useBridgeStatus() {
  const [s, setS] = useState({ telegram: false, mt5: false });
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data } = await db.from("bridge_heartbeat").select("service,last_seen,status");
      if (!alive || !data) return;
      const fresh = (d: { last_seen: string; status: string | null } | undefined) =>
        !!d && d.status === "online" && Date.now() - new Date(d.last_seen).getTime() < 60_000;
      const tg = data.find((r: any) => r.service === "telegram");
      const mt = data.find((r: any) => r.service === "mt5");
      setS({ telegram: fresh(tg as any), mt5: fresh(mt as any) });
    };
    load();
    const i = setInterval(load, 10_000);
    const ch = supabase
      .channel(`hb-${uid()}`)
      .on("postgres_changes" as any, { event: "*", schema: "public", table: "bridge_heartbeat" }, load)
      .subscribe();
    return () => {
      alive = false;
      clearInterval(i);
      supabase.removeChannel(ch);
    };
  }, []);
  return s;
}

export function useSingleton<T>(table: string, initial: T): T {
  const [row, setRow] = useState<T>(initial);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data } = await db.from(table).select("*").eq("id", 1).maybeSingle();
      if (alive && data) setRow(data as T);
    };
    load();
    const ch = supabase
      .channel(`s-${table}-${uid()}`)
      .on("postgres_changes" as any, { event: "*", schema: "public", table }, load)
      .subscribe();
    return () => {
      alive = false;
      supabase.removeChannel(ch);
    };
  }, [table]);
  return row;
}

export function useRealtimeRows<T>(
  table: string,
  order: { col: string; asc?: boolean } = { col: "created_at", asc: false },
  limit = 100,
): T[] {
  const [rows, setRows] = useState<T[]>([]);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data } = await db.from(table).select("*").order(order.col, { ascending: !!order.asc }).limit(limit);
      if (alive && data) setRows(data as T[]);
    };
    load();
    // Fallback poll in case the realtime socket drops.
    const i = setInterval(load, 15_000);
    const onLocal = (e: Event) => { if ((e as CustomEvent).detail === table) load(); };
    window.addEventListener("rows-changed", onLocal);
    const ch = supabase
      .channel(`r-${table}-${uid()}`)
      .on("postgres_changes" as any, { event: "*", schema: "public", table }, load)
      .subscribe();
    return () => {
      alive = false;
      clearInterval(i);
      window.removeEventListener("rows-changed", onLocal);
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table]);
  return rows;
}

/** Ask every useRealtimeRows(table) on this page to reload now. */
export function notifyRowsChanged(table: string) {
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("rows-changed", { detail: table }));
}
