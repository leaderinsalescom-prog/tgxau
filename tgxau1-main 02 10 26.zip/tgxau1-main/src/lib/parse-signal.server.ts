import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { generateText } from "ai";

const SYSTEM_PROMPT = `You are a XAUUSD (gold) trading signal parser. Detect and extract valid signals regardless of format. Signals come in many styles, languages, emojis. Be intelligent.

VALID SIGNAL NEEDS:
- Direction (BUY/SELL/LONG/SHORT) — infer from SL/TP position vs entry if missing but obvious
- At least one price (entry, zone, or "market")
- At least an SL or a TP

IGNORE (set valid=false):
- "STANDBYYY", "ARE YOU READY", "NEW SIGNAL COMING"
- "Join channel", VIP promotions, attribution like "[Forwarded from ...]" without an actual signal
- Market commentary without prices
- Status updates ("60+ PIPS RUNNING", "SL hit")

PARSING RULES:
- If TP is in pips: tp_type="pips", tp[] = pip values.
- If entry says NOW/MARKET: entry_type="market", entry=[].
- If zone like "4300-4302": entry_type="zone", entry=[4300,4302].
- Never hallucinate. Unknown field = null.
- Multilingual (Arabic/Urdu/mixed) — recognize buy/sell equivalents.
- Cancel/close/management commands: valid=false, parse_reason="management_command:<close|cancel|sl_to_be|partial_close>".
- Confidence < 0.7 = manual review (still output valid=true if signal is complete).

OUTPUT JSON ONLY, NO markdown:
{"valid":bool,"direction":"BUY"|"SELL"|null,"entry":[numbers],"entry_type":"limit"|"zone"|"market"|null,"sl":number|null,"tp":[numbers],"tp_type":"price"|"pips"|null,"risk":"HIGH"|"NORMAL","confidence":0.0-1.0,"source_format":"clean|zone|emoji|compact|pip|natural|mixed|forwarded|other","parse_reason":"string|null"}`;

export type ParsedSignal = {
  valid: boolean;
  direction: "BUY" | "SELL" | null;
  entry: number[];
  entry_type: string | null;
  sl: number | null;
  tp: number[];
  tp_type: string | null;
  risk: "HIGH" | "NORMAL";
  confidence: number;
  source_format: string;
  parse_reason: string | null;
};

export async function parseSignalDirect(text: string): Promise<ParsedSignal> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("LOVABLE_API_KEY missing");
  const provider = createOpenAICompatible({
    name: "lovable",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
  });
  const { text: out } = await generateText({
    model: provider("google/gemini-3-flash-preview"),
    system: SYSTEM_PROMPT,
    prompt: text,
  });
  const match = out.match(/\{[\s\S]*\}/);
  if (!match) {
    return blank("parser_no_json");
  }
  try {
    const p = JSON.parse(match[0]);
    return {
      valid: !!p.valid,
      direction: p.direction === "BUY" || p.direction === "SELL" ? p.direction : null,
      entry: Array.isArray(p.entry) ? p.entry.map((n: any) => Number(n)).filter((n: number) => !isNaN(n)) : [],
      entry_type: p.entry_type ?? null,
      sl: p.sl == null ? null : Number(p.sl),
      tp: Array.isArray(p.tp) ? p.tp.map((n: any) => Number(n)).filter((n: number) => !isNaN(n)) : [],
      tp_type: p.tp_type ?? null,
      risk: p.risk === "HIGH" ? "HIGH" : "NORMAL",
      confidence: typeof p.confidence === "number" ? Math.max(0, Math.min(1, p.confidence)) : 0,
      source_format: p.source_format ?? "other",
      parse_reason: p.parse_reason ?? null,
    };
  } catch {
    return blank("parser_json_error");
  }
}

function blank(reason: string): ParsedSignal {
  return { valid: false, direction: null, entry: [], entry_type: null, sl: null, tp: [], tp_type: null, risk: "NORMAL", confidence: 0, source_format: "other", parse_reason: reason };
}
