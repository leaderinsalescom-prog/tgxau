export const fmtUSD = (n: number | null | undefined, opts: { sign?: boolean } = {}) => {
  if (n == null || isNaN(n)) return "—";
  const s = (opts.sign && n > 0 ? "+" : "") +
    n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 });
  return s;
};
export const fmtPips = (n: number | null | undefined) => {
  if (n == null || isNaN(n)) return "—";
  return (n > 0 ? "+" : "") + n.toFixed(1) + " pips";
};
export const fmtPrice = (n: number | null | undefined, d = 2) =>
  n == null || isNaN(n) ? "—" : n.toFixed(d);
export const pnlClass = (n: number | null | undefined) =>
  n == null ? "text-muted-foreground" : n > 0 ? "text-pnl-pos" : n < 0 ? "text-pnl-neg" : "text-muted-foreground";

// Saudi Arabia Standard Time (UTC+3, no DST)
export function nowAST(): Date {
  return new Date(Date.now());
}
export function fmtAST(d: Date | number = Date.now()) {
  const date = typeof d === "number" ? new Date(d) : d;
  return date.toLocaleTimeString("en-GB", { timeZone: "Asia/Riyadh", hour: "2-digit", minute: "2-digit", second: "2-digit" }) + " AST";
}
export function fmtDateAST(d: Date | string | number) {
  const date = typeof d === "string" || typeof d === "number" ? new Date(d) : d;
  return date.toLocaleString("en-GB", { timeZone: "Asia/Riyadh", year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export type MarketSession = {
  name: "Asian" | "London" | "New York" | "Overlap (LDN/NY)" | "Closed";
  open: boolean;
};
// Forex market: closed Fri 22:00 UTC → Sun 22:00 UTC
export function currentSession(now = new Date()): MarketSession {
  const utcDay = now.getUTCDay(); // 0=Sun
  const utcHour = now.getUTCHours();
  const minutes = utcHour * 60 + now.getUTCMinutes();
  // Closed window
  if ((utcDay === 5 && minutes >= 22 * 60) || utcDay === 6 || (utcDay === 0 && minutes < 22 * 60)) {
    return { name: "Closed", open: false };
  }
  // Sessions in UTC (approximate):
  // Asian: 23:00-08:00, London: 07:00-16:00, NY: 12:00-21:00
  const inLondon = utcHour >= 7 && utcHour < 16;
  const inNY = utcHour >= 12 && utcHour < 21;
  const inAsian = utcHour >= 23 || utcHour < 8;
  if (inLondon && inNY) return { name: "Overlap (LDN/NY)", open: true };
  if (inLondon) return { name: "London", open: true };
  if (inNY) return { name: "New York", open: true };
  if (inAsian) return { name: "Asian", open: true };
  return { name: "Asian", open: true };
}
