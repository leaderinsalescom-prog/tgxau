import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AlertCircle, Building2, Loader2, Radio, RefreshCw, Settings2 } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useRealtimeRows } from "@/lib/hooks";
import { parseInstruction } from "@/lib/parse-instruction";
import { fastParse } from "@/lib/fast-parse";
import { fmtDateAST } from "@/lib/format";
import type { Channel } from "@/lib/types";

const db = supabase as any;

type BrokerAccount = {
  id: string; label: string | null; login: string; server: string;
  is_active: boolean; copy_enabled: boolean;
};
type Routing = { id: string; channel_id: string; broker_account_id: string; enabled: boolean };

/** Instruction types a channel can send while a trade is running. */
const INSTRUCTIONS: { key: string; label: string; hint: string }[] = [
  { key: "close_full", label: "Close full position", hint: '"close all", "exit trade"' },
  { key: "collect_half", label: "Collect half / partial close", hint: '"collect half", "TP1 hit"' },
  { key: "breakeven", label: "Break-even", hint: '"SL to breakeven"' },
  { key: "modify_sl", label: "Move stop loss", hint: '"move SL to 4405"' },
  { key: "modify_tp", label: "Move take profit", hint: '"new TP 4440"' },
  { key: "cancel_pending", label: "Cancel pending orders", hint: '"cancel limit orders"' },
];

export const Route = createFileRoute("/channels")({
  head: () => ({ meta: [
    { title: "Signal Channels — GoldCopier" },
    { name: "description", content: "Choose which Telegram channels send signals, route each channel to broker accounts and control how its instructions are parsed." },
    { property: "og:title", content: "Signal Channels — GoldCopier" },
    { property: "og:description", content: "Route each Telegram signal channel to the broker accounts you choose and control instruction handling." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ChannelsPage,
});

function ChannelsPage() {
  const channels = useRealtimeRows<Channel>("channels", { col: "name", asc: true }, 200);
  const brokers = useRealtimeRows<BrokerAccount>("broker_accounts", { col: "created_at", asc: true }, 10);
  const routes = useRealtimeRows<Routing>("channel_brokers", { col: "created_at", asc: true }, 500);
  const [refreshing, setRefreshing] = useState(false);
  const [open, setOpen] = useState<Channel | null>(null);
  const [q, setQ] = useState("");

  const selectedCount = channels.filter((c) => c.is_selected).length;
  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? channels.filter((c) => c.name.toLowerCase().includes(t) || (c.username ?? "").toLowerCase().includes(t)) : channels;
  }, [channels, q]);

  const toggle = async (c: Channel) => {
    const { error } = await db.from("channels").update({ is_selected: !c.is_selected }).eq("id", c.id);
    if (error) toast.error(error.message);
  };

  const refresh = async () => {
    setRefreshing(true);
    const { error } = await db.from("pending_actions").insert({ action: "fetch_channels" });
    if (error) toast.error(error.message);
    else toast.info("Asked the Telegram listener to refresh your channel list…");
    setTimeout(() => setRefreshing(false), 4000);
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20"><Radio className="size-5" /></div>
            <div>
              <h1 className="text-2xl font-display font-bold tracking-tight">Channels</h1>
              <p className="text-sm text-muted-foreground mt-0.5">{selectedCount} of {channels.length} channels are sending signals to the copier.</p>
            </div>
          </div>
          <Button variant="outline" onClick={refresh} disabled={refreshing}>
            <RefreshCw className={refreshing ? "animate-spin" : ""} /> Refresh list
          </Button>
        </div>

        <Input placeholder="Search channels…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />

        {channels.length === 0 ? (
          <div className="surface-card p-10 text-center">
            <AlertCircle className="mx-auto size-7 text-warning" />
            <h2 className="mt-3 font-semibold">No channels yet</h2>
            <p className="mt-1 text-sm text-muted-foreground">Start the Telegram listener on your VPS, then press Refresh list.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            {filtered.map((c) => {
              const linked = routes.filter((r) => r.channel_id === c.id && r.enabled).length;
              return (
                <article key={c.id} className={`surface-card p-4 ${c.is_selected ? "" : "opacity-70"}`}>
                  <div className="flex items-start gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="truncate font-semibold">{c.name}</h2>
                        {c.username && <span className="text-[10px] text-muted-foreground">@{c.username}</span>}
                        <span className={`rounded px-1.5 py-0.5 text-[10px] ${c.is_selected ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>
                          {c.is_selected ? "Sending signals" : "Muted"}
                        </span>
                      </div>
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        {linked > 0 ? `${linked} account${linked > 1 ? "s" : ""} receiving` : "No accounts selected"}
                        {c.last_message_at ? ` · last message ${fmtDateAST(c.last_message_at)}` : ""}
                      </p>
                    </div>
                    <Switch checked={c.is_selected} onCheckedChange={() => toggle(c)} aria-label="Send signals from this channel" />
                  </div>

                  {c.last_message && (
                    <div className="mt-3 rounded-md bg-muted/40 p-2">
                      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">Last message</div>
                      <p className="mt-0.5 line-clamp-2 text-[11px]">{c.last_message}</p>
                      <ParsePreview text={c.last_message} />
                    </div>
                  )}

                  <div className="mt-3 flex justify-end border-t border-border/70 pt-3">
                    <Button size="sm" variant="outline" onClick={() => setOpen(c)}><Settings2 /> Configure</Button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      <ChannelDrawer channel={open} brokers={brokers} routes={routes} onClose={() => setOpen(null)} />
    </AppShell>
  );
}

/** Shows how the deterministic parser reads a message — no AI round-trip. */
function ParsePreview({ text }: { text: string }) {
  const instr = parseInstruction(text);
  const sig = instr ? null : fastParse(text);
  if (instr) {
    return (
      <div className="mt-1.5 flex flex-wrap gap-1">
        {instr.ops.map((o) => (
          <span key={o.op} className="rounded bg-gold/10 px-1.5 py-0.5 text-[9px] text-gold">{o.op.replace(/_/g, " ")}</span>
        ))}
      </div>
    );
  }
  if (sig?.valid) {
    return (
      <div className="mt-1.5 flex flex-wrap gap-1 text-[9px]">
        <span className="rounded bg-success/15 px-1.5 py-0.5 text-success">{sig.direction}</span>
        {sig.entry?.length ? <span className="rounded bg-muted px-1.5 py-0.5">entry {sig.entry.join(" / ")}</span> : null}
        {sig.sl != null ? <span className="rounded bg-muted px-1.5 py-0.5">SL {sig.sl}</span> : null}
        {sig.tp?.length ? <span className="rounded bg-muted px-1.5 py-0.5">TP {sig.tp.join(" / ")}</span> : null}
      </div>
    );
  }
  return <div className="mt-1.5 text-[9px] text-muted-foreground">Not a tradeable message</div>;
}

function ChannelDrawer({ channel, brokers, routes, onClose }: {
  channel: Channel | null; brokers: BrokerAccount[]; routes: Routing[]; onClose: () => void;
}) {
  const [brokerId, setBrokerId] = useState<string | null>(null);

  useEffect(() => {
    if (channel) setBrokerId(brokers[0]?.id ?? null);
  }, [channel, brokers]);

  const setRoute = async (broker: BrokerAccount, enabled: boolean) => {
    if (!channel) return;
    const existing = routes.find((r) => r.channel_id === channel.id && r.broker_account_id === broker.id);
    const { error } = existing
      ? await db.from("channel_brokers").update({ enabled }).eq("id", existing.id)
      : await db.from("channel_brokers").insert({ channel_id: channel.id, broker_account_id: broker.id, enabled });
    if (error) toast.error(error.message);
  };

  return (
    <Sheet open={!!channel} onOpenChange={(o) => { if (!o) onClose(); }}>
      <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader>
          <SheetTitle>{channel?.name ?? "Channel"}</SheetTitle>
          <SheetDescription>Choose which accounts copy this channel and how its messages are handled.</SheetDescription>
        </SheetHeader>

        <div className="mt-5 space-y-5">
          <section className="space-y-2">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Accounts receiving this channel</h3>
            {brokers.length === 0 ? (
              <p className="text-xs text-muted-foreground">Connect a broker account first.</p>
            ) : brokers.map((b) => {
              const on = !!routes.find((r) => r.channel_id === channel?.id && r.broker_account_id === b.id)?.enabled;
              return (
                <label key={b.id} className="flex items-center gap-3 rounded-md border border-border/70 p-2.5">
                  <Building2 className="size-4 text-gold" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm">{b.label ?? `Account ${b.login}`}</div>
                    <div className="text-[10px] text-muted-foreground">{b.login} · {b.server}</div>
                  </div>
                  <Switch checked={on} onCheckedChange={(v) => setRoute(b, v)} aria-label="Copy this channel to this account" />
                </label>
              );
            })}
          </section>

          {channel && brokerId && (
            <section className="space-y-2">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Trading rules</h3>
              {brokers.length > 1 && (
                <div className="flex flex-wrap gap-1.5">
                  {brokers.map((b) => (
                    <button key={b.id} onClick={() => setBrokerId(b.id)}
                      className={`rounded-full border px-3 py-1 text-[11px] ${brokerId === b.id ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground"}`}>
                      {b.label ?? b.login}
                    </button>
                  ))}
                </div>
              )}
              <ChannelConfig channelId={channel.id} brokerId={brokerId} />
            </section>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

function ChannelConfig({ channelId, brokerId }: { channelId: string; brokerId: string }) {
  const [cfg, setCfg] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    (async () => {
      const { data } = await db.from("channel_broker_config").select("*")
        .eq("channel_id", channelId).eq("broker_account_id", brokerId).maybeSingle();
      if (alive) { setCfg(data ?? null); setLoading(false); }
    })();
    return () => { alive = false; };
  }, [channelId, brokerId]);

  const create = async () => {
    const { data, error } = await db.from("channel_broker_config")
      .insert({ channel_id: channelId, broker_account_id: brokerId })
      .select("*").single();
    if (error) return toast.error(error.message);
    setCfg(data);
  };

  const patch = (values: Record<string, any>) => setCfg((c: any) => ({ ...c, ...values }));

  const save = async () => {
    setSaving(true);
    const { id, user_id, created_at, updated_at, channel_id, broker_account_id, ...values } = cfg;
    const { error } = await db.from("channel_broker_config").update(values).eq("id", id);
    setSaving(false);
    if (error) toast.error(error.message); else toast.success("Channel rules saved");
  };

  if (loading) return <div className="py-6 text-center"><Loader2 className="inline size-5 animate-spin text-muted-foreground" /></div>;
  if (!cfg) {
    return (
      <div className="rounded-md border border-dashed border-border p-4 text-center">
        <p className="text-xs text-muted-foreground">No rules yet for this channel and account.</p>
        <Button size="sm" className="mt-2" onClick={create}>Create rules</Button>
      </div>
    );
  }

  const map: Record<string, string> = cfg.instruction_map ?? {};

  return (
    <div className="space-y-3">
      <Tabs defaultValue="symbols">
        <TabsList className="w-full">
          <TabsTrigger value="symbols" className="flex-1">Symbols</TabsTrigger>
          <TabsTrigger value="instructions" className="flex-1">Instructions</TabsTrigger>
          <TabsTrigger value="risk" className="flex-1">Risk</TabsTrigger>
        </TabsList>

        <TabsContent value="symbols" className="space-y-3 pt-3">
          <Row label="Symbol prefix" hint="Added before the symbol, e.g. m.XAUUSD">
            <Input value={cfg.symbol_prefix ?? ""} onChange={(e) => patch({ symbol_prefix: e.target.value })} />
          </Row>
          <Row label="Symbol suffix" hint="Added after the symbol, e.g. XAUUSD.pro">
            <Input value={cfg.symbol_suffix ?? ""} onChange={(e) => patch({ symbol_suffix: e.target.value })} />
          </Row>
          <Row label="Symbols to trade" hint="Comma separated. Empty means all.">
            <Input value={(cfg.symbols_allow ?? []).join(", ")} onChange={(e) => patch({ symbols_allow: splitList(e.target.value) })} />
          </Row>
          <Row label="Symbols to avoid" hint="Comma separated.">
            <Input value={(cfg.symbols_avoid ?? []).join(", ")} onChange={(e) => patch({ symbols_avoid: splitList(e.target.value) })} />
          </Row>
        </TabsContent>

        <TabsContent value="instructions" className="space-y-2 pt-3">
          <p className="text-[11px] text-muted-foreground">Turn an instruction off and the copier ignores that kind of follow-up message from this channel.</p>
          {INSTRUCTIONS.map((i) => (
            <label key={i.key} className="flex items-center gap-3 rounded-md border border-border/70 p-2.5">
              <div className="min-w-0 flex-1">
                <div className="text-sm">{i.label}</div>
                <div className="text-[10px] text-muted-foreground">{i.hint}</div>
              </div>
              <Switch
                checked={map[i.key] !== "ignore"}
                onCheckedChange={(v) => patch({ instruction_map: { ...map, [i.key]: v ? "allow" : "ignore" } })}
                aria-label={i.label}
              />
            </label>
          ))}
        </TabsContent>

        <TabsContent value="risk" className="space-y-3 pt-3">
          <Row label="Trade style">
            <Choice value={cfg.trade_style} onChange={(v) => patch({ trade_style: v })}
              options={[["single", "Single entry"], ["range", "Range trading"]]} />
          </Row>
          <Row label="Risk mode">
            <Choice value={cfg.risk_mode} onChange={(v) => patch({ risk_mode: v })}
              options={[["fixed", "Fixed lot"], ["dynamic", "% of balance"]]} />
          </Row>
          {cfg.risk_mode === "dynamic" ? (
            <Row label="Risk per signal (%)" hint="Keep this low — 0.5% to 1% keeps drawdown controlled.">
              <Input type="number" step="0.1" value={cfg.dynamic_percent ?? 0} onChange={(e) => patch({ dynamic_percent: Number(e.target.value) })} />
            </Row>
          ) : (
            <Row label="Fixed lot">
              <Input type="number" step="0.01" value={cfg.fixed_lot ?? 0.01} onChange={(e) => patch({ fixed_lot: Number(e.target.value) })} />
            </Row>
          )}
          <Row label="Single take profit target" hint="Used when the channel only sends one target.">
            <Choice value={cfg.single_tp_target} onChange={(v) => patch({ single_tp_target: v })}
              options={[["tp1", "First target"], ["last", "Final target"]]} />
          </Row>
          <Toggle label="Use the entry price from the signal" checked={cfg.use_signal_entry} onChange={(v) => patch({ use_signal_entry: v })} />
          <Toggle label="Move stop to break-even automatically" checked={cfg.be_enabled} onChange={(v) => patch({ be_enabled: v })} />
          {cfg.be_enabled && (
            <Row label="Break-even offset (pips)">
              <Input type="number" step="0.5" value={cfg.be_offset_pips ?? 5} onChange={(e) => patch({ be_offset_pips: Number(e.target.value) })} />
            </Row>
          )}
          <Toggle label="Close the trade on an opposite signal" checked={cfg.close_on_opposite_signal} onChange={(v) => patch({ close_on_opposite_signal: v })} />
          <Toggle label="Reverse the signal direction" checked={cfg.reverse_signal} onChange={(v) => patch({ reverse_signal: v })} />
        </TabsContent>
      </Tabs>

      <Button className="w-full" onClick={save} disabled={saving}>{saving ? "Saving…" : "Save channel rules"}</Button>
    </div>
  );
}

function splitList(v: string) {
  return v.split(",").map((s) => s.trim().toUpperCase()).filter(Boolean);
}
function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <div className="text-xs font-medium">{label}</div>
      {children}
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-3 rounded-md border border-border/70 p-2.5">
      <span className="flex-1 text-sm">{label}</span>
      <Switch checked={!!checked} onCheckedChange={onChange} aria-label={label} />
    </label>
  );
}
function Choice({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: [string, string][] }) {
  return (
    <div className="flex gap-1.5">
      {options.map(([v, label]) => (
        <button key={v} onClick={() => onChange(v)}
          className={`flex-1 rounded-md border px-3 py-1.5 text-xs ${value === v ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground"}`}>
          {label}
        </button>
      ))}
    </div>
  );
}
