import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Building2, Copy, Pencil, Plus, Power, RefreshCw, ShieldCheck, Trash2, Wallet } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { notifyRowsChanged, useRealtimeRows } from "@/lib/hooks";
import { supabase } from "@/integrations/supabase/client";
import { fmtUSD } from "@/lib/format";

const db = supabase as any;
export const MAX_BROKER_ACCOUNTS = 5;

type BrokerAccount = {
  id: string; label: string | null; platform: string; login: string; server: string;
  broker_name: string | null; account_type: string | null; is_active: boolean;
  copy_enabled: boolean; health_status: string | null; initial_balance: number | null;
  current_balance: number | null; current_equity: number | null; created_at: string;
  terminal_path: string | null; last_seen_at: string | null;
};

export const Route = createFileRoute("/brokers")({
  head: () => ({ meta: [
    { title: "Brokers — GoldCopier" },
    { name: "description", content: "Connect up to 5 MT4/MT5 accounts and copy every valid signal to the accounts you choose." },
    { property: "og:title", content: "Brokers — GoldCopier" },
    { property: "og:description", content: "Connect up to 5 MT4/MT5 accounts and copy every valid signal to the accounts you choose." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: BrokersPage,
});

function BrokersPage() {
  const brokers = useRealtimeRows<BrokerAccount>("broker_accounts", { col: "created_at" }, 20);
  const [connectOpen, setConnectOpen] = useState(false);
  const [editing, setEditing] = useState<BrokerAccount | null>(null);
  const [selected, setSelected] = useState<BrokerAccount | null>(null);
  const atLimit = brokers.length >= MAX_BROKER_ACCOUNTS;

  const patch = async (broker: BrokerAccount, values: Partial<BrokerAccount>) => {
    const { error } = await db.from("broker_accounts").update(values).eq("id", broker.id);
    if (error) toast.error(error.message);
    notifyRowsChanged("broker_accounts");
  };
  const remove = async (broker: BrokerAccount) => {
    if (!confirm(`Remove ${broker.label ?? broker.login}?`)) return;
    const { error } = await db.from("broker_accounts").delete().eq("id", broker.id);
    if (error) toast.error(error.message); else toast.success("Broker account removed");
    notifyRowsChanged("broker_accounts");
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-display font-bold">Brokers</h1>
            <p className="mt-1 text-sm text-muted-foreground">Connect up to {MAX_BROKER_ACCOUNTS} accounts. Every valid signal is copied to each connected account with copying switched on.</p>
          </div>
          <Button onClick={() => setConnectOpen(true)} disabled={atLimit}><Plus /> Connect account</Button>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Summary label="Accounts" value={`${brokers.length}/${MAX_BROKER_ACCOUNTS}`} icon={Building2} />
          <Summary label="Connected" value={String(brokers.filter((b) => b.is_active).length)} icon={ShieldCheck} />
          <Summary label="Copying" value={String(brokers.filter((b) => b.is_active && b.copy_enabled).length)} icon={Copy} />
          <Summary label="Total balance" value={fmtUSD(brokers.reduce((sum, b) => sum + Number(b.current_balance ?? 0), 0))} icon={Wallet} />
        </div>

        {atLimit && <p className="text-xs text-muted-foreground">Account limit reached — remove an account before connecting another.</p>}

        {brokers.length === 0 ? (
          <div className="surface-card p-10 text-center">
            <Building2 className="mx-auto size-8 text-gold" />
            <h2 className="mt-3 font-semibold">No broker accounts</h2>
            <p className="mt-1 text-sm text-muted-foreground">Connect your first MT5 account to begin copying signals.</p>
            <Button className="mt-4" onClick={() => setConnectOpen(true)}><Plus /> Connect account</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">{brokers.map((broker) => (
            <article key={broker.id} className="surface-card p-4">
              <div className="flex items-start gap-3">
                <div className="flex size-10 items-center justify-center rounded-md bg-gold/10 text-gold"><Building2 className="size-5" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="truncate font-semibold">{broker.label ?? `Account ${broker.login}`}</h2>
                    {broker.id === brokers[brokers.length - 1]?.id && <span className="rounded bg-gold/15 px-1.5 py-0.5 text-[10px] text-gold">Main</span>}
                    <span className={`rounded px-1.5 py-0.5 text-[10px] ${broker.is_active ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>{broker.is_active ? (broker.health_status === "online" ? "Online" : "Enabled") : "Disabled"}</span>
                    <span className={`rounded px-1.5 py-0.5 text-[10px] ${broker.is_active && broker.copy_enabled ? "bg-gold/15 text-gold" : "bg-muted text-muted-foreground"}`}>{broker.is_active && broker.copy_enabled ? "Copying ON" : "Copying OFF"}</span>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{broker.platform.toUpperCase()} · {broker.broker_name ?? broker.server}</p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                <Info label="Login" value={broker.login} />
                <Info label="Account type" value={broker.account_type ?? "—"} />
                <Info label="Balance" value={fmtUSD(broker.current_balance ?? broker.initial_balance)} />
                <Info label="Equity" value={fmtUSD(broker.current_equity)} />
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-border/70 pt-3">
                <label className="flex items-center gap-2 text-xs">
                  <Switch checked={broker.is_active} onCheckedChange={(v) => patch(broker, { is_active: v })} aria-label="Connect account" />
                  <span className="text-muted-foreground">Connected</span>
                </label>
                <label className="flex items-center gap-2 text-xs">
                  <Switch checked={broker.copy_enabled} onCheckedChange={(v) => patch(broker, { copy_enabled: v })} aria-label="Copy signals to this account" />
                  <span className="text-muted-foreground">Copy signals</span>
                </label>
                <Button size="sm" variant="outline" onClick={() => setSelected(broker)}>Details</Button>
                <Button size="sm" variant="outline" onClick={() => { setEditing(broker); setConnectOpen(true); }}><Pencil className="size-3.5" /> Edit</Button>
                <Button size="icon" variant="ghost" className="ml-auto text-destructive" onClick={() => remove(broker)} aria-label="Remove broker"><Trash2 /></Button>
              </div>
            </article>
          ))}</div>
        )}
        <p className="text-[11px] text-muted-foreground">Changes apply to the VPS automatically within a few seconds — no need to re-download the ZIP. Accounts switched off stop receiving new signals; already-open trades are left untouched.</p>
      </div>
      <ConnectBrokerDialog open={connectOpen} onOpenChange={(o) => { setConnectOpen(o); if (!o) setEditing(null); }} count={brokers.length} editing={editing} />
      <BrokerDetail broker={selected} onOpenChange={(open) => { if (!open) setSelected(null); }} />
    </AppShell>
  );
}

const EMPTY_FORM = { label: "", platform: "mt5", login: "", password: "", server: "", broker: "", terminal: "" };

function ConnectBrokerDialog({ open, onOpenChange, count, editing }: { open: boolean; onOpenChange: (open: boolean) => void; count: number; editing?: BrokerAccount | null }) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  useEffect(() => {
    if (!open) return;
    setForm(editing ? { label: editing.label ?? "", platform: editing.platform, login: editing.login, password: "", server: editing.server, broker: editing.broker_name ?? "", terminal: editing.terminal_path ?? "" } : EMPTY_FORM);
  }, [open, editing]);
  const save = async () => {
    if (!editing && count >= MAX_BROKER_ACCOUNTS) return toast.error(`Maximum of ${MAX_BROKER_ACCOUNTS} accounts reached`);
    if (!form.login.trim() || !form.server.trim() || (!editing && !form.password)) return toast.error("Login, password and server are required");
    if (!/^\d+$/.test(form.login.trim())) return toast.error("MT login must be a number");
    setSaving(true);
    const values: Record<string, unknown> = {
      label: form.label || null, platform: form.platform, login: form.login.trim(), server: form.server.trim(),
      broker_name: form.broker || null, terminal_path: form.terminal.trim() || null,
    };
    if (form.password) values.password_encrypted = form.password;
    // The first (oldest) account is automatically mirrored into Settings by the database.
    const res = editing
      ? await db.from("broker_accounts").update(values).eq("id", editing.id).select("id")
      : await db.from("broker_accounts").insert({ ...values, is_active: true, copy_enabled: true, health_status: "pending" }).select("id");
    setSaving(false);
    if (res.error || !res.data?.length) return toast.error(res.error?.message ?? "Could not save the account");
    notifyRowsChanged("broker_accounts");
    toast.success(editing ? "Account updated" : "Account saved. The VPS bridge will verify the connection.");
    onOpenChange(false);
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit trading account" : "Connect a new trading account"}</DialogTitle>
          <DialogDescription>{editing ? "Leave the password blank to keep the saved one." : `Add an MT5 account from any broker (${count}/${MAX_BROKER_ACCOUNTS} used).`}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <Field label="Account label" value={form.label} onChange={(label) => setForm((f) => ({ ...f, label }))} placeholder="Gold account" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="MT5 login" value={form.login} onChange={(login) => setForm((f) => ({ ...f, login }))} placeholder="12345678" />
            <Field label="Broker" value={form.broker} onChange={(broker) => setForm((f) => ({ ...f, broker }))} placeholder="Broker name" />
          </div>
          <Field label="Password" type="password" value={form.password} onChange={(password) => setForm((f) => ({ ...f, password }))} placeholder={editing ? "•••••••• (unchanged)" : "Trading password"} />
          <Field label="Broker server" value={form.server} onChange={(server) => setForm((f) => ({ ...f, server }))} placeholder="Broker-Demo" />
          <Field label="MT5 terminal path on VPS (optional for your first account — only needed for 2nd, 3rd… accounts)" value={form.terminal} onChange={(terminal) => setForm((f) => ({ ...f, terminal }))} placeholder="Leave empty for the first account · e.g. C:\\MT5-Account2\\terminal64.exe" />
          <p className="text-[11px] text-muted-foreground">Each extra account needs its own MT5 installation folder on the VPS (MT5 can only log into one account per terminal).</p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button disabled={saving} onClick={save}>{saving ? <RefreshCw className="animate-spin" /> : <Plus />} {editing ? "Save changes" : "Connect account"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BrokerDetail({ broker, onOpenChange }: { broker: BrokerAccount | null; onOpenChange: (open: boolean) => void }) {
  const pnl = Number(broker?.current_equity ?? 0) - Number(broker?.initial_balance ?? broker?.current_balance ?? 0);
  return (
    <Sheet open={!!broker} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>{broker?.label ?? "Broker account"}</SheetTitle>
          <SheetDescription>{broker?.broker_name ?? broker?.server} · #{broker?.login}</SheetDescription>
        </SheetHeader>
        {broker && (
          <div className="mt-6 space-y-5">
            <div className="grid grid-cols-2 gap-3">
              <DetailStat label="Current balance" value={fmtUSD(broker.current_balance)} />
              <DetailStat label="Current equity" value={fmtUSD(broker.current_equity)} />
              <DetailStat label="Total P/L" value={fmtUSD(pnl, { sign: true })} />
              <DetailStat label="Account type" value={broker.account_type ?? "—"} />
            </div>
            <div className="surface-card p-4">
              <h3 className="text-sm font-semibold">Connection</h3>
              <div className="mt-3 space-y-2 text-xs">
                <Info label="Platform" value={broker.platform.toUpperCase()} />
                <Info label="Server" value={broker.server} />
                <Info label="Health" value={broker.health_status ?? "Pending verification"} />
                <Info label="Copying signals" value={broker.copy_enabled ? "On" : "Off"} />
                <Info label="Bridge id" value={broker.id} />
              </div>
              <p className="mt-3 text-[11px] text-muted-foreground">
                Run one bridge per account on your VPS with <code>BROKER_ACCOUNT_ID={broker.id}</code> in its .env — it only executes signals routed to this account.
              </p>
            </div>
            <Button className="w-full" variant="outline" asChild><Link to="/execution-audit"><Power className="mr-1 size-4" /> View execution audit</Link></Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Field({ label, value, onChange, placeholder, type = "text" }: { label: string; value: string; onChange: (value: string) => void; placeholder: string; type?: string }) { return <label className="space-y-1.5 text-xs font-medium"><span>{label}</span><input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></label>; }
function Summary({ label, value, icon: Icon }: { label: string; value: string; icon: any }) { return <div className="surface-card p-3"><div className="flex items-center justify-between text-[10px] uppercase text-muted-foreground"><span>{label}</span><Icon className="size-3.5" /></div><div className="mt-1 text-xl font-bold tabular">{value}</div></div>; }
function Info({ label, value }: { label: string; value: string }) { return <div className="flex items-center justify-between gap-3"><span className="text-muted-foreground">{label}</span><span className="truncate text-right font-medium tabular">{value}</span></div>; }
function DetailStat({ label, value }: { label: string; value: string }) { return <div className="surface-card p-3"><div className="text-[10px] uppercase text-muted-foreground">{label}</div><div className="mt-1 font-semibold tabular">{value}</div></div>; }
