import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { AuditLog } from "@/components/AuditLog";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/audit")({
  head: () => ({ meta: [{ title: "Signal Audit — GoldCopier Pro" }, { name: "description", content: "Per-signal audit log of entries, target hits, breakeven, cancellations and manual closes." }] }),
  component: AuditPage,
});

function AuditPage() {
  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold">Audit Log</h1>
          <Link to="/" className="text-xs text-muted-foreground flex items-center gap-1"><ArrowLeft className="size-3" /> Dashboard</Link>
        </div>
        <AuditLog />
      </div>
    </AppShell>
  );
}
