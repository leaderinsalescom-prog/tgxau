import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { SignalsFeed } from "@/components/SignalsFeed";
import { ScrollText } from "lucide-react";

export const Route = createFileRoute("/copier-logs")({
  head: () => ({
    meta: [
      { title: "Copier Logs — GoldCopier" },
      { name: "description", content: "Every received signal with executed, skipped, update and review status." },
      { property: "og:title", content: "Copier Logs — GoldCopier" },
      { property: "og:description", content: "Every received signal with executed, skipped, update and review status." },
    ],
  }),
  component: CopierLogsPage,
});

function CopierLogsPage() {
  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20">
            <ScrollText className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Copier Logs</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Recent signals: executed, skipped, updates and manual review.</p>
          </div>
        </div>
        <SignalsFeed />
      </div>
    </AppShell>
  );
}
