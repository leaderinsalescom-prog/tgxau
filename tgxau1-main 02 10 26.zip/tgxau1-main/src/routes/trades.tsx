import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { AuditLog } from "@/components/AuditLog";
import { Activity } from "lucide-react";

export const Route = createFileRoute("/trades")({
  head: () => ({
    meta: [
      { title: "Trades — GoldCopier" },
      { name: "description", content: "Every signal-to-trade lifecycle with fills, targets, breakeven and outcome." },
      { property: "og:title", content: "Trades — GoldCopier" },
      { property: "og:description", content: "Every signal-to-trade lifecycle with fills, targets, breakeven and outcome." },
    ],
  }),
  component: TradesPage,
});

function TradesPage() {
  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20">
            <Activity className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Trades</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Full signal audit &amp; trade outcomes across all accounts.</p>
          </div>
        </div>
        <AuditLog />
      </div>
    </AppShell>
  );
}
