import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useRealtimeRows, useSingleton } from "@/lib/hooks";
import { supabase } from "@/integrations/supabase/client";
import { fmtDateAST } from "@/lib/format";
import type { Signal, Settings } from "@/lib/types";
import { ArrowLeft, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const db = supabase as any;

export const Route = createFileRoute("/review")({
  head: () => ({ meta: [{ title: "Manual Review — GoldCopier Pro" }, { name: "description", content: "Review low-confidence signals awaiting execution." }] }),
  component: ReviewPage,
});

function ReviewPage() {
  const signals = useRealtimeRows<Signal>("signals", { col: "created_at" }, 200);
  const settings = useSingleton<Settings>("settings", {} as Settings);
  const pending = signals.filter((s) => s.manual_review && !s.executed);
  const [busyId, setBusyId] = useState<string | null>(null);

  const execute = async (s: Signal) => {
    if (!s.direction) { toast.error("Signal has no direction — dismiss instead"); return; }
    setBusyId(s.id);
    const st: any = settings ?? {};
    const { error } = await db.from("pending_actions").insert({
      action: "open",
      payload: {
        signal_id: s.id,
        channel_name: s.channel_name,
        direction: s.direction,
        entry: s.entry,
        entry_type: s.entry_type,
        sl: s.sl,
        tp: s.tp,
        tp_type: s.tp_type,
        lot_size: st.lot_size ?? 0.01,
        position_count: st.position_count ?? 2,
        trading_mode: st.trading_mode ?? "quick_100",
        scalping_position_count: st.scalping_position_count ?? 10,
        scalping_pip_target: st.scalping_pip_target ?? 50,
        hybrid_pip_target: st.hybrid_pip_target ?? 100,
        quick_pip_target: st.quick_pip_target ?? 100,
        symbol: st.instrument ?? "XAUUSD",
        manual_override: true,
      },
    });
    if (error) { setBusyId(null); return toast.error(error.message); }
    await db.from("signals").update({ manual_review: false, executed: true }).eq("id", s.id);
    toast.success("Queued for execution");
    setBusyId(null);
  };

  const dismiss = async (s: Signal) => {
    setBusyId(s.id);
    const { error } = await db.from("signals").update({ manual_review: false }).eq("id", s.id);
    setBusyId(null);
    if (error) return toast.error(error.message);
    toast.success("Dismissed");
  };

  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold">Manual Review</h1>
          <Link to="/" className="text-xs text-muted-foreground flex items-center gap-1"><ArrowLeft className="size-3" /> Dashboard</Link>
        </div>
        <p className="text-xs text-muted-foreground">
          Signals with confidence below your threshold ({((settings.min_confidence ?? 0.7) * 100).toFixed(0)}%) wait here for approval.
        </p>

        {pending.length === 0 ? (
          <div className="surface-card p-10 text-center text-sm text-muted-foreground">
            No signals awaiting review.
          </div>
        ) : (
          <div className="space-y-3">
            {pending.map((s) => (
              <div key={s.id} className="surface-card p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-sm">
                    {s.direction && (
                      <span className={`font-semibold ${s.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg"}`}>{s.direction}</span>
                    )}
                    <span className="text-xs text-muted-foreground truncate max-w-[160px]">{s.channel_name || "—"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] tabular px-1.5 py-0.5 rounded bg-warning/15 text-warning">
                      {((s.confidence ?? 0) * 100).toFixed(0)}%
                    </span>
                    <span className="text-[10px] text-muted-foreground">{fmtDateAST(s.created_at)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs tabular">
                  <Field k="Entries" v={s.entry?.join(" · ") ?? "—"} />
                  <Field k="Entry type" v={s.entry_type ?? "—"} />
                  <Field k="Stop loss" v={s.sl?.toString() ?? "—"} />
                  <Field k="Take profits" v={s.tp?.join(" · ") ?? "—"} />
                  <Field k="TP type" v={s.tp_type ?? "—"} />
                  <Field k="Format" v={s.source_format ?? "—"} />
                </div>

                <details className="rounded border border-border/60 bg-muted/30 p-2">
                  <summary className="cursor-pointer text-[10px] uppercase tracking-wider text-muted-foreground">Raw message</summary>
                  <pre className="mt-2 text-[11px] whitespace-pre-wrap break-words">{s.raw_message}</pre>
                </details>

                <div className="flex gap-2 pt-1">
                  <button
                    disabled={busyId === s.id || !s.direction}
                    onClick={() => execute(s)}
                    className="flex-1 rounded-lg bg-gold-gradient text-primary-foreground text-sm font-semibold py-2 shadow-[var(--shadow-gold)] disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    {busyId === s.id ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
                    Execute Now
                  </button>
                  <button
                    disabled={busyId === s.id}
                    onClick={() => dismiss(s)}
                    className="flex-1 rounded-lg border border-border bg-card hover:bg-accent text-sm py-2 disabled:opacity-50 flex items-center justify-center gap-1.5"
                  >
                    <XCircle className="size-4" /> Dismiss
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Field({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className="text-[11px] break-words">{v}</div>
    </div>
  );
}
