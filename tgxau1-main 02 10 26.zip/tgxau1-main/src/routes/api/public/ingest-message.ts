import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { fastParse } from "@/lib/fast-parse";
import { parseInstruction } from "@/lib/parse-instruction";

const Body = z.object({
  text: z.string().min(1).max(4000),
  channel_id: z.string().min(1).max(128),
  channel_name: z.string().min(1).max(255).optional(),
  dry_run: z.boolean().optional(),
});

export const Route = createFileRoute("/api/public/ingest-message")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const t0 = Date.now();
        let body: z.infer<typeof Body>;
        try {
          body = Body.parse(await request.json());
        } catch (e: any) {
          return Response.json({ error: "invalid_input", details: e?.message }, { status: 400 });
        }

        // Management instruction lane ("COLLECT HALF SET BREAKEVEN — HOLD FOR TP",
        // "SL to breakeven", "close all"…). These manage positions that are
        // already running and must reach the bridge immediately.
        const instruction = parseInstruction(body.text);
        if (instruction) {
          if (body.dry_run) {
            return Response.json({ instruction, dry_run: true, ms: Date.now() - t0 });
          }
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const managePayload = {
            channel_id: body.channel_id,
            channel_name: body.channel_name ?? null,
            ops: instruction.ops,
            symbol: instruction.symbol,
            direction: instruction.direction,
            raw: body.text,
          };
          // Management protects trades that are already open, so it goes to every
          // connected account (even ones with copying OFF), one row per bridge.
          // Same command re-delivered (Telegram reconnect / edit) within 60 s → act once.
          const since = new Date(Date.now() - 60_000).toISOString();
          const [{ data: activeAccs }, { data: recent }] = await Promise.all([
            supabaseAdmin.from("broker_accounts").select("id").eq("is_active", true),
            supabaseAdmin.from("pending_actions").select("id").eq("action", "manage")
              .eq("payload->>channel_id", body.channel_id).eq("payload->>raw", body.text)
              .gte("created_at", since).limit(1),
          ]);
          if ((recent ?? []).length) {
            return Response.json({ ok: true, instruction, queued: false, reason: "duplicate_command", ms: Date.now() - t0 });
          }
          const manageRows = (activeAccs ?? []).length
            ? (activeAccs as any[]).map((a) => ({ action: "manage", payload: { ...managePayload, broker_account_id: a.id }, status: "pending" }))
            : [{ action: "manage", payload: managePayload, status: "pending" }];
          const { error: mErr } = await supabaseAdmin.from("pending_actions").insert(manageRows);
          if (mErr) return Response.json({ error: "db_queue", message: mErr.message }, { status: 500 });
          void supabaseAdmin.from("signal_events").insert({
            event_type: "instruction_received",
            channel_name: body.channel_name ?? null,
            detail: { ops: instruction.ops, raw: body.text },
          });
          return Response.json({ ok: true, instruction, queued: true, ms: Date.now() - t0 });
        }

        // Fast filter only after the instruction lane. Management messages often
        // contain no digits, so filtering first used to discard them as junk.
        if (isObviousJunk(body.text)) {
          return Response.json({ ignored: true, reason: "junk_filter" });
        }

        // Fast lane: deterministic regex parser (sub-millisecond). Only fall
        // back to the AI parser when it can't produce a confident result.
        let parser: "fast" | "ai" = "fast";
        let parsed: any = fastParse(body.text);
        if (!parsed) {
          parser = "ai";
          try {
            const { parseSignalDirect } = await import("@/lib/parse-signal.server");
            parsed = await parseSignalDirect(body.text);
          } catch (e: any) {
            return Response.json({ error: "parser_failed", message: String(e?.message ?? e) }, { status: 500 });
          }
        }

        if (body.dry_run) {
          return Response.json({ parsed, parser, dry_run: true, ms: Date.now() - t0 });
        }


        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Save the signal and read settings concurrently — they don't depend
        // on each other, so serialising them just added a round-trip.
        const [signalRes, settingsRes, targetsRes] = await Promise.all([
          supabaseAdmin.from("signals").insert({
            channel_id: body.channel_id,
            channel_name: body.channel_name ?? null,
            raw_message: body.text,
            valid: parsed.valid,
            direction: parsed.direction,
            entry: parsed.entry?.length ? parsed.entry : null,
            entry_type: parsed.entry_type,
            sl: parsed.sl,
            tp: parsed.tp?.length ? parsed.tp : null,
            tp_type: parsed.tp_type,
            risk: parsed.risk,
            confidence: parsed.confidence,
            source_format: parsed.source_format,
            parse_reason: parsed.parse_reason,
          }).select("id").single(),
          supabaseAdmin.from("settings").select("*").eq("id", 1).maybeSingle(),
          // Account routing runs in parallel too — it only depends on the channel.
          resolveTargets(supabaseAdmin, body.channel_id),
        ]);

        const { data: signal, error: sigErr } = signalRes;
        if (sigErr) return Response.json({ error: "db_signal", message: sigErr.message }, { status: 500 });

        const settings = settingsRes.data;
        const minConf = (settings as any)?.min_confidence ?? 0.7;
        const liveEnabled = (settings as any)?.live_enabled === true;
        const shouldExecute = parsed.valid && parsed.confidence >= minConf && liveEnabled && parsed.direction;

        if (shouldExecute) {
          const s: any = settings ?? {};
          const targets = targetsRes;
          if (targets === "muted") {
            return Response.json({ ok: true, signal_id: signal!.id, parsed, parser, queued: false, reason: "channel_muted", ms: Date.now() - t0 });
          }
          const basePayload = {
              signal_id: signal!.id,
              channel_name: body.channel_name ?? null,
              direction: parsed.direction,
              entry: parsed.entry,
              entry_type: parsed.entry_type,
              sl: parsed.sl,
              tp: parsed.tp,
              tp_type: parsed.tp_type,
              lot_size: s.lot_size ?? 0.01,
              position_count: s.position_count ?? 2,
              trading_mode: s.trading_mode ?? "quick_100",
              execution_mode: s.execution_mode === "instant" ? "instant" : "limit",
              scalping_position_count: s.scalping_position_count ?? 10,
              scalping_pip_target: s.scalping_pip_target ?? 50,
              scalping_time_exit_minutes: s.scalping_time_exit_minutes ?? 10,
              scalping_trail_enabled: s.scalping_trail_enabled ?? true,
              scalping_trail_style: s.scalping_trail_style ?? "structure",
              scalping_trail_ema_period: s.scalping_trail_ema_period ?? 21,
              scalping_trail_aggressive_multiplier: s.scalping_trail_aggressive_multiplier ?? 3,
              scalping_trail_be_offset_pips: s.scalping_trail_be_offset_pips ?? 10,
              hybrid_pip_target: s.hybrid_pip_target ?? 100,
              quick_pip_target: s.quick_pip_target ?? 100,
              symbol: s.instrument ?? "XAUUSD",
              half_close_mode: s.half_close_mode ?? "auto",
              half_close_pips: s.half_close_pips ?? 40,
              breakeven_enabled: s.breakeven_enabled ?? true,
              breakeven_offset_pips: s.breakeven_offset_pips ?? 5,
              layering_enabled: s.layering_enabled === true,
              marginal_entry_enabled: s.marginal_entry_enabled === true,
              marginal_entry_pips: Number(s.marginal_entry_pips ?? 5),
          };

          // One queued order per receiving account. With no routing rows the
          // single legacy bridge picks the action up (broker_account_id null).
          const rows = targets.length
            ? targets.map((id) => ({ action: "open", payload: { ...basePayload, broker_account_id: id } }))
            : [{ action: "open", payload: basePayload }];
          const { error: queueErr } = await supabaseAdmin.from("pending_actions").insert(rows);
          if (queueErr) return Response.json({ error: "db_queue", message: queueErr.message }, { status: 500 });
        }

        // Low-confidence flagging is not on the execution path — don't await it.
        if (parsed.valid && parsed.confidence < minConf) {
          void supabaseAdmin.from("signals").update({ manual_review: true }).eq("id", signal!.id);
        }

        return Response.json({
          ok: true, signal_id: signal!.id, parsed, parser,
          queued: shouldExecute, ms: Date.now() - t0,
        });
      },
    },
  },
});

/**
 * Which broker accounts should receive this channel's signals.
 * "muted" -> the channel exists but is switched off, nothing is placed.
 * "muted" is also returned when accounts exist but none has copying ON.
 * []      -> no broker accounts at all: fall back to the single legacy bridge.
 */
async function resolveTargets(admin: any, channelId: string): Promise<string[] | "muted"> {
  if (!channelId || channelId === "manual") return [];
  const [chanRes, routeRes, brokerRes] = await Promise.all([
    admin.from("channels").select("id,is_selected").eq("id", channelId).maybeSingle(),
    admin.from("channel_brokers").select("broker_account_id,enabled").eq("channel_id", channelId),
    admin.from("broker_accounts").select("id,is_active,copy_enabled"),
  ]);
  if (chanRes.data && chanRes.data.is_selected === false) return "muted";

  const live = new Set(
    ((brokerRes.data ?? []) as any[]).filter((b) => b.is_active && b.copy_enabled).map((b) => b.id as string),
  );
  // No broker accounts at all → legacy single-bridge setup (bridge uses Settings creds).
  // Accounts exist but every one has copying OFF → place nothing anywhere.
  if (!live.size) return (brokerRes.data ?? []).length ? "muted" : [];
  const routed = ((routeRes.data ?? []) as any[])
    .filter((r) => r.enabled && live.has(r.broker_account_id))
    .map((r) => r.broker_account_id as string);
  // No explicit routing for this channel → every account that has copying on.
  return routed.length ? routed : [...live];
}

function isObviousJunk(t: string) {
  const lower = t.toLowerCase();
  const junkPatterns = [/^standby+\b/i, /are you ready\??/i, /new signal coming/i, /join (the )?(backup|vip|premium) channel/i, /^\s*👀+\s*$/, /^\s*ok\s*$/i, /sl hit no more trades/i];
  if (junkPatterns.some((r) => r.test(lower))) return true;
  // No digits at all → no prices
  if (!/\d/.test(t)) return true;
  return false;
}
