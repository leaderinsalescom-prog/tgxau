import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState } from "react";
import { ExternalLink, Newspaper, Search } from "lucide-react";
import { StubPage } from "@/components/StubPage";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { FeedStatus, FilterChips, ImpactDot } from "@/components/FilterChips";
import { getMarketNews, type NewsItem } from "@/lib/market-data.functions";

export const Route = createFileRoute("/market-news")({
  head: () => ({
    meta: [
      { title: "Market News — GoldCopier" },
      { name: "description", content: "Live forex and gold news: central banks, Fed, inflation, jobs and geopolitics, tagged by currency and impact." },
      { property: "og:title", content: "Market News — GoldCopier" },
      { property: "og:description", content: "Near real-time forex and XAUUSD headlines filtered by currency and impact." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MarketNewsPage,
});

const ASSETS = ["all", "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD", "XAU"] as const;
type Asset = (typeof ASSETS)[number];
type ImpactF = "all" | "High" | "Medium" | "Low";
type TimeF = "1h" | "6h" | "24h" | "all";

function ago(iso: string) {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  return h < 24 ? `${h}h ago` : `${Math.round(h / 24)}d ago`;
}

function MarketNewsPage() {
  const fetchNews = useServerFn(getMarketNews);
  const q = useQuery({ queryKey: ["market-news"], queryFn: () => fetchNews(), refetchInterval: 120_000, retry: 2, staleTime: 60_000 });
  const [asset, setAsset] = useState<Asset>("all");
  const [impact, setImpact] = useState<ImpactF>("all");
  const [time, setTime] = useState<TimeF>("all");
  const [sort, setSort] = useState<"latest" | "impact">("latest");
  const [search, setSearch] = useState("");

  // Track what the user has already seen so fresh arrivals get a "NEW" badge.
  const seenRef = useRef<Set<string> | null>(null);
  const [fresh, setFresh] = useState<Set<string>>(new Set());
  useEffect(() => {
    const items = q.data?.items;
    if (!items) return;
    if (seenRef.current === null) {
      seenRef.current = new Set(items.map((i) => i.id));
      return;
    }
    const added = items.filter((i) => !seenRef.current!.has(i.id)).map((i) => i.id);
    added.forEach((id) => seenRef.current!.add(id));
    if (added.length) setFresh((prev) => new Set([...prev, ...added]));
  }, [q.data]);

  const items = useMemo(() => {
    const list = q.data?.items ?? [];
    const cutoff = time === "all" ? 0 : Date.now() - { "1h": 1, "6h": 6, "24h": 24 }[time] * 3_600_000;
    const s = search.trim().toLowerCase();
    const rank = { High: 0, Medium: 1, Low: 2 } as const;
    return list
      .filter((n) => asset === "all" || n.currencies.includes(asset))
      .filter((n) => impact === "all" || n.impact === impact)
      .filter((n) => new Date(n.published).getTime() >= cutoff)
      .filter((n) => !s || n.title.toLowerCase().includes(s) || n.source.toLowerCase().includes(s))
      .sort((a, b) => (sort === "impact" ? rank[a.impact] - rank[b.impact] : 0) || b.published.localeCompare(a.published));
  }, [q.data, asset, impact, time, sort, search]);

  return (
    <StubPage title="Market News" description="Forex & gold headlines, tagged by currency and impact. Auto-refreshes every 2 minutes." icon={Newspaper}>
      <div className="space-y-4">
        <FeedStatus fetchedAt={q.data?.fetchedAt} stale={q.data?.stale} sources={q.data?.sources} isFetching={q.isFetching} onRefresh={() => q.refetch()} />

        <div className="surface-card p-3 sm:p-4 space-y-3">
          <div className="relative">
            <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search headlines or sources…" className="pl-9" />
          </div>
          <FilterChips label="Currency" value={asset} onChange={setAsset} options={ASSETS.map((a) => ({ value: a, label: a === "all" ? "All" : a === "XAU" ? "XAU/USD" : a }))} />
          <FilterChips
            label="Impact"
            value={impact}
            onChange={setImpact}
            options={[{ value: "all", label: "All impact" }, { value: "High", label: "High" }, { value: "Medium", label: "Medium" }, { value: "Low", label: "Low" }]}
          />
          <div className="flex flex-wrap gap-3 justify-between">
            <FilterChips label="Time" value={time} onChange={setTime} options={[{ value: "1h", label: "1h" }, { value: "6h", label: "6h" }, { value: "24h", label: "24h" }, { value: "all", label: "Any time" }]} />
            <FilterChips label="Sort" value={sort} onChange={setSort} options={[{ value: "latest", label: "Latest" }, { value: "impact", label: "Impact" }]} />
          </div>
        </div>

        {q.isLoading ? (
          <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
        ) : q.isError && !q.data ? (
          <div className="surface-card p-8 text-center text-sm text-muted-foreground">
            News is temporarily unavailable. We'll retry automatically.
          </div>
        ) : items.length === 0 ? (
          <div className="surface-card p-8 text-center text-sm text-muted-foreground">
            {(q.data?.items.length ?? 0) === 0 ? "No news sources are responding right now. We'll retry shortly." : "No headlines match these filters."}
          </div>
        ) : (
          <ul className="space-y-2">
            {items.map((n) => (
              <NewsRow key={n.id} n={n} isNew={fresh.has(n.id) || Date.now() - new Date(n.published).getTime() < 30 * 60_000} />
            ))}
          </ul>
        )}
      </div>
    </StubPage>
  );
}

function NewsRow({ n, isNew }: { n: NewsItem; isNew: boolean }) {
  return (
    <li className={`surface-card p-3 sm:p-4 ${isNew ? "ring-1 ring-gold/40" : ""}`}>
      <a href={n.link} target="_blank" rel="noopener noreferrer" className="group block">
        <div className="flex items-start gap-3">
          <div className="pt-1.5"><ImpactDot impact={n.impact} /></div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium leading-snug group-hover:text-gold transition-colors">
              {n.title}
              <ExternalLink className="inline size-3 ml-1 opacity-50" />
            </p>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
              {isNew && <span className="px-1.5 py-0.5 rounded bg-gold/15 text-gold font-semibold">NEW</span>}
              <span>{n.source}</span>
              <span>·</span>
              <time dateTime={n.published} title={new Date(n.published).toLocaleString()}>{ago(n.published)}</time>
              <span>·</span>
              <span>{n.impact} impact</span>
              {n.currencies.map((c) => (
                <span key={c} className="px-1.5 py-0.5 rounded border border-border font-mono text-[10px]">{c === "XAU" ? "XAU/USD" : c}</span>
              ))}
            </div>
          </div>
        </div>
      </a>
    </li>
  );
}
