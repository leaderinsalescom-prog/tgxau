import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ListChecks, Send, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { SignalsFeed } from "@/components/SignalsFeed";
import { fastParse } from "@/lib/fast-parse";
import { parseInstruction } from "@/lib/parse-instruction";

export const Route = createFileRoute("/manage-signals")({
  head: () => ({ meta: [
    { title: "Manage Signals — GoldCopier" },
    { name: "description", content: "Add your own trade signals to the copier feed and review every signal parsed from your channels." },
    { property: "og:title", content: "Manage Signals — GoldCopier" },
    { property: "og:description", content: "Send your own signals to the copier and review every parsed signal in one place." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ManageSignalsPage,
});

function ManageSignalsPage() {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  // Builder fields
  const [dir, setDir] = useState<"BUY" | "SELL">("BUY");
  const [symbol, setSymbol] = useState("XAUUSD");
  const [e1, setE1] = useState("");
  const [e2, setE2] = useState("");
  const [sl, setSl] = useState("");
  const [tp, setTp] = useState("");

  const build = () => {
    const entry = [e1, e2].filter(Boolean).join("-");
    const lines = [
      `${symbol.toUpperCase()} ${dir}${entry ? ` ${entry}` : " NOW"}`,
      sl ? `SL ${sl}` : "",
      tp ? `TP ${tp}` : "",
    ].filter(Boolean);
    setText(lines.join("\n"));
  };

  const instr = text.trim() ? parseInstruction(text) : null;
  const parsed = instr ? null : text.trim() ? fastParse(text) : null;

  const send = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      const res = await fetch("/api/public/ingest-message", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ text, channel_id: "manual", channel_name: "My signals" }),
      });
      const json: any = await res.json();
      if (!res.ok) throw new Error(json?.message ?? json?.error ?? "Could not send");
      if (json.ignored) toast.warning("That message was not read as a signal or an instruction.");
      else if (json.queued) toast.success("Signal sent — the order is on its way to your account.");
      else toast.info("Saved to the feed. Nothing was placed (automatic copying is off or confidence is low).");
      setText("");
    } catch (e: any) {
      toast.error(e?.message ?? "Could not send");
    } finally {
      setSending(false);
    }
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20"><ListChecks className="size-5" /></div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Manage Signals</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Send your own signals to the copier, or review everything your channels sent.</p>
          </div>
        </div>

        <section className="surface-card p-4 space-y-4">
          <h2 className="text-sm font-semibold">Add your own signal</h2>

          <div className="grid gap-2 sm:grid-cols-6">
            <div className="sm:col-span-2 flex gap-1.5">
              {(["BUY", "SELL"] as const).map((d) => (
                <button key={d} onClick={() => setDir(d)}
                  className={`flex-1 rounded-md border px-3 py-2 text-xs font-semibold ${dir === d ? (d === "BUY" ? "border-pnl-pos bg-pnl-pos/10 text-pnl-pos" : "border-pnl-neg bg-pnl-neg/10 text-pnl-neg") : "border-border text-muted-foreground"}`}>
                  {d}
                </button>
              ))}
            </div>
            <Input className="sm:col-span-2" value={symbol} onChange={(e) => setSymbol(e.target.value)} placeholder="Symbol" aria-label="Symbol" />
            <Input className="sm:col-span-1" value={e1} onChange={(e) => setE1(e.target.value)} placeholder="Entry 1" aria-label="First entry" />
            <Input className="sm:col-span-1" value={e2} onChange={(e) => setE2(e.target.value)} placeholder="Entry 2" aria-label="Second entry" />
            <Input className="sm:col-span-3" value={sl} onChange={(e) => setSl(e.target.value)} placeholder="Stop loss" aria-label="Stop loss" />
            <Input className="sm:col-span-3" value={tp} onChange={(e) => setTp(e.target.value)} placeholder="Take profit (4432 or 4432, 4450)" aria-label="Take profit" />
          </div>
          <Button size="sm" variant="outline" onClick={build}><Wand2 /> Write the message for me</Button>

          <div className="space-y-1">
            <div className="text-xs font-medium">Message</div>
            <Textarea rows={4} value={text} onChange={(e) => setText(e.target.value)}
              placeholder={"XAUUSD BUY 4413-4409\nSL 4403\nTP 4432\n\nOr an instruction: COLLECT HALF SET BREAKEVEN - HOLD FOR TP"} />
            <p className="text-[10px] text-muted-foreground">
              Paste a signal exactly as a channel would write it, or type an instruction for trades already running.
            </p>
          </div>

          <div className="rounded-md bg-muted/40 p-2.5 text-[11px]">
            <div className="text-[9px] uppercase tracking-wider text-muted-foreground">How this will be read</div>
            {instr ? (
              <div className="mt-1 flex flex-wrap gap-1">
                {instr.ops.map((o) => <span key={o.op} className="rounded bg-gold/10 px-1.5 py-0.5 text-[9px] text-gold">{o.op.replace(/_/g, " ")}</span>)}
              </div>
            ) : parsed?.valid ? (
              <div className="mt-1 flex flex-wrap gap-1 text-[9px]">
                <span className="rounded bg-success/15 px-1.5 py-0.5 text-success">{parsed.direction}</span>
                {parsed.entry?.length ? <span className="rounded bg-muted px-1.5 py-0.5">entry {parsed.entry.join(" / ")}</span> : null}
                {parsed.sl != null ? <span className="rounded bg-muted px-1.5 py-0.5">SL {parsed.sl}</span> : null}
                {parsed.tp?.length ? <span className="rounded bg-muted px-1.5 py-0.5">TP {parsed.tp.join(" / ")}</span> : null}
              </div>
            ) : (
              <p className="mt-1 text-muted-foreground">{text.trim() ? "Not readable yet — add a direction, entry, stop loss and target." : "Nothing typed yet."}</p>
            )}
          </div>

          <Button className="w-full" onClick={send} disabled={sending || !text.trim() || (!instr && !parsed?.valid)}>
            <Send /> {sending ? "Sending…" : "Send to copier"}
          </Button>
          <p className="text-[10px] text-muted-foreground">
            Orders are only placed when automatic copying is switched on and a stop loss and target are present.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold">All signals</h2>
          <SignalsFeed />
        </section>
      </div>
    </AppShell>
  );
}
