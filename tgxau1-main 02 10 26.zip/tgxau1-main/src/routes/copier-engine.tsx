import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Activity, Building2, Cpu, Radio, ShieldCheck, Zap } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useBridgeStatus, useRealtimeRows, useSingleton } from "@/lib/hooks";
import { fmtDateAST } from "@/lib/format";
import type { Channel, Settings } from "@/lib/types";

const db = supabase as any;

type BrokerAccount = { id: string; label: string | null; login: string; is_active: boolean; copy_enabled: boolean };
type Routing = { id: string; channel_id: string; broker_account_id: string; enabled: boolean };
type EngineEvent = { id: string; type: string; status: string; message: string | null; channel_id: string | null; created_at: string };

export const Route = createFileRoute("/copier-engine")({
  head: () => ({ meta: [
    { title: "Copier Engine — GoldCopier" },
    { name: "description", content: "Switch on automatic copying, choose how orders are placed and see exactly which channels reach which accounts." },
    { property: "og:title", content: "Copier Engine — GoldCopier" },
    { property: "og:description", content: "Automatic signal copying to every connected account, with live engine activity." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: CopierEnginePage,
});

function CopierEnginePage() {
  const s = useSingleton<Settings | null>("settings", null);
  const bridge = useBridgeStatus();
  const channels = useRealtimeRows<Channel>("channels", { col: "name", asc: true }, 200);
  const brokers = useRealtimeRows<BrokerAccount>("broker_accounts", { col: "created_at", asc: true }, 10);
  const routes = useRealtimeRows<Routing>("channel_brokers", { col: "created_at", asc: true }, 500);
  const events = useRealtimeRows<EngineEvent>("copier_engine_events", { col: "created_at" }, 50);
  const [busy, setBusy] = useState(false);

  const patch = async (values: Partial<Settings>) => {
    setBusy(true);
    const { error } = await db.from("settings").update(values).eq("id", 1);
    setBusy(false);
    if (error) toast.error(error.message);
  };

  const activeChannels = channels.filter((c) => c.is_selected);
  const copyAccounts = brokers.filter((b) => b.is_active && b.copy_enabled);
  const live = s?.live_enabled === true;
  const engineReady = bridge.telegram && bridge.mt5 && copyAccounts.length > 0 && activeChannels.length > 0;

  const copyToAll = async () => {
    const { error } = await db.from("broker_accounts").update({ copy_enabled: true }).eq("is_active", true);
    if (error) toast.error(error.message); else toast.success("Every connected account will now receive signals");
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20"><Cpu className="size-5" /></div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Copier Engine</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Copy every valid signal to your connected accounts automatically.</p>
          </div>
        </div>

        <section className={`surface-card p-4 ${live ? "ring-1 ring-success/40" : ""}`}>
          <div className="flex flex-wrap items-center gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="font-semibold">{live ? "Automatic copying is on" : "Automatic copying is off"}</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {live
                  ? `Valid signals from ${activeChannels.length} channel${activeChannels.length === 1 ? "" : "s"} are placed on ${copyAccounts.length} account${copyAccounts.length === 1 ? "" : "s"} with no manual step.`
                  : "Signals are recorded and parsed, but nothing is placed on your accounts until you switch this on."}
              </p>
            </div>
            <Switch checked={live} onCheckedChange={(v) => patch({ live_enabled: v } as Partial<Settings>)} disabled={busy} aria-label="Automatic copying" />
          </div>

          {live && !engineReady && (
            <p className="mt-3 rounded-md bg-warning/10 p-2 text-[11px] text-warning">
              Copying is on but the engine is not ready:{" "}
              {[!bridge.telegram && "the Telegram listener is offline", !bridge.mt5 && "the trading bridge is offline",
                copyAccounts.length === 0 && "no account has copying switched on", activeChannels.length === 0 && "no channel is selected"]
                .filter(Boolean).join(", ")}.
            </p>
          )}
        </section>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Channels sending" value={String(activeChannels.length)} icon={Radio} />
          <Stat label="Accounts receiving" value={String(copyAccounts.length)} icon={Building2} />
          <Stat label="Telegram" value={bridge.telegram ? "Online" : "Offline"} icon={Activity} ok={bridge.telegram} />
          <Stat label="Trading bridge" value={bridge.mt5 ? "Online" : "Offline"} icon={ShieldCheck} ok={bridge.mt5} />
        </div>

        <section className="surface-card p-4 space-y-4">
          <h2 className="text-sm font-semibold">How orders are placed</h2>
          <div className="grid gap-2 sm:grid-cols-2">
            <ModeCard
              title="Instant" active={s?.execution_mode === "instant"} icon={Zap}
              desc="Fill at the best available market price the moment the signal lands."
              onClick={() => patch({ execution_mode: "instant" } as Partial<Settings>)}
            />
            <ModeCard
              title="Limit orders" active={s?.execution_mode !== "instant"} icon={Activity}
              desc="Place pending orders at the channel's entry prices and wait for price to come to you."
              onClick={() => patch({ execution_mode: "limit" } as Partial<Settings>)}
            />
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <NumField label="Positions per signal" value={s?.position_count ?? 2} step={1}
              onCommit={(v) => patch({ position_count: Math.max(1, Math.round(v)) } as Partial<Settings>)} />
            <NumField label="Lot size" value={s?.lot_size ?? 0.01} step={0.01}
              onCommit={(v) => patch({ lot_size: v } as Partial<Settings>)} />
            <NumField label="Minimum confidence" value={s?.min_confidence ?? 0.7} step={0.05}
              hint="Signals parsed below this score are held for review instead of traded."
              onCommit={(v) => patch({ min_confidence: Math.min(1, Math.max(0, v)) } as Partial<Settings>)} />
          </div>
        </section>

        <section className="surface-card p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold">Channel to account routing</h2>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={copyToAll}>Copy to all accounts</Button>
              <Button size="sm" variant="ghost" asChild><Link to="/channels">Edit channels</Link></Button>
            </div>
          </div>
          {activeChannels.length === 0 ? (
            <p className="text-xs text-muted-foreground">No channel is selected yet. Pick your signal channels first.</p>
          ) : (
            <ul className="space-y-1.5">
              {activeChannels.map((c) => {
                const targets = brokers.filter((b) => routes.some((r) => r.channel_id === c.id && r.broker_account_id === b.id && r.enabled) && b.is_active && b.copy_enabled);
                return (
                  <li key={c.id} className="flex flex-wrap items-center gap-2 rounded-md border border-border/70 p-2.5 text-xs">
                    <span className="min-w-0 flex-1 truncate font-medium">{c.name}</span>
                    {targets.length === 0 ? (
                      <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">No account selected</span>
                    ) : targets.map((t) => (
                      <span key={t.id} className="rounded bg-gold/10 px-1.5 py-0.5 text-[10px] text-gold">{t.label ?? t.login}</span>
                    ))}
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="surface-card p-4 space-y-3">
          <h2 className="text-sm font-semibold">Engine activity</h2>
          {events.length === 0 ? (
            <p className="text-xs text-muted-foreground">Nothing yet — activity appears here as signals are copied.</p>
          ) : (
            <ul className="space-y-1.5 max-h-96 overflow-y-auto">
              {events.map((e) => (
                <li key={e.id} className="rounded-md border border-border/70 p-2.5">
                  <div className="flex items-center gap-2 text-xs">
                    <span className={`rounded px-1.5 py-0.5 text-[10px] ${statusClass(e.status)}`}>{e.status}</span>
                    <span className="font-medium">{e.type.replace(/_/g, " ")}</span>
                    <span className="ml-auto text-[10px] text-muted-foreground">{fmtDateAST(e.created_at)}</span>
                  </div>
                  {e.message && <p className="mt-1 text-[11px] text-muted-foreground">{e.message}</p>}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </AppShell>
  );
}

function statusClass(s: string) {
  if (/ok|success|executed|placed/i.test(s)) return "bg-success/15 text-success";
  if (/error|fail|reject/i.test(s)) return "bg-destructive/15 text-destructive";
  return "bg-muted text-muted-foreground";
}

function Stat({ label, value, icon: Icon, ok }: { label: string; value: string; icon: any; ok?: boolean }) {
  return (
    <div className="surface-card p-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground"><Icon className="size-3.5" /> {label}</div>
      <div className={`mt-1 text-lg font-bold ${ok === undefined ? "" : ok ? "text-success" : "text-muted-foreground"}`}>{value}</div>
    </div>
  );
}

function ModeCard({ title, desc, active, icon: Icon, onClick }: { title: string; desc: string; active: boolean; icon: any; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`rounded-lg border p-3 text-left transition-colors ${active ? "border-gold bg-gold/5" : "border-border hover:bg-accent"}`}>
      <div className="flex items-center gap-2"><Icon className={`size-4 ${active ? "text-gold" : "text-muted-foreground"}`} /><span className="text-sm font-medium">{title}</span></div>
      <p className="mt-1 text-[11px] text-muted-foreground">{desc}</p>
    </button>
  );
}

function NumField({ label, value, step, hint, onCommit }: { label: string; value: number; step: number; hint?: string; onCommit: (v: number) => void }) {
  const [v, setV] = useState<string | null>(null);
  return (
    <div className="space-y-1">
      <div className="text-xs font-medium">{label}</div>
      <Input
        type="number" step={step} value={v ?? String(value)}
        onChange={(e) => setV(e.target.value)}
        onBlur={() => { const n = Number(v ?? value); setV(null); if (isFinite(n) && n !== value) onCommit(n); }}
      />
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
