import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { CalendarClock, Search } from "lucide-react";
import { StubPage } from "@/components/StubPage";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { FeedStatus, FilterChips, ImpactDot } from "@/components/FilterChips";
import { getEconomicCalendar, type CalendarEvent } from "@/lib/market-data.functions";

export const Route = createFileRoute("/economic-calendar")({
  head: () => ({
    meta: [
      { title: "Economic Calendar — GoldCopier" },
      { name: "description", content: "Forex economic calendar: FOMC, CPI, NFP, GDP and central-bank decisions with impact, forecast, previous and actual." },
      { property: "og:title", content: "Economic Calendar — GoldCopier" },
      { property: "og:description", content: "Upcoming and released high-impact forex events in your local time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CalendarPage,
});

const CCY = ["all", "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD"] as const;
type Ccy = (typeof CCY)[number];
type Period = "today" | "tomorrow" | "week" | "next" | "custom";
type ImpactF = "all" | "High" | "Medium" | "Low";

const dayStart = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const addDays = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const toInput = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

function periodRange(p: Period, from: string, to: string): [number, number] {
  const today = dayStart(new Date());
  const mon = addDays(today, -((today.getDay() + 6) % 7));
  switch (p) {
    case "today": return [today.getTime(), addDays(today, 1).getTime()];
    case "tomorrow": return [addDays(today, 1).getTime(), addDays(today, 2).getTime()];
    case "week": return [mon.getTime(), addDays(mon, 7).getTime()];
    case "next": return [addDays(mon, 7).getTime(), addDays(mon, 14).getTime()];
    case "custom": {
      const f = from ? new Date(from + "T00:00").getTime() : 0;
      const t = to ? addDays(new Date(to + "T00:00"), 1).getTime() : Infinity;
      return [f, t];
    }
  }
}

function num(v: string) {
  const m = v.replace(/,/g, "").match(/-?\d+(\.\d+)?/);
  if (!m) return null;
  let n = parseFloat(m[0]);
  if (/K$/i.test(v)) n *= 1e3;
  if (/M$/i.test(v)) n *= 1e6;
  if (/B$/i.test(v)) n *= 1e9;
  return n;
}
function surprise(e: CalendarEvent) {
  const a = num(e.actual), f = num(e.forecast);
  if (a == null || f == null) return null;
  const d = a - f;
  return { d, label: `${d > 0 ? "+" : ""}${Math.round(d * 1000) / 1000}` };
}

function CalendarPage() {
  const fetchCal = useServerFn(getEconomicCalendar);
  const q = useQuery({ queryKey: ["economic-calendar"], queryFn: () => fetchCal(), refetchInterval: 60_000, retry: 2, staleTime: 30_000 });
  const [period, setPeriod] = useState<Period>("week");
  const [ccy, setCcy] = useState<Ccy>("all");
  const [impact, setImpact] = useState<ImpactF>("all");
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [tz, setTz] = useState("");
  const [, tick] = useState(0);

  useEffect(() => {
    setTz(Intl.DateTimeFormat().resolvedOptions().timeZone);
    setFrom(toInput(new Date()));
    setTo(toInput(addDays(new Date(), 7)));
    const id = setInterval(() => tick((x) => x + 1), 30_000); // keep released/upcoming status fresh
    return () => clearInterval(id);
  }, []);

  const events = useMemo(() => {
    const [a, b] = periodRange(period, from, to);
    const s = search.trim().toLowerCase();
    return (q.data?.items ?? []).filter((e) => {
      const t = new Date(e.date).getTime();
      return t >= a && t < b &&
        (ccy === "all" || e.country === ccy) &&
        (impact === "all" || e.impact === impact) &&
        (!s || e.title.toLowerCase().includes(s) || e.country.toLowerCase().includes(s));
    });
  }, [q.data, period, from, to, ccy, impact, search]);

  const groups = useMemo(() => {
    const m = new Map<string, CalendarEvent[]>();
    for (const e of events) {
      const k = new Date(e.date).toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" });
      m.set(k, [...(m.get(k) ?? []), e]);
    }
    return [...m.entries()];
  }, [events]);

  const nextHigh = (q.data?.items ?? []).find((e) => e.impact === "High" && new Date(e.date).getTime() > Date.now());

  return (
    <StubPage title="Economic Calendar" description={`Times shown in your local timezone${tz ? ` (${tz})` : ""}. Updates automatically.`} icon={CalendarClock}>
      <div className="space-y-4">
        <FeedStatus fetchedAt={q.data?.fetchedAt} stale={q.data?.stale} sources={q.data?.sources} isFetching={q.isFetching} onRefresh={() => q.refetch()} />

        {nextHigh && (
          <div className="surface-card p-3 sm:p-4 flex flex-wrap items-center gap-2 text-sm">
            <ImpactDot impact="High" />
            <span className="text-muted-foreground">Next high-impact:</span>
            <span className="font-mono text-xs px-1.5 py-0.5 rounded border border-border">{nextHigh.country}</span>
            <span className="font-medium">{nextHigh.title}</span>
            <span className="text-gold">{countdown(nextHigh.date)}</span>
          </div>
        )}

        <div className="surface-card p-3 sm:p-4 space-y-3">
          <div className="relative">
            <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search events (CPI, FOMC, NFP…)" className="pl-9" />
          </div>
          <FilterChips
            label="Period"
            value={period}
            onChange={setPeriod}
            options={[{ value: "today", label: "Today" }, { value: "tomorrow", label: "Tomorrow" }, { value: "week", label: "This week" }, { value: "next", label: "Next week" }, { value: "custom", label: "Custom" }]}
          />
          {period === "custom" && (
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-auto" aria-label="From date" />
              <span className="text-muted-foreground">to</span>
              <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-auto" aria-label="To date" />
              <span className="text-muted-foreground">Data covers this week and next week.</span>
            </div>
          )}
          <FilterChips label="Currency" value={ccy} onChange={setCcy} options={CCY.map((c) => ({ value: c, label: c === "all" ? "All" : c }))} />
          <FilterChips
            label="Impact"
            value={impact}
            onChange={setImpact}
            options={[{ value: "all", label: "All impact" }, { value: "High", label: "High" }, { value: "Medium", label: "Medium" }, { value: "Low", label: "Low" }]}
          />
        </div>

        {q.isLoading ? (
          <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
        ) : q.isError && !q.data ? (
          <div className="surface-card p-8 text-center text-sm text-muted-foreground">The calendar is temporarily unavailable. We'll retry automatically.</div>
        ) : groups.length === 0 ? (
          <div className="surface-card p-8 text-center text-sm text-muted-foreground">
            {(q.data?.items.length ?? 0) === 0 ? "The calendar source isn't responding right now. We'll retry shortly." : "No events match these filters."}
          </div>
        ) : (
          <div className="space-y-4">
            {groups.map(([day, list]) => (
              <section key={day} className="surface-card overflow-hidden">
                <h2 className="px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground border-b border-border bg-surface/50">{day}</h2>
                <div className="hidden md:grid grid-cols-[70px_60px_1fr_80px_80px_80px_70px] gap-2 px-4 py-2 text-[11px] uppercase text-muted-foreground border-b border-border">
                  <span>Time</span><span>Ccy</span><span>Event</span><span className="text-right">Actual</span><span className="text-right">Forecast</span><span className="text-right">Previous</span><span className="text-right">Surprise</span>
                </div>
                <ul className="divide-y divide-border">{list.map((e) => <EventRow key={e.id} e={e} />)}</ul>
              </section>
            ))}
            <p className="text-xs text-muted-foreground">Source: Forex Factory public calendar export. Actual values appear when the source publishes them.</p>
          </div>
        )}
      </div>
    </StubPage>
  );
}

function countdown(iso: string) {
  const m = Math.round((new Date(iso).getTime() - Date.now()) / 60000);
  if (m < 60) return `in ${m}m`;
  const h = Math.floor(m / 60);
  return h < 24 ? `in ${h}h ${m % 60}m` : `in ${Math.floor(h / 24)}d ${h % 24}h`;
}

function EventRow({ e }: { e: CalendarEvent }) {
  const t = new Date(e.date);
  const released = t.getTime() <= Date.now();
  const allDay = t.getHours() === 0 && t.getMinutes() === 0 && e.impact === "Holiday";
  const time = allDay ? "All day" : t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const s = surprise(e);
  const sCls = s == null ? "text-muted-foreground" : s.d > 0 ? "text-pnl-pos" : s.d < 0 ? "text-pnl-neg" : "text-muted-foreground";
  const actual = e.actual || (released && (e.forecast || e.previous) ? "Awaiting" : "—");
  return (
    <li className={`px-4 py-3 text-sm ${released ? "opacity-80" : ""} ${e.impact === "High" && !released ? "bg-destructive/5" : ""}`}>
      {/* Desktop */}
      <div className="hidden md:grid grid-cols-[70px_60px_1fr_80px_80px_80px_70px] gap-2 items-center">
        <span className="font-mono text-xs">{time}</span>
        <span className="flex items-center gap-1.5 font-mono text-xs"><ImpactDot impact={e.impact} />{e.country}</span>
        <span className="flex items-center gap-2 min-w-0">
          <span className="truncate">{e.title}</span>
          {released && <span className="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success">Released</span>}
        </span>
        <span className={`text-right font-mono ${e.actual ? sCls : "text-muted-foreground"}`}>{actual}</span>
        <span className="text-right font-mono text-muted-foreground">{e.forecast || "—"}</span>
        <span className="text-right font-mono text-muted-foreground">{e.previous || "—"}</span>
        <span className={`text-right font-mono ${sCls}`}>{s?.label ?? "—"}</span>
      </div>
      {/* Mobile */}
      <div className="md:hidden space-y-1.5">
        <div className="flex items-center gap-2">
          <ImpactDot impact={e.impact} />
          <span className="font-mono text-xs">{time}</span>
          <span className="font-mono text-xs px-1.5 rounded border border-border">{e.country}</span>
          {released && <span className="text-[10px] px-1.5 py-0.5 rounded bg-success/15 text-success">Released</span>}
          <span className="ml-auto text-[11px] text-muted-foreground">{e.impact}</span>
        </div>
        <p className="font-medium">{e.title}</p>
        <div className="grid grid-cols-4 gap-2 text-xs">
          <div><p className="text-muted-foreground">Actual</p><p className={`font-mono ${e.actual ? sCls : ""}`}>{actual}</p></div>
          <div><p className="text-muted-foreground">Forecast</p><p className="font-mono">{e.forecast || "—"}</p></div>
          <div><p className="text-muted-foreground">Previous</p><p className="font-mono">{e.previous || "—"}</p></div>
          <div><p className="text-muted-foreground">Surprise</p><p className={`font-mono ${sCls}`}>{s?.label ?? "—"}</p></div>
        </div>
      </div>
    </li>
  );
}
