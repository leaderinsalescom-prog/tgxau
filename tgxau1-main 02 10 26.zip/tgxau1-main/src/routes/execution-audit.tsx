import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ClipboardList } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { RangeTabs } from "@/components/RangeTabs";
import { useRealtimeRows } from "@/lib/hooks";
import { rangeCutoff, type Range as RangeKey } from "@/lib/range";

type AuditRow = {
  id: string;
  signal_id: string | null;
  sig8: string | null;
  broker_login: string | null;
  channel_name: string | null;
  symbol: string | null;
  direction: string | null;
  execution_mode: string | null;
  trading_mode: string | null;
  lot_size: number | null;
  requested_entry: number[] | null;
  sl: number | null;
  tps: number[] | null;
  order_tickets: number[] | null;
  position_tickets: number[] | null;
  status: string;
  outcome: string | null;
  pnl_usd: number | null;
  pnl_pips: number | null;
  error: string | null;
  created_at: string;
};

export const Route = createFileRoute("/execution-audit")({
  head: () => ({ meta: [
    { title: "Execution Audit — GoldCopier" },
    { name: "description", content: "Every parsed signal, MT5 order and position ID, TP/SL values and final outcome per trade attempt." },
    { property: "og:title", content: "Execution Audit — GoldCopier" },
    { property: "og:description", content: "Every parsed signal, MT5 order and position ID, TP/SL values and final outcome per trade attempt." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ExecutionAuditPage,
});

const STATUS_TONE: Record<string, string> = {
  queued: "bg-muted text-muted-foreground",
  submitted: "bg-gold/15 text-gold",
  placed: "bg-gold/15 text-gold",
  filled: "bg-success/15 text-success",
  closed: "bg-success/15 text-success",
  failed: "bg-destructive/15 text-destructive",
  cancelled: "bg-muted text-muted-foreground",
};

function ExecutionAuditPage() {
  const rows = useRealtimeRows<AuditRow>("execution_audit", { col: "created_at" }, 500);
  const [range, setRange] = useState<RangeKey>("7d");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const from = rangeCutoff(range);
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (from && new Date(r.created_at).getTime() < from) return false;
      if (!q) return true;
      return [r.sig8, r.channel_name, r.symbol, r.broker_login, r.status, r.outcome]
        .some((v) => (v ?? "").toString().toLowerCase().includes(q));
    });
  }, [rows, range, query]);

  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <div className="flex size-10 items-center justify-center rounded-lg bg-gold/10 text-gold ring-1 ring-gold/20"><ClipboardList className="size-5" /></div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Execution Audit</h1>
            <p className="mt-0.5 text-sm text-muted-foreground">Every trade attempt: parsed signal, order and position IDs, SL/TP and final outcome.</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <RangeTabs value={range} onChange={setRange} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search channel, symbol, ticket…"
            className="h-9 w-56 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <span className="text-xs text-muted-foreground">{filtered.length} attempts</span>
        </div>

        {filtered.length === 0 ? (
          <div className="surface-card p-10 text-center text-sm text-muted-foreground">No execution records in this range yet.</div>
        ) : (
          <div className="space-y-2">
            {filtered.map((r) => (
              <article key={r.id} className="surface-card p-3 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`rounded px-1.5 py-0.5 text-[10px] uppercase ${STATUS_TONE[r.status] ?? "bg-muted text-muted-foreground"}`}>{r.outcome ?? r.status}</span>
                  <span className="font-semibold">{r.symbol ?? "—"}</span>
                  <span className={r.direction === "SELL" ? "text-destructive" : "text-success"}>{r.direction ?? "—"}</span>
                  <span className="text-muted-foreground">{r.channel_name ?? "unknown channel"}</span>
                  {r.broker_login && <span className="rounded bg-muted px-1.5 py-0.5 text-[10px]">#{r.broker_login}</span>}
                  <span className="ml-auto text-muted-foreground">{new Date(r.created_at).toLocaleString()}</span>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 sm:grid-cols-4">
                  <Cell label="Entry" value={(r.requested_entry ?? []).join(" / ") || "market"} />
                  <Cell label="SL" value={r.sl != null ? String(r.sl) : "—"} />
                  <Cell label="TPs" value={(r.tps ?? []).join(" / ") || "—"} />
                  <Cell label="Lot" value={r.lot_size != null ? String(r.lot_size) : "—"} />
                  <Cell label="Mode" value={`${r.trading_mode ?? "—"} · ${r.execution_mode ?? "—"}`} />
                  <Cell label="Orders" value={(r.order_tickets ?? []).join(", ") || "—"} />
                  <Cell label="Positions" value={(r.position_tickets ?? []).join(", ") || "—"} />
                  <Cell label="P/L" value={r.pnl_usd != null ? `$${Number(r.pnl_usd).toFixed(2)}${r.pnl_pips != null ? ` (${Number(r.pnl_pips).toFixed(1)}p)` : ""}` : "—"} />
                </div>
                {r.error && <p className="mt-2 text-[11px] text-destructive">{r.error}</p>}
              </article>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className="truncate tabular">{value}</div>
    </div>
  );
}
