import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSingleton } from "@/lib/hooks";
import { ChannelPicker } from "@/components/ChannelPicker";
import type { Settings, Account, Channel } from "@/lib/types";
import { ArrowRight, ArrowLeft, ExternalLink, HelpCircle, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

const db = supabase as any;

export const Route = createFileRoute("/setup")({
  head: () => ({ meta: [{ title: "Setup — GoldCopier Pro" }, { name: "description", content: "Connect Telegram and MetaTrader 5 in under 10 minutes." }] }),
  component: SetupWizard,
});

const STEPS = ["Welcome", "Telegram", "Channels", "MT5", "Preferences", "Test"] as const;

function SetupWizard() {
  const settings = useSingleton<Settings>("settings", {} as Settings);
  const [step, setStep] = useState(0);
  const navigate = useNavigate();

  const finish = async () => {
    await db.from("settings").update({ setup_completed: true, live_enabled: true }).eq("id", 1);
    toast.success("GoldCopier Pro is live!");
    navigate({ to: "/" });
  };

  return (
    <div className="min-h-dvh px-4 py-6 max-w-xl mx-auto">
      <ProgressBar step={step} />
      <div className="surface-card p-6 mt-5">
        {step === 0 && <Welcome onNext={() => setStep(1)} />}
        {step === 1 && <TelegramStep settings={settings} onNext={() => setStep(2)} onBack={() => setStep(0)} />}
        {step === 2 && <ChannelStep onNext={() => setStep(3)} onBack={() => setStep(1)} />}
        {step === 3 && <Mt5Step settings={settings} onNext={() => setStep(4)} onBack={() => setStep(2)} />}
        {step === 4 && <PreferencesStep settings={settings} onNext={() => setStep(5)} onBack={() => setStep(3)} />}
        {step === 5 && <TestStep onFinish={finish} onBack={() => setStep(4)} />}
      </div>
      <Link to="/" onClick={() => { if (typeof window !== "undefined") sessionStorage.setItem("skip_setup", "1"); }} className="block text-center text-xs text-muted-foreground mt-4">Skip setup for now</Link>
    </div>
  );
}

function ProgressBar({ step }: { step: number }) {
  const pct = ((step + 1) / STEPS.length) * 100;
  return (
    <div>
      <div className="flex items-center justify-between text-[11px] mb-2">
        <span className="font-display font-semibold text-gold text-base">Setup</span>
        <span className="text-muted-foreground tabular">Step {step + 1} of {STEPS.length} · {STEPS[step]}</span>
      </div>
      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
        <div className="h-full bg-gold-gradient transition-all duration-500" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function Btn({ children, variant = "primary", ...p }: any) {
  const styles = variant === "primary"
    ? "bg-gold-gradient text-primary-foreground font-semibold shadow-[var(--shadow-gold)]"
    : "border border-border bg-card text-foreground hover:bg-accent";
  return <button {...p} className={`px-4 py-2.5 rounded-lg text-sm transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed ${styles} ${p.className ?? ""}`}>{children}</button>;
}

function Welcome({ onNext }: { onNext: () => void }) {
  return (
    <div className="text-center space-y-4 py-4">
      <div className="text-5xl">👋</div>
      <h2 className="text-2xl font-display font-bold text-foreground">Welcome to GoldCopier Pro</h2>
      <p className="text-sm text-muted-foreground leading-relaxed">
        Let's get you set up in about 10 minutes. We'll connect your Telegram and MetaTrader 5 so your trades run automatically — even while you sleep.
      </p>
      <div className="text-left bg-muted/40 rounded-lg p-4 text-xs space-y-2 mt-6">
        <div className="flex gap-2"><span>📱</span><span>Connect Telegram (1 min)</span></div>
        <div className="flex gap-2"><span>📡</span><span>Pick the channels we should watch</span></div>
        <div className="flex gap-2"><span>💼</span><span>Connect your MT5 broker account</span></div>
        <div className="flex gap-2"><span>⚙️</span><span>Pick your trading style</span></div>
        <div className="flex gap-2"><span>🧪</span><span>Run a safe test signal</span></div>
      </div>
      <Btn onClick={onNext} className="w-full mt-4">Let's begin <ArrowRight className="inline size-4 ml-1" /></Btn>
    </div>
  );
}

function Tooltip({ children }: { children: React.ReactNode }) {
  return (
    <span className="group relative inline-block ml-1 align-middle">
      <HelpCircle className="size-3.5 text-muted-foreground inline" />
      <span className="absolute z-10 hidden group-hover:block group-focus:block bottom-full left-1/2 -translate-x-1/2 mb-1 w-56 text-[10px] bg-popover text-popover-foreground border border-border rounded-md p-2 shadow-lg">
        {children}
      </span>
    </span>
  );
}

function Field({ label, tooltip, ...p }: any) {
  return (
    <label className="block space-y-1.5">
      <div className="text-xs font-medium text-foreground/90">
        {label}
        {tooltip && <Tooltip>{tooltip}</Tooltip>}
      </div>
      <input {...p} className="w-full px-3 py-2.5 rounded-lg bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
    </label>
  );
}

function TelegramStep({ settings, onNext, onBack }: { settings: Settings; onNext: () => void; onBack: () => void }) {
  const [apiId, setApiId] = useState(settings.telegram_api_id ?? "");
  const [apiHash, setApiHash] = useState(settings.telegram_api_hash ?? "");
  const [phone, setPhone] = useState(settings.telegram_phone ?? "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setApiId(settings.telegram_api_id ?? "");
    setApiHash(settings.telegram_api_hash ?? "");
    setPhone(settings.telegram_phone ?? "");
  }, [settings.telegram_api_id, settings.telegram_api_hash, settings.telegram_phone]);

  const save = async () => {
    if (!apiId || !apiHash || !phone) return toast.error("Fill all three fields");
    setSaving(true);
    const nextTelegram = { telegram_api_id: apiId.trim(), telegram_api_hash: apiHash.trim(), telegram_phone: phone.trim() };
    const changed = nextTelegram.telegram_api_id !== (settings.telegram_api_id ?? "")
      || nextTelegram.telegram_api_hash !== (settings.telegram_api_hash ?? "")
      || nextTelegram.telegram_phone !== (settings.telegram_phone ?? "");
    const { error } = await db.from("settings").update({ ...nextTelegram, telegram_connected: false }).eq("id", 1);
    if (!error && changed) {
      await db.from("channels").delete().neq("id", "__keep_none__");
      await db.from("pending_actions").insert({ action: "fetch_channels" });
    }
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(changed ? "Telegram changed. The VPS listener will reconnect and refresh channels." : "Telegram credentials saved.");
    onNext();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-display font-bold">Connect Telegram</h2>
      <ol className="text-xs text-muted-foreground space-y-2 list-decimal list-inside">
        <li>Open <a href="https://my.telegram.org" target="_blank" rel="noreferrer" className="text-gold underline inline-flex items-center gap-1">my.telegram.org <ExternalLink className="size-3" /></a></li>
        <li>Log in with your Telegram phone number</li>
        <li>Tap <b className="text-foreground">API Development Tools</b></li>
        <li>Create an app — any name works (e.g. "GoldCopier")</li>
        <li>Copy your <b className="text-foreground">api_id</b> and <b className="text-foreground">api_hash</b> below</li>
      </ol>
      <div className="space-y-3 pt-2">
        <Field label="API ID" tooltip="A short number. Required to read your Telegram messages — stays only on your server." value={apiId} onChange={(e: any) => setApiId(e.target.value)} placeholder="12345678" />
        <Field label="API Hash" tooltip="Long alphanumeric string from my.telegram.org." value={apiHash} onChange={(e: any) => setApiHash(e.target.value)} placeholder="abcd1234ef…" />
        <Field label="Phone (with country code)" tooltip="The phone number on your Telegram account, e.g. +966501234567." value={phone} onChange={(e: any) => setPhone(e.target.value)} placeholder="+966…" />
      </div>
      <div className="rounded-lg bg-warning/10 border border-warning/30 p-3 text-[11px] text-foreground/80">
        <b className="text-warning">Important:</b> After saving, download the VPS ZIP from Settings, extract it, and double-click <code>1_START_HERE.bat</code>. Telegram will ask for an SMS code the first time — that's normal.
      </div>
      <div className="flex gap-2">
        <Btn variant="ghost" onClick={onBack}><ArrowLeft className="inline size-4" /> Back</Btn>
        <Btn onClick={save} disabled={saving} className="flex-1">{saving && <Loader2 className="inline size-4 mr-1 animate-spin" />}Save & Continue <ArrowRight className="inline size-4 ml-1" /></Btn>
      </div>
    </div>
  );
}

function ChannelStep({ onNext, onBack }: { onNext: () => void; onBack: () => void }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-display font-bold">Pick your signal channels</h2>
      <p className="text-xs text-muted-foreground">
        Select one or more Telegram channels we should monitor for XAUUSD signals. You can also
        change these later from the Settings page.
      </p>
      <ChannelPicker />
      <div className="flex gap-2 pt-2">
        <Btn variant="ghost" onClick={onBack}><ArrowLeft className="inline size-4" /></Btn>
        <Btn onClick={onNext} className="flex-1">Confirm channels <ArrowRight className="inline size-4 ml-1" /></Btn>
      </div>
    </div>
  );
}

type PrimaryBroker = { id: string; login: string; server: string; broker_name: string | null; has_password: boolean };

// The Setup MT5 step edits the PRIMARY broker account (oldest row in broker_accounts).
// broker_accounts is the single source of truth; settings.mt5_* is mirrored by a DB trigger.
async function loadPrimaryBroker(): Promise<PrimaryBroker | null> {
  const { data } = await db.from("broker_accounts").select("id,login,server,broker_name,password_encrypted").order("created_at", { ascending: true }).limit(1);
  const row = data?.[0];
  return row ? { id: row.id, login: row.login, server: row.server, broker_name: row.broker_name, has_password: !!row.password_encrypted } : null;
}

function Mt5Step({ settings, onNext, onBack }: { settings: Settings; onNext: () => void; onBack: () => void }) {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [server, setServer] = useState("");
  const [broker, setBroker] = useState("");
  const [primary, setPrimary] = useState<PrimaryBroker | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const account = useSingleton<Account>("account", {} as Account);

  useEffect(() => {
    loadPrimaryBroker().then((p) => {
      setPrimary(p);
      if (p) { setLogin(p.login); setServer(p.server); setBroker(p.broker_name ?? ""); }
      setLoading(false);
    });
  }, []);

  const save = async () => {
    const l = login.trim(), s = server.trim();
    if (!l || !s || (!password && !primary?.has_password)) return toast.error("Account number, password and server are required");
    if (!/^\d+$/.test(l)) return toast.error("Account number must contain digits only");
    setSaving(true);
    const values: Record<string, unknown> = { login: l, server: s, broker_name: broker.trim() || null, platform: "mt5" };
    if (password) values.password_encrypted = password;
    const res = primary
      ? await db.from("broker_accounts").update(values).eq("id", primary.id).select("id")
      : await db.from("broker_accounts").insert({ ...values, label: broker.trim() || "Main account", is_active: true, copy_enabled: true, health_status: "pending" }).select("id");
    if (res.error || !res.data?.length) {
      setSaving(false);
      return toast.error(res.error?.message ?? "Could not save the account. Please try again.");
    }
    await db.from("settings").update({ mt5_connected: false, mt5_account_type: null }).eq("id", 1);
    const fresh = await loadPrimaryBroker();
    setPrimary(fresh); setPassword(""); setSaving(false);
    toast.success("Saved. It now also appears on the Brokers page.");
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-display font-bold">Connect MetaTrader 5</h2>
      <p className="text-xs text-muted-foreground">This is your main account. Add more accounts later on the <Link to="/brokers" className="text-gold underline">Brokers</Link> page. The VPS scripts read these live from the app.</p>
      {primary && <div className="flex items-center gap-2 text-xs text-success"><CheckCircle2 className="size-4" /> Saved account #{primary.login} · {primary.server}</div>}
      <div className="space-y-3">
        <Field label="Account Number" tooltip="Your MT5 login number from the broker." value={login} onChange={(e: any) => setLogin(e.target.value)} placeholder="12345678" />
        <Field label="Password" tooltip="The trader password (not investor). Leave blank to keep the saved one." value={password} type="password" onChange={(e: any) => setPassword(e.target.value)} placeholder={primary?.has_password ? "•••••••• (saved — leave blank to keep)" : ""} />
        <Field label="Server" tooltip="Something like Exness-Real3 or ICMarkets-Live01 — check your broker email." value={server} onChange={(e: any) => setServer(e.target.value)} placeholder="Exness-Real3" />
        <Field label="Broker name (optional)" tooltip="Shown on the Brokers page." value={broker} onChange={(e: any) => setBroker(e.target.value)} placeholder="Exness" />
      </div>
      <Btn onClick={save} disabled={saving || loading} className="w-full">{saving && <Loader2 className="inline size-4 mr-1 animate-spin" />}Save credentials</Btn>

      <div className="surface-card p-4">
        <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Live status</div>
        {settings.mt5_connected && account.balance != null ? (
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-success text-sm font-medium"><CheckCircle2 className="size-4" /> Connected</div>
            <div className="text-2xl font-bold text-gold tabular">${account.balance?.toFixed(2)}</div>
            <div className="text-[11px] text-muted-foreground">#{account.login} · {account.server} · {account.account_type?.toUpperCase()}</div>
          </div>
        ) : (
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <Loader2 className="size-4 animate-spin" /> {primary ? "Saved. Start the VPS scripts — the bridge connects within ~15s." : "Waiting for account details…"}
          </div>
        )}
      </div>

      <div className="flex gap-2">
        <Btn variant="ghost" onClick={onBack}><ArrowLeft className="inline size-4" /></Btn>
        <Btn onClick={onNext} className="flex-1" disabled={!primary}>Continue <ArrowRight className="inline size-4 ml-1" /></Btn>
      </div>
    </div>
  );
}

function PreferencesStep({ settings, onNext, onBack }: { settings: Settings; onNext: () => void; onBack: () => void }) {
  const [lot, setLot] = useState(settings.lot_size ?? 0.01);
  const [count, setCount] = useState(settings.position_count ?? 2);
  const [mode, setMode] = useState<Settings["trading_mode"]>(settings.trading_mode ?? "quick_100");
  const [goal, setGoal] = useState(settings.weekly_goal_usd ?? 500);
  const [quickTgt, setQuickTgt] = useState<number>(settings.quick_pip_target ?? 100);
  const [hybridTgt, setHybridTgt] = useState<number>(settings.hybrid_pip_target ?? 100);
  const [scalpCount, setScalpCount] = useState<number>(settings.scalping_position_count ?? 10);
  const [scalpTgt, setScalpTgt] = useState<number>(settings.scalping_pip_target ?? 50);

  useEffect(() => {
    if (settings.lot_size != null) setLot(settings.lot_size);
    if (settings.position_count != null) setCount(settings.position_count);
    if (settings.trading_mode) setMode(settings.trading_mode);
    if (settings.weekly_goal_usd != null) setGoal(settings.weekly_goal_usd);
    if (settings.quick_pip_target != null) setQuickTgt(settings.quick_pip_target);
    if (settings.hybrid_pip_target != null) setHybridTgt(settings.hybrid_pip_target);
    if (settings.scalping_position_count != null) setScalpCount(settings.scalping_position_count);
    if (settings.scalping_pip_target != null) setScalpTgt(settings.scalping_pip_target);
  }, [settings]);

  const save = async () => {
    const patch: any = {
      lot_size: Number(lot),
      position_count: Math.max(1, Math.round(Number(count) || 1)),
      trading_mode: mode,
      weekly_goal_usd: Number(goal),
      quick_pip_target: Math.max(10, Math.round(Number(quickTgt) || 100)),
      hybrid_pip_target: Math.max(10, Math.round(Number(hybridTgt) || 100)),
      scalping_position_count: Math.max(1, Math.round(Number(scalpCount) || 10)),
      scalping_pip_target: Math.max(1, Math.round(Number(scalpTgt) || 50)),
    };
    const { error } = await db.from("settings").update(patch).eq("id", 1);
    if (error) return toast.error(error.message);
    onNext();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-display font-bold">How do you want to trade?</h2>
      <Field label="Lot size" tooltip="0.01 = micro lot. Safe to start with." type="number" step="0.01" min="0.01" value={lot} onChange={(e: any) => setLot(e.target.value)} />

      <div className="space-y-2">
        <div className="text-xs font-medium">Trading mode</div>
        <ModeOption active={mode === "quick_100"} onClick={() => setMode("quick_100")}
          title="Quick 100 Pips" body="Split positions 50/50 across dual entries. All share one TP based on the first entry ± target pips." />
        <ModeOption active={mode === "hybrid"} onClick={() => setMode("hybrid")}
          title="Hybrid" body="Half TP at target pips; other half rides channel TPs. First-half close cancels pendings and moves SL to breakeven ± 10 pips." />
        <ModeOption active={mode === "scalping"} onClick={() => setMode("scalping")}
          title="Scalping" body="N positions at first entry. Fixed pip TP, time-based exit, trailing SL. Channel TPs ignored." />
        <ModeOption active={mode === ("channel_follow" as any)} onClick={() => setMode("channel_follow" as any)}
          title="Channel Follow" body="Split 50/50. Half → channel TP1; half → channel final TP. SL from channel. BE +10 after first half hits." />
      </div>

      {mode === "scalping" ? (
        <>
          <Field label="Scalping positions (10 / 15 / 20)" type="number" min="1" step="1" value={scalpCount} onChange={(e: any) => setScalpCount(e.target.value)} />
          <Field label="Scalping pip target" type="number" min="1" step="5" value={scalpTgt} onChange={(e: any) => setScalpTgt(e.target.value)} />
        </>
      ) : (
        <>
          <Field label="Positions per signal" tooltip="Split evenly across the two entries. e.g. 6 = 3 on Entry 1, 3 on Entry 2." type="number" min="1" value={count} onChange={(e: any) => setCount(e.target.value)} />
          {mode === "quick_100" && (
            <Field label="Quick 100 pip target" type="number" min="10" step="10" value={quickTgt} onChange={(e: any) => setQuickTgt(e.target.value)} />
          )}
          {mode === "hybrid" && (
            <Field label="Hybrid pip trigger (first half TP)" type="number" min="10" step="10" value={hybridTgt} onChange={(e: any) => setHybridTgt(e.target.value)} />
          )}
        </>
      )}

      <Field label="Weekly profit goal (USD)" tooltip="Used for the progress bar on your dashboard." type="number" min="0" value={goal} onChange={(e: any) => setGoal(e.target.value)} />

      <div className="flex gap-2">
        <Btn variant="ghost" onClick={onBack}><ArrowLeft className="inline size-4" /></Btn>
        <Btn onClick={save} className="flex-1">Save & continue <ArrowRight className="inline size-4 ml-1" /></Btn>
      </div>
    </div>
  );
}

function ModeOption({ active, onClick, title, body }: any) {
  return (
    <button onClick={onClick} className={`w-full text-left p-3 rounded-lg border transition-all ${active ? "border-gold bg-gold/5 ring-gold" : "border-border bg-card hover:bg-accent"}`}>
      <div className="font-semibold text-sm">{title}</div>
      <div className="text-[11px] text-muted-foreground mt-0.5">{body}</div>
    </button>
  );
}

function TestStep({ onFinish, onBack }: { onFinish: () => void; onBack: () => void }) {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<Record<string, "ok" | "fail" | "pending">>({});
  const [errors, setErrors] = useState<Record<string, string>>({});

  const run = async () => {
    setRunning(true);
    setResults({ tg: "pending", parse: "pending", mt5: "pending", order: "pending" });
    setErrors({});

    // 1. Telegram online?
    const { data: hb } = await db.from("bridge_heartbeat").select("*");
    const tg = hb?.find((r: any) => r.service === "telegram");
    const tgOk = tg?.status === "online" && Date.now() - new Date(tg.last_seen).getTime() < 60_000;
    setResults((r) => ({ ...r, tg: tgOk ? "ok" : "fail" }));
    if (!tgOk) setErrors((e) => ({ ...e, tg: "Download the VPS ZIP, extract it, then run 1_START_HERE.bat." }));

    // 2. Parser via test
    try {
      const res = await fetch("/api/public/ingest-message", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: "BUY XAUUSD 2350 SL 2340 TP 2360 2370 2380", channel_id: "test", channel_name: "Test", dry_run: true }),
      });
      const j = await res.json();
      setResults((r) => ({ ...r, parse: j.parsed?.valid ? "ok" : "fail" }));
      if (!j.parsed?.valid) setErrors((e) => ({ ...e, parse: j.error || "Parser failed to recognize a clean signal" }));
    } catch (e: any) {
      setResults((r) => ({ ...r, parse: "fail" }));
      setErrors((er) => ({ ...er, parse: e.message }));
    }

    // 3. MT5 online?
    const mt = hb?.find((r: any) => r.service === "mt5");
    const mtOk = mt?.status === "online" && Date.now() - new Date(mt.last_seen).getTime() < 60_000;
    setResults((r) => ({ ...r, mt5: mtOk ? "ok" : "fail" }));
    if (!mtOk) setErrors((e) => ({ ...e, mt5: "Run 1_START_HERE.bat on your VPS. Make sure MT5 terminal is open and logged in." }));

    // 4. Order simulation — queue a dry-run open
    if (mtOk) {
      await db.from("pending_actions").insert({ action: "test_signal", payload: { dry_run: true } });
      setResults((r) => ({ ...r, order: "ok" }));
    } else {
      setResults((r) => ({ ...r, order: "fail" }));
    }
    setRunning(false);
  };

  const allOk = Object.values(results).length === 4 && Object.values(results).every((v) => v === "ok");

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-display font-bold">Test the full pipeline</h2>
      <p className="text-xs text-muted-foreground">No real money is risked — we just verify each piece talks to the next.</p>
      <Btn onClick={run} disabled={running} className="w-full">{running ? <><Loader2 className="inline size-4 mr-1 animate-spin" />Testing…</> : "Send Test Signal"}</Btn>

      <ul className="space-y-2">
        <Step ok={results.tg} label="Telegram listener online" err={errors.tg} />
        <Step ok={results.parse} label="AI signal parser working" err={errors.parse} />
        <Step ok={results.mt5} label="MT5 bridge connected" err={errors.mt5} />
        <Step ok={results.order} label="Order simulated (dry run)" err={errors.order} />
      </ul>

      <div className="flex gap-2">
        <Btn variant="ghost" onClick={onBack}><ArrowLeft className="inline size-4" /></Btn>
        <Btn onClick={onFinish} disabled={!allOk} className="flex-1">Go Live ✓</Btn>
      </div>
    </div>
  );
}

function Step({ ok, label, err }: { ok?: "ok" | "fail" | "pending"; label: string; err?: string }) {
  const icon = ok === "ok" ? <CheckCircle2 className="size-4 text-success" />
    : ok === "fail" ? <AlertCircle className="size-4 text-destructive" />
    : ok === "pending" ? <Loader2 className="size-4 text-muted-foreground animate-spin" />
    : <span className="size-4 rounded-full border border-border inline-block" />;
  return (
    <li className="surface-card p-3 text-sm flex items-start gap-3">
      <span className="mt-0.5">{icon}</span>
      <div className="flex-1">
        <div>{label}</div>
        {err && <div className="text-[11px] text-destructive mt-1">{err}</div>}
      </div>
    </li>
  );
}
