import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { OpenPositionsTile } from "@/components/OpenPositionsTile";
import { LivePriceTile } from "@/components/LivePriceTile";

import { useSingleton, useRealtimeRows } from "@/lib/hooks";
import { fmtUSD, fmtDateAST, pnlClass } from "@/lib/format";
import type { Account, Settings, Trade, Position } from "@/lib/types";
import {
  Wallet,
  TrendingUp,
  Activity,
  DollarSign,
  Radio,
  LineChart as LineChartIcon,
  Users,
  Copy,
  ArrowRight,
  Cpu,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RTooltip,
  ResponsiveContainer,
} from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — GoldCopier" },
      { name: "description", content: "Live KPIs, trade outcomes, per-channel profit, and copier engine feed." },
      { property: "og:title", content: "Dashboard — GoldCopier" },
      { property: "og:description", content: "Live KPIs, trade outcomes, per-channel profit, and copier engine feed." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const settings = useSingleton<Settings>("settings", {} as Settings);
  const account = useSingleton<Account>("account", {} as Account);
  const positions = useRealtimeRows<Position>("positions", { col: "opened_at" });
  const trades = useRealtimeRows<Trade>("trades", { col: "opened_at" }, 500);
  const engineEvents = useRealtimeRows<any>("copier_engine_events", { col: "created_at" }, 20);
  const logEvents = useRealtimeRows<any>("copier_log_events", { col: "created_at" }, 20);
  const brokers = useRealtimeRows<any>("broker_accounts", { col: "created_at" }, 50);
  const channels = useRealtimeRows<any>("channels", { col: "created_at" }, 50);

  const s = useMemo(() => computeStats(trades), [trades]);
  const outcomeSeries = useMemo(() => buildOutcomeSeries(trades), [trades]);
  const channelSeries = useMemo(() => buildChannelSeries(trades), [trades]);

  const kpis = [
    { label: "Balance", value: fmtUSD(account.balance), icon: Wallet, accent: "gold" as const },
    { label: "Today's Profit", value: fmtUSD(s.todayPnl, { sign: true }), icon: TrendingUp, cls: pnlClass(s.todayPnl) },
    { label: "Trades Today", value: String(s.todayCount), icon: Activity },
    { label: "Open P&L", value: fmtUSD(s.openPnl, { sign: true }), icon: DollarSign, cls: pnlClass(s.openPnl) },
    { label: "Active Channels", value: String(channels.filter((c) => c.is_selected).length), icon: Radio },
    { label: "Open Trades", value: String(positions.length), icon: LineChartIcon },
    { label: "Accounts Connected", value: `${brokers.filter((b) => b.is_active).length}/${brokers.length || 0}`, icon: Users },
    { label: "Trades Copied Today", value: String(s.todayCount), icon: Copy },
  ];

  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-display font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {settings.live_enabled ? "Live trading enabled" : "Live trading disabled"} · {fmtDateAST(new Date())}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {kpis.map((k) => (
            <KpiCard key={k.label} {...k} />
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,2fr)_minmax(280px,1fr)] gap-4">
          <OpenPositionsTile />
          <LivePriceTile instrument={settings.instrument} />
        </div>


        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ChartCard title="Trade outcomes" subtitle="Last 7 days">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={outcomeSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <RTooltip contentStyle={tooltipStyle} />
                <Bar dataKey="wins" stackId="a" fill="var(--color-success)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="losses" stackId="a" fill="var(--color-destructive)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Profit by channel" subtitle="Last 7 days">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={channelSeries} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis dataKey="name" type="category" stroke="var(--color-muted-foreground)" fontSize={11} width={90} />
                <RTooltip contentStyle={tooltipStyle} />
                <Bar dataKey="pnl" fill="var(--color-gold)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="surface-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold flex items-center gap-2">
                <Cpu className="size-4 text-gold" /> Copier Engine
              </h2>
              <Link to="/copier-engine" className="text-xs text-gold flex items-center gap-1">All <ArrowRight className="size-3" /></Link>
            </div>
            {engineEvents.length === 0 ? (
              <EmptyRow>Waiting for engine activity…</EmptyRow>
            ) : (
              <ul className="space-y-1.5 max-h-72 overflow-auto">
                {engineEvents.slice(0, 8).map((e: any) => (
                  <li key={e.id} className="flex items-center gap-2 text-xs">
                    <span className={`size-1.5 rounded-full ${statusDot(e.status)}`} />
                    <span className="text-muted-foreground shrink-0 w-14 tabular">{fmtTime(e.created_at)}</span>
                    <span className="font-medium">{e.type ?? "event"}</span>
                    <span className="text-muted-foreground truncate">{e.message}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="surface-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold">Copier Logs</h2>
              <Link to="/copier-logs" className="text-xs text-gold flex items-center gap-1">All <ArrowRight className="size-3" /></Link>
            </div>
            {logEvents.length === 0 ? (
              <EmptyRow>No log events yet.</EmptyRow>
            ) : (
              <div className="overflow-auto max-h-72">
                <table className="w-full text-xs">
                  <thead className="text-muted-foreground text-left">
                    <tr>
                      <th className="py-1 pr-2 font-medium">Status</th>
                      <th className="py-1 pr-2 font-medium">Symbol</th>
                      <th className="py-1 pr-2 font-medium">Reason</th>
                      <th className="py-1 pr-2 font-medium">Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logEvents.slice(0, 8).map((e: any) => (
                      <tr key={e.id} className="border-t border-border/60">
                        <td className="py-1.5 pr-2">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${statusPillCls(e.status)}`}>{e.status}</span>
                        </td>
                        <td className="py-1.5 pr-2 tabular">{e.symbol ?? "—"}</td>
                        <td className="py-1.5 pr-2 text-muted-foreground truncate max-w-[160px]">{e.reason ?? e.message ?? "—"}</td>
                        <td className="py-1.5 pr-2 text-muted-foreground tabular">{fmtTime(e.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <div className="surface-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold">Linked accounts</h2>
            <Link to="/brokers" className="text-xs text-gold flex items-center gap-1">Manage <ArrowRight className="size-3" /></Link>
          </div>
          {brokers.length === 0 ? (
            <EmptyRow>
              No accounts connected. <Link to="/brokers" className="text-gold">Add your first account</Link>
            </EmptyRow>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {brokers.slice(0, 6).map((b: any) => (
                <div key={b.id} className="rounded-lg border border-border/70 p-3 bg-background/40">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium truncate">{b.label ?? `#${b.login}`}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${b.is_active ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>
                      {b.is_active ? "Connected" : "Idle"}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted-foreground mt-1">
                    {b.platform?.toUpperCase() ?? "MT5"} · {b.broker_name ?? "—"}
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs tabular">
                    <span className="text-muted-foreground">Balance</span>
                    <span className="font-medium">{fmtUSD(b.current_balance ?? b.initial_balance)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

const tooltipStyle = {
  background: "var(--color-popover)",
  border: "1px solid var(--color-border)",
  borderRadius: 8,
  fontSize: 12,
  color: "var(--color-popover-foreground)",
};

function KpiCard({ label, value, icon: Icon, cls, accent }: { label: string; value: string; icon: any; cls?: string; accent?: "gold" }) {
  return (
    <div className="surface-card p-4 relative overflow-hidden">
      {accent === "gold" && <div className="absolute inset-0 bg-gold-gradient opacity-[0.06]" />}
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className={`font-display font-bold tabular text-2xl mt-1 ${cls ?? (accent === "gold" ? "text-gold" : "text-foreground")}`}>
            {value}
          </div>
        </div>
        <Icon className={`size-4 ${accent === "gold" ? "text-gold" : "text-muted-foreground"}`} />
      </div>
    </div>
  );
}

function ChartCard({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="surface-card p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-semibold">{title}</h2>
          {subtitle && <p className="text-[11px] text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

function EmptyRow({ children }: { children: React.ReactNode }) {
  return <div className="text-center text-sm text-muted-foreground py-8">{children}</div>;
}

function fmtTime(iso: string) {
  try {
    return new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  } catch { return "—"; }
}

function statusDot(s?: string | null) {
  switch ((s ?? "").toLowerCase()) {
    case "success":
    case "executed":
    case "ok": return "bg-success";
    case "failed":
    case "error": return "bg-destructive";
    case "skipped":
    case "pending": return "bg-warning";
    default: return "bg-muted-foreground";
  }
}
function statusPillCls(s?: string | null) {
  switch ((s ?? "").toLowerCase()) {
    case "executed":
    case "success": return "bg-success/15 text-success";
    case "failed":
    case "error": return "bg-destructive/15 text-destructive";
    case "skipped": return "bg-warning/15 text-warning";
    case "pending": return "bg-muted text-muted-foreground";
    default: return "bg-muted text-muted-foreground";
  }
}

function computeStats(trades: Trade[]) {
  const now = Date.now();
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  const closed = trades.filter((t) => t.status === "closed");
  const todayClosed = closed.filter((t) => t.closed_at && new Date(t.closed_at).getTime() >= dayStart.getTime());
  const todayCount = trades.filter((t) => new Date(t.opened_at).getTime() >= dayStart.getTime()).length;
  const todayPnl = todayClosed.reduce((sum, t) => sum + (t.pnl_usd ?? 0), 0);
  const openPnl = trades.filter((t) => t.status === "open").reduce((sum, t) => sum + (t.pnl_usd ?? 0), 0);
  return { todayPnl, openPnl, todayCount, now };
}

function buildOutcomeSeries(trades: Trade[]) {
  const days: { day: string; wins: number; losses: number }[] = [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today); d.setDate(d.getDate() - i);
    days.push({ day: d.toLocaleDateString("en-US", { weekday: "short" }), wins: 0, losses: 0 });
  }
  const closed = trades.filter((t) => t.status === "closed" && t.closed_at);
  closed.forEach((t) => {
    const ts = new Date(t.closed_at!).getTime();
    const diff = Math.floor((today.getTime() - new Date(new Date(ts).setHours(0, 0, 0, 0)).getTime()) / 86400000);
    if (diff < 0 || diff > 6) return;
    const idx = 6 - diff;
    if ((t.pnl_usd ?? 0) >= 0) days[idx].wins++;
    else days[idx].losses++;
  });
  return days;
}

function buildChannelSeries(trades: Trade[]) {
  const cutoff = Date.now() - 7 * 86400000;
  const map = new Map<string, number>();
  trades.forEach((t) => {
    if (t.status !== "closed" || !t.closed_at) return;
    if (new Date(t.closed_at).getTime() < cutoff) return;
    const name = t.channel_name ?? "Unknown";
    map.set(name, (map.get(name) ?? 0) + (t.pnl_usd ?? 0));
  });
  return Array.from(map.entries())
    .map(([name, pnl]) => ({ name: name.length > 14 ? name.slice(0, 14) + "…" : name, pnl: Number(pnl.toFixed(2)) }))
    .sort((a, b) => b.pnl - a.pnl)
    .slice(0, 6);
}
