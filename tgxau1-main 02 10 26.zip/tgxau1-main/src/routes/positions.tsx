import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useRealtimeRows } from "@/lib/hooks";
import { supabase } from "@/integrations/supabase/client";
import type { Position } from "@/lib/types";
import { fmtUSD, fmtPips, pnlClass, fmtDateAST } from "@/lib/format";
import { TrendingUp, TrendingDown, X, Edit3 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const db = supabase as any;

export const Route = createFileRoute("/positions")({
  head: () => ({ meta: [{ title: "Open Positions — GoldCopier Pro" }, { name: "description", content: "All open MT5 positions with live P&L, edit SL/TP, close manually." }] }),
  component: PositionsPage,
});

function PositionsPage() {
  const positions = useRealtimeRows<Position>("positions", { col: "opened_at" });
  const totalPnl = positions.reduce((s, p) => s + (p.pnl_usd ?? 0), 0);
  const totalPips = positions.reduce((s, p) => s + (p.pnl_pips ?? 0), 0);

  const closeAll = async () => {
    if (!confirm("Close ALL open positions now?")) return;
    // Emergency close reaches every connected account's bridge.
    const { data: accs } = await db.from("broker_accounts").select("id").eq("is_active", true);
    const rows = (accs ?? []).length
      ? accs.map((a: any) => ({ action: "close_all", payload: { broker_account_id: a.id }, status: "pending" }))
      : [{ action: "close_all", payload: {}, status: "pending" }];
    await db.from("pending_actions").insert(rows);
    toast.success("Close-all queued — executing on VPS now");
  };


  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold">Positions</h1>
          {positions.length > 0 && (
            <button onClick={closeAll} className="text-xs px-3 py-1.5 rounded-md border border-destructive/40 text-destructive hover:bg-destructive/10">
              Close all
            </button>
          )}
        </div>

        {positions.length > 0 && (
          <div className="surface-card p-4 grid grid-cols-2 gap-4">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Open P&L</div>
              <div className={`text-2xl font-bold tabular ${pnlClass(totalPnl)}`}>{fmtUSD(totalPnl, { sign: true })}</div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Combined Pips</div>
              <div className={`text-2xl font-bold tabular ${pnlClass(totalPips)}`}>{fmtPips(totalPips)}</div>
            </div>
          </div>
        )}

        {positions.length === 0 ? (
          <div className="surface-card p-10 text-center text-sm text-muted-foreground">No open positions right now.</div>
        ) : (
          <div className="space-y-2">{positions.map((p) => <PositionCard key={p.mt5_ticket} p={p} />)}</div>
        )}
      </div>
    </AppShell>
  );
}

function PositionCard({ p }: { p: Position }) {
  const [editing, setEditing] = useState<"sl" | "tp" | null>(null);
  const [val, setVal] = useState("");
  const dirCls = p.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg";
  const Icon = p.direction === "BUY" ? TrendingUp : TrendingDown;

  const save = async () => {
    const n = parseFloat(val);
    if (isNaN(n)) return toast.error("Invalid number");
    await db.from("pending_actions").insert({ action: "modify", payload: { ticket: p.mt5_ticket, [editing!]: n }, status: "pending" });
    toast.success("Update queued — executing on VPS");
    setEditing(null); setVal("");
  };
  const close = async () => {
    if (!confirm(`Close ${p.direction} ${p.lot_size} @${p.entry_price}?`)) return;
    // Optimistically hide the row; bridge will sync truth within ~1s.
    await db.from("positions").delete().eq("mt5_ticket", p.mt5_ticket);
    await db.from("pending_actions").insert({ action: "close", payload: { ticket: p.mt5_ticket }, status: "pending" });
    toast.success("Closing now — SL/TP preserved");
  };


  return (
    <div className="surface-card p-4 space-y-3">
      <div className="flex items-center gap-3">
        <Icon className={`size-5 ${dirCls}`} />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={`font-semibold ${dirCls}`}>{p.direction}</span>
            <span className="text-sm tabular">@{p.entry_price.toFixed(2)}</span>
            <span className="text-[10px] text-muted-foreground">· {p.lot_size} lot</span>
          </div>
          <div className="text-[10px] text-muted-foreground">#{p.mt5_ticket} · {fmtDateAST(p.opened_at)}{p.channel_name ? ` · ${p.channel_name}` : ""}</div>
        </div>
        <div className={`text-right tabular ${pnlClass(p.pnl_usd)}`}>
          <div className="font-bold">{fmtUSD(p.pnl_usd, { sign: true })}</div>
          <div className="text-[10px]">{fmtPips(p.pnl_pips)}</div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-xs">
        <Stat label="Current" value={p.current_price?.toFixed(2) ?? "—"} />
        <EditableStat label="SL" value={p.sl?.toFixed(2) ?? "—"} editing={editing === "sl"} val={val} setVal={setVal}
          onEdit={() => { setEditing("sl"); setVal(p.sl?.toString() ?? ""); }} onCancel={() => setEditing(null)} onSave={save} />
        <EditableStat label="TP" value={p.tp?.toFixed(2) ?? "—"} editing={editing === "tp"} val={val} setVal={setVal}
          onEdit={() => { setEditing("tp"); setVal(p.tp?.toString() ?? ""); }} onCancel={() => setEditing(null)} onSave={save} />
      </div>

      <button onClick={close} className="w-full text-xs py-2 rounded-md border border-destructive/40 text-destructive hover:bg-destructive/10 flex items-center justify-center gap-1">
        <X className="size-3" /> Close Now
      </button>
    </div>
  );
}
function Stat({ label, value }: any) {
  return (
    <div className="rounded-md bg-muted/30 px-2 py-1.5">
      <div className="text-[9px] uppercase text-muted-foreground">{label}</div>
      <div className="tabular text-sm">{value}</div>
    </div>
  );
}
function EditableStat({ label, value, editing, val, setVal, onEdit, onCancel, onSave }: any) {
  return (
    <div className="rounded-md bg-muted/30 px-2 py-1.5 relative">
      <div className="text-[9px] uppercase text-muted-foreground flex items-center justify-between">
        <span>{label}</span>
        {!editing && <button onClick={onEdit}><Edit3 className="size-2.5 text-muted-foreground hover:text-gold" /></button>}
      </div>
      {editing ? (
        <div className="flex gap-1 items-center">
          <input autoFocus value={val} onChange={(e) => setVal(e.target.value)} className="w-full bg-transparent border-b border-gold text-sm tabular outline-none" />
          <button onClick={onSave} className="text-[10px] text-success">✓</button>
          <button onClick={onCancel} className="text-[10px] text-muted-foreground">✕</button>
        </div>
      ) : <div className="tabular text-sm">{value}</div>}
    </div>
  );
}
