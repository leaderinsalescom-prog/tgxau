import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { BarChart3 } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell } from "@/components/AppShell";
import { RangeTabs } from "@/components/RangeTabs";
import { useRealtimeRows } from "@/lib/hooks";
import { rangeCutoff, type Range } from "@/lib/range";
import { fmtPips, fmtUSD, pnlClass } from "@/lib/format";
import type { Trade } from "@/lib/types";

export const Route = createFileRoute("/performance")({
  head: () => ({ meta: [
    { title: "Performance — GoldCopier" },
    { name: "description", content: "Win rate, profit factor, drawdown and per-channel results for every closed trade." },
    { property: "og:title", content: "Performance — GoldCopier" },
    { property: "og:description", content: "Track win rate, profit factor, drawdown and per-channel results." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: PerformancePage,
});

function PerformancePage() {
  const trades = useRealtimeRows<Trade>("trades", { col: "closed_at" }, 1000);
  const [range, setRange] = useState<Range>("30d");

  const closed = useMemo(() => {
    const cut = rangeCutoff(range);
    return trades
      .filter((t) => t.status === "closed" && t.closed_at && new Date(t.closed_at).getTime() >= cut)
      .sort((a, b) => new Date(a.closed_at!).getTime() - new Date(b.closed_at!).getTime());
  }, [trades, range]);

  const k = useMemo(() => {
    let wins = 0, losses = 0, gross = 0, loss = 0, pips = 0, peak = 0, equity = 0, maxDD = 0;
    const curve: { t: string; pnl: number }[] = [];
    for (const t of closed) {
      const p = Number(t.pnl_usd ?? 0);
      pips += Number(t.pnl_pips ?? 0);
      if (p > 0) { wins += 1; gross += p; } else if (p < 0) { losses += 1; loss += Math.abs(p); }
      equity += p;
      peak = Math.max(peak, equity);
      maxDD = Math.max(maxDD, peak - equity);
      curve.push({ t: new Date(t.closed_at!).toLocaleDateString("en-GB", { day: "2-digit", month: "short" }), pnl: Number(equity.toFixed(2)) });
    }
    const decided = wins + losses;
    return {
      wins, losses, pips, net: equity, maxDD, curve,
      winRate: decided ? (wins / decided) * 100 : 0,
      profitFactor: loss > 0 ? gross / loss : gross > 0 ? Infinity : 0,
      avgWin: wins ? gross / wins : 0,
      avgLoss: losses ? loss / losses : 0,
    };
  }, [closed]);

  const byChannel = useMemo(() => {
    const m = new Map<string, { name: string; n: number; wins: number; pnl: number; pips: number }>();
    for (const t of closed) {
      const name = t.channel_name ?? "Manual";
      const row = m.get(name) ?? { name, n: 0, wins: 0, pnl: 0, pips: 0 };
      row.n += 1;
      if (Number(t.pnl_usd ?? 0) > 0) row.wins += 1;
      row.pnl += Number(t.pnl_usd ?? 0);
      row.pips += Number(t.pnl_pips ?? 0);
      m.set(name, row);
    }
    return [...m.values()].sort((a, b) => b.pnl - a.pnl);
  }, [closed]);

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20"><BarChart3 className="size-5" /></div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Performance</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Results from every closed trade, broken down by channel.</p>
          </div>
        </div>

        <RangeTabs value={range} onChange={setRange} />

        {closed.length === 0 ? (
          <div className="surface-card p-10 text-center text-sm text-muted-foreground">No closed trades in this period.</div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Kpi label="Net profit" value={fmtUSD(k.net, { sign: true })} cls={pnlClass(k.net)} />
              <Kpi label="Win rate" value={`${k.winRate.toFixed(1)}%`} sub={`${k.wins}W / ${k.losses}L`} />
              <Kpi label="Profit factor" value={k.profitFactor === Infinity ? "∞" : k.profitFactor.toFixed(2)} sub="Above 1.5 is healthy" />
              <Kpi label="Max drawdown" value={fmtUSD(-k.maxDD)} cls={k.maxDD > 0 ? "text-pnl-neg" : ""} sub="Largest peak-to-trough drop" />
            </div>

            <section className="surface-card p-4">
              <h2 className="text-sm font-semibold">Cumulative profit</h2>
              <div className="mt-3 h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={k.curve}>
                    <defs>
                      <linearGradient id="pnlFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--gold))" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="hsl(var(--gold))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="t" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} minTickGap={24} />
                    <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} width={48} />
                    <Tooltip formatter={(v: any) => fmtUSD(Number(v), { sign: true })} contentStyle={{ fontSize: 12 }} />
                    <Area type="monotone" dataKey="pnl" stroke="hsl(var(--gold))" strokeWidth={2} fill="url(#pnlFill)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </section>

            <div className="grid gap-3 sm:grid-cols-3">
              <Kpi label="Total pips" value={fmtPips(k.pips)} cls={pnlClass(k.pips)} />
              <Kpi label="Average win" value={fmtUSD(k.avgWin)} />
              <Kpi label="Average loss" value={fmtUSD(-k.avgLoss)} cls={k.avgLoss > 0 ? "text-pnl-neg" : ""} />
            </div>

            <section className="surface-card p-4 space-y-2">
              <h2 className="text-sm font-semibold">By channel</h2>
              <ul className="space-y-1.5">
                {byChannel.map((c) => (
                  <li key={c.name} className="flex flex-wrap items-center gap-2 rounded-md border border-border/70 p-2.5 text-xs">
                    <span className="min-w-0 flex-1 truncate font-medium">{c.name}</span>
                    <span className="text-muted-foreground">{c.n} trades</span>
                    <span className="text-muted-foreground">{((c.wins / c.n) * 100).toFixed(0)}% win</span>
                    <span className={`tabular ${pnlClass(c.pips)}`}>{fmtPips(c.pips)}</span>
                    <span className={`tabular font-semibold ${pnlClass(c.pnl)}`}>{fmtUSD(c.pnl, { sign: true })}</span>
                  </li>
                ))}
              </ul>
            </section>
          </>
        )}
      </div>
    </AppShell>
  );
}

function Kpi({ label, value, sub, cls }: { label: string; value: string; sub?: string; cls?: string }) {
  return (
    <div className="surface-card p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 text-xl font-bold tabular ${cls ?? ""}`}>{value}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}
