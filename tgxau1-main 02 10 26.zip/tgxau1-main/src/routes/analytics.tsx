import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useRealtimeRows } from "@/lib/hooks";
import type { Trade } from "@/lib/types";
import { fmtUSD, pnlClass } from "@/lib/format";
import { useMemo } from "react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, BarChart, Bar } from "recharts";

export const Route = createFileRoute("/analytics")({
  head: () => ({ meta: [{ title: "Analytics — GoldCopier Pro" }, { name: "description", content: "Equity curve, win/loss ratio, and best trading hours for XAUUSD." }] }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const trades = useRealtimeRows<Trade>("trades", { col: "opened_at", asc: true }, 1000);
  const closed = useMemo(() => trades.filter((t) => t.status === "closed" && t.closed_at), [trades]);

  const equity = useMemo(() => {
    let run = 0;
    return closed.map((t) => ({ x: new Date(t.closed_at!).getTime(), y: (run += t.pnl_usd ?? 0) }));
  }, [closed]);

  const wins = closed.filter((t) => (t.pnl_usd ?? 0) > 0).length;
  const losses = closed.filter((t) => (t.pnl_usd ?? 0) <= 0).length;
  const pieData = [{ name: "Wins", value: wins }, { name: "Losses", value: losses }];

  const calendar = useMemo(() => buildCalendar(closed), [closed]);
  const byHour = useMemo(() => {
    const buckets = Array.from({ length: 24 }, (_, h) => ({ hour: h, pnl: 0 }));
    closed.forEach((t) => { const h = new Date(t.opened_at).getUTCHours(); buckets[h].pnl += t.pnl_usd ?? 0; });
    return buckets;
  }, [closed]);

  const byMonth = useMemo(() => {
    const m = new Map<string, number>();
    closed.forEach((t) => {
      const k = (t.closed_at ?? t.opened_at).slice(0, 7);
      m.set(k, (m.get(k) ?? 0) + (t.pnl_usd ?? 0));
    });
    return Array.from(m, ([month, pnl]) => ({ month, pnl })).slice(-6);
  }, [closed]);

  return (
    <AppShell>
      <div className="space-y-4">
        <h1 className="text-2xl font-display font-bold">Analytics</h1>

        <Card title="Equity Curve">
          {equity.length < 2 ? <Empty /> : (
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={equity}>
                <XAxis dataKey="x" hide />
                <YAxis hide />
                <Tooltip contentStyle={tipStyle} labelFormatter={(v) => new Date(Number(v)).toLocaleDateString()} formatter={(v) => fmtUSD(Number(v))} />
                <Line type="monotone" dataKey="y" stroke="var(--color-gold)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card title="Win / Loss">
          {closed.length === 0 ? <Empty /> : (
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="50%" height={140}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" innerRadius={36} outerRadius={56} stroke="none">
                    <Cell fill="var(--color-success)" />
                    <Cell fill="var(--color-destructive)" />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="text-xs space-y-1">
                <div><span className="inline-block size-2.5 rounded-full bg-success mr-1" />{wins} wins</div>
                <div><span className="inline-block size-2.5 rounded-full bg-destructive mr-1" />{losses} losses</div>
                <div className="text-muted-foreground pt-1">{closed.length ? ((wins / closed.length) * 100).toFixed(0) : 0}% win rate</div>
              </div>
            </div>
          )}
        </Card>

        <Card title="Daily P&L (last 12 weeks)">
          {calendar.length === 0 ? <Empty /> : <CalendarHeatmap days={calendar} />}
        </Card>

        <Card title="Best Trading Hours (UTC)">
          {byHour.every((b) => b.pnl === 0) ? <Empty /> : (
            <ResponsiveContainer width="100%" height={140}>
              <BarChart data={byHour}>
                <XAxis dataKey="hour" tick={{ fontSize: 9, fill: "var(--color-muted-foreground)" }} />
                <YAxis hide />
                <Tooltip contentStyle={tipStyle} formatter={(v) => fmtUSD(Number(v))} />
                <Bar dataKey="pnl">
                  {byHour.map((b, i) => <Cell key={i} fill={b.pnl >= 0 ? "var(--color-success)" : "var(--color-destructive)"} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card title="Monthly P&L">
          {byMonth.length === 0 ? <Empty /> : (
            <div className="space-y-1.5">
              {byMonth.map((m) => (
                <div key={m.month} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground tabular">{m.month}</span>
                  <span className={`tabular font-semibold ${pnlClass(m.pnl)}`}>{fmtUSD(m.pnl, { sign: true })}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </AppShell>
  );
}

const tipStyle = { background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 11 };

function Card({ title, children }: any) {
  return (
    <section className="surface-card p-4">
      <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">{title}</h2>
      {children}
    </section>
  );
}
function Empty() {
  return <div className="text-center text-xs text-muted-foreground py-6">Not enough data yet</div>;
}

function buildCalendar(trades: Trade[]) {
  const map = new Map<string, number>();
  trades.forEach((t) => {
    const d = (t.closed_at ?? t.opened_at).slice(0, 10);
    map.set(d, (map.get(d) ?? 0) + (t.pnl_usd ?? 0));
  });
  if (map.size === 0) return [];
  const today = new Date();
  const days: { date: string; pnl: number }[] = [];
  for (let i = 83; i >= 0; i--) {
    const d = new Date(today); d.setDate(today.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    days.push({ date: key, pnl: map.get(key) ?? 0 });
  }
  return days;
}

function CalendarHeatmap({ days }: { days: { date: string; pnl: number }[] }) {
  const max = Math.max(...days.map((d) => Math.abs(d.pnl)), 1);
  return (
    <div className="grid grid-cols-12 gap-1">
      {days.map((d) => {
        const intensity = Math.abs(d.pnl) / max;
        const bg = d.pnl === 0 ? "var(--color-muted)"
          : d.pnl > 0 ? `color-mix(in oklab, var(--color-success) ${20 + intensity * 80}%, transparent)`
          : `color-mix(in oklab, var(--color-destructive) ${20 + intensity * 80}%, transparent)`;
        return <div key={d.date} title={`${d.date}: ${fmtUSD(d.pnl, { sign: true })}`} style={{ background: bg }} className="aspect-square rounded-sm" />;
      })}
    </div>
  );
}
