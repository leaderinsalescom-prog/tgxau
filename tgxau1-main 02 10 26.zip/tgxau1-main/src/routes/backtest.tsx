import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FlaskConical, Loader2, Play } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useRealtimeRows } from "@/lib/hooks";
import { fmtDateAST, fmtPips, pnlClass } from "@/lib/format";
import type { Channel } from "@/lib/types";

const db = supabase as any;

type Run = {
  id: string; channel_ids: string[]; channel_labels: string[] | null;
  from_date: string; to_date: string; status: string; total_pips: number | null;
  win_rate: number | null; wins: number | null; losses: number | null;
  signal_count: number | null; error_message: string | null; created_at: string;
};
type RunSignal = {
  id: string; run_id: string; symbol: string; direction: string; entry: number | null;
  sl: number | null; outcome: string | null; pips: number | null; opened_at: string | null;
};

const isoDaysAgo = (d: number) => new Date(Date.now() - d * 86_400_000).toISOString().slice(0, 10);

export const Route = createFileRoute("/backtest")({
  head: () => ({ meta: [
    { title: "Backtest — GoldCopier" },
    { name: "description", content: "Replay past signals from any channel over a date range and see win rate, pips and every trade outcome." },
    { property: "og:title", content: "Backtest — GoldCopier" },
    { property: "og:description", content: "Replay past channel signals and measure win rate and pips before going live." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: BacktestPage,
});

function BacktestPage() {
  const channels = useRealtimeRows<Channel>("channels", { col: "name", asc: true }, 200);
  const runs = useRealtimeRows<Run>("backtest_runs", { col: "created_at" }, 30);
  const [picked, setPicked] = useState<string[]>([]);
  const [from, setFrom] = useState(isoDaysAgo(30));
  const [to, setTo] = useState(isoDaysAgo(0));
  const [running, setRunning] = useState(false);
  const [openRun, setOpenRun] = useState<string | null>(null);

  const toggle = (id: string) => setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const run = async () => {
    if (picked.length === 0) return toast.error("Pick at least one channel");
    if (from > to) return toast.error("The start date must come before the end date");
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) return toast.error("Sign in first");
    setRunning(true);

    const labels = channels.filter((c) => picked.includes(c.id)).map((c) => c.name);
    const { data: created, error: runErr } = await db.from("backtest_runs").insert({
      user_id: auth.user.id, channel_ids: picked, channel_labels: labels,
      from_date: from, to_date: to, status: "running",
    }).select("id").single();
    if (runErr) { setRunning(false); return toast.error(runErr.message); }

    try {
      const fromTs = new Date(`${from}T00:00:00Z`).toISOString();
      const toTs = new Date(`${to}T23:59:59Z`).toISOString();
      const { data: signals, error: sErr } = await db.from("signals").select("*")
        .in("channel_id", picked).gte("created_at", fromTs).lte("created_at", toTs)
        .eq("valid", true).order("created_at", { ascending: true }).limit(1000);
      if (sErr) throw sErr;

      const ids = (signals ?? []).map((s: any) => s.id);
      const { data: trades } = ids.length
        ? await db.from("trades").select("signal_id,pnl_pips,status,close_reason,opened_at,closed_at,instrument").in("signal_id", ids)
        : { data: [] };

      const bySignal = new Map<string, any[]>();
      for (const t of trades ?? []) {
        const arr = bySignal.get(t.signal_id) ?? [];
        arr.push(t); bySignal.set(t.signal_id, arr);
      }

      let wins = 0, losses = 0, totalPips = 0;
      const rows = (signals ?? []).map((s: any) => {
        const ts = bySignal.get(s.id) ?? [];
        const closed = ts.filter((t) => t.status === "closed");
        const pips = closed.reduce((sum, t) => sum + Number(t.pnl_pips ?? 0), 0);
        let outcome: string;
        if (ts.length === 0) outcome = "not_taken";
        else if (closed.length === 0) outcome = "open";
        else if (pips > 0) { outcome = "win"; wins += 1; }
        else if (pips < 0) { outcome = "loss"; losses += 1; }
        else outcome = "breakeven";
        if (closed.length) totalPips += pips;
        return {
          run_id: created.id, user_id: auth.user!.id,
          symbol: ts[0]?.instrument ?? s.entry_type ?? "XAUUSD",
          direction: s.direction ?? "BUY",
          entry: s.entry?.[0] ?? null, sl: s.sl ?? null, tps: s.tp ?? null,
          outcome, pips: closed.length ? pips : null,
          opened_at: ts[0]?.opened_at ?? s.created_at,
          closed_at: closed[closed.length - 1]?.closed_at ?? null,
        };
      });

      if (rows.length) {
        for (let i = 0; i < rows.length; i += 200) {
          const { error } = await db.from("backtest_signals").insert(rows.slice(i, i + 200));
          if (error) throw error;
        }
      }

      const decided = wins + losses;
      await db.from("backtest_runs").update({
        status: "completed", signal_count: rows.length, wins, losses,
        total_pips: Number(totalPips.toFixed(1)),
        win_rate: decided ? Number(((wins / decided) * 100).toFixed(1)) : null,
        completed_at: new Date().toISOString(),
      }).eq("id", created.id);

      setOpenRun(created.id);
      toast.success(`Replayed ${rows.length} signals`);
    } catch (e: any) {
      await db.from("backtest_runs").update({ status: "failed", error_message: String(e?.message ?? e) }).eq("id", created.id);
      toast.error(String(e?.message ?? e));
    } finally {
      setRunning(false);
    }
  };

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center ring-1 ring-gold/20"><FlaskConical className="size-5" /></div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Backtest</h1>
            <p className="text-sm text-muted-foreground mt-0.5">Replay the signals a channel already sent and see how they would have finished.</p>
          </div>
        </div>

        <section className="surface-card p-4 space-y-4">
          <div>
            <h2 className="text-sm font-semibold">Channels</h2>
            {channels.length === 0 ? (
              <p className="mt-1 text-xs text-muted-foreground">No channels yet.</p>
            ) : (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {channels.map((c) => (
                  <button key={c.id} onClick={() => toggle(c.id)}
                    className={`rounded-full border px-3 py-1 text-[11px] ${picked.includes(c.id) ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground"}`}>
                    {c.name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="grid gap-3 sm:grid-cols-3 sm:items-end">
            <div className="space-y-1"><div className="text-xs font-medium">From</div><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
            <div className="space-y-1"><div className="text-xs font-medium">To</div><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
            <Button onClick={run} disabled={running}>{running ? <Loader2 className="animate-spin" /> : <Play />} Run replay</Button>
          </div>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-semibold">Past runs</h2>
          {runs.length === 0 ? (
            <div className="surface-card p-8 text-center text-sm text-muted-foreground">No runs yet.</div>
          ) : runs.map((r) => (
            <article key={r.id} className="surface-card p-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">{(r.channel_labels ?? []).join(", ") || `${r.channel_ids.length} channels`}</span>
                <span className={`rounded px-1.5 py-0.5 text-[10px] ${r.status === "completed" ? "bg-success/15 text-success" : r.status === "failed" ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>{r.status}</span>
                <span className="ml-auto text-[10px] text-muted-foreground">{r.from_date} → {r.to_date} · {fmtDateAST(r.created_at)}</span>
              </div>
              {r.error_message && <p className="mt-2 text-[11px] text-destructive">{r.error_message}</p>}
              <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs">
                <Metric label="Signals" value={String(r.signal_count ?? 0)} />
                <Metric label="Win rate" value={r.win_rate != null ? `${r.win_rate}%` : "—"} />
                <Metric label="Wins / losses" value={`${r.wins ?? 0} / ${r.losses ?? 0}`} />
                <Metric label="Total pips" value={fmtPips(r.total_pips)} cls={pnlClass(r.total_pips)} />
              </div>
              <button onClick={() => setOpenRun(openRun === r.id ? null : r.id)} className="mt-3 text-[11px] text-primary">
                {openRun === r.id ? "Hide signals" : "Show signals"}
              </button>
              {openRun === r.id && <RunSignals runId={r.id} />}
            </article>
          ))}
        </section>
      </div>
    </AppShell>
  );
}

function RunSignals({ runId }: { runId: string }) {
  const [rows, setRows] = useState<RunSignal[] | null>(null);
  if (rows === null) {
    db.from("backtest_signals").select("*").eq("run_id", runId).order("opened_at", { ascending: true }).limit(500)
      .then(({ data }: any) => setRows(data ?? []));
    return <div className="py-4 text-center"><Loader2 className="inline size-4 animate-spin text-muted-foreground" /></div>;
  }
  if (rows.length === 0) return <p className="mt-2 text-[11px] text-muted-foreground">No signals in this range.</p>;
  return (
    <ul className="mt-2 max-h-80 space-y-1 overflow-y-auto">
      {rows.map((s) => (
        <li key={s.id} className="flex items-center gap-2 rounded-md bg-muted/30 px-2 py-1.5 text-[11px]">
          <span className={s.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg"}>{s.direction}</span>
          <span className="tabular">{s.symbol}</span>
          {s.entry != null && <span className="text-muted-foreground tabular">@{s.entry}</span>}
          <span className="ml-auto rounded bg-background px-1.5 py-0.5 text-[10px] text-muted-foreground">{(s.outcome ?? "").replace(/_/g, " ")}</span>
          <span className={`tabular ${pnlClass(s.pips)}`}>{s.pips != null ? fmtPips(s.pips) : "—"}</span>
        </li>
      ))}
    </ul>
  );
}

function Metric({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div className="rounded-md bg-muted/30 px-2 py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`tabular text-sm font-semibold ${cls ?? ""}`}>{value}</div>
    </div>
  );
}
