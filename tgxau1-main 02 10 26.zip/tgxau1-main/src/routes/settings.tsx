import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { ChannelPicker } from "@/components/ChannelPicker";
import { supabase } from "@/integrations/supabase/client";
import { useBridgeStatus, useSingleton } from "@/lib/hooks";
import { useTheme } from "@/lib/theme";
import type { Settings, Account } from "@/lib/types";
import { Download, ExternalLink, Power, Loader2, CheckCircle2, AlertCircle, RefreshCw, Sun, Moon } from "lucide-react";
import { toast } from "sonner";



const db = supabase as any;

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — GoldCopier Pro" }, { name: "description", content: "Configure Telegram, MT5, trading mode, and download the VPS scripts." }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const settings = useSingleton<Settings>("settings", {} as Settings);
  const account = useSingleton<Account>("account", {} as Account);
  const { telegram: tgLive, mt5: mt5Live } = useBridgeStatus();
  const [saving, setSaving] = useState(false);
  const [lastError, setLastError] = useState<{ created_at: string; error: string | null; result: any } | null>(null);
  const [symbols, setSymbols] = useState<string[]>([]);
  const [refreshingSymbols, setRefreshingSymbols] = useState(false);

  useEffect(() => {
    const loadErr = async () => {
      const { data } = await db.from("pending_actions")
        .select("created_at,error,result")
        .eq("status", "failed").eq("action", "open")
        .order("created_at", { ascending: false }).limit(1);
      setLastError((data && data[0]) || null);
    };
    loadErr();
    const i = setInterval(loadErr, 8000);
    return () => clearInterval(i);
  }, []);

  useEffect(() => {
    const load = async () => {
      const { data } = await db.from("pending_actions")
        .select("result,status").eq("action", "fetch_symbols").eq("status", "done")
        .order("created_at", { ascending: false }).limit(1);
      const list = (data && data[0]?.result?.symbols) || [];
      if (Array.isArray(list) && list.length) setSymbols(list);
    };
    load();
  }, []);

  const refreshSymbols = async () => {
    setRefreshingSymbols(true);
    const { error } = await db.from("pending_actions").insert({ action: "fetch_symbols", payload: {} });
    if (error) { toast.error(error.message); setRefreshingSymbols(false); return; }
    toast.success("Asked the VPS bridge for the broker's symbol list…");
    const start = Date.now();
    const t = setInterval(async () => {
      const { data } = await db.from("pending_actions")
        .select("result,status,created_at").eq("action", "fetch_symbols")
        .order("created_at", { ascending: false }).limit(1);
      const row = data && data[0];
      if (row && row.status === "done" && Array.isArray(row.result?.symbols)) {
        setSymbols(row.result.symbols); setRefreshingSymbols(false); clearInterval(t);
      } else if (Date.now() - start > 30_000) {
        setRefreshingSymbols(false); clearInterval(t);
        toast.error("Bridge didn't respond. Make sure mt5_bridge.py is running on the VPS.");
      }
    }, 2000);
  };

  const patch = async (p: Partial<Settings>) => {
    setSaving(true);
    const { error } = await db.from("settings").update(p).eq("id", 1);
    setSaving(false);
    if (error) toast.error(error.message);
  };

  return (
    <AppShell>
      <div className="space-y-4">
        <h1 className="text-2xl font-display font-bold">Settings</h1>

        {/* Live toggle */}
        <div className="surface-card p-4 flex items-center justify-between">
          <div>
            <div className="font-semibold flex items-center gap-2"><Power className={`size-4 ${settings.live_enabled ? "text-success" : "text-muted-foreground"}`} />Live trading</div>
            <div className="text-[11px] text-muted-foreground">When OFF, signals are parsed and logged but no orders execute.</div>
          </div>
          <Toggle on={!!settings.live_enabled} onChange={(v) => patch({ live_enabled: v })} />
        </div>

        {/* Telegram */}
        <Section title="Telegram">
          <StatusRow on={tgLive} label={tgLive ? "Connected · listening" : "Not connected"} />
          <Link to="/setup" className="text-xs text-gold flex items-center gap-1 mt-2"><ExternalLink className="size-3" /> Open Telegram setup</Link>
        </Section>

        {/* Channels — synced with Setup wizard */}
        <Section title="Telegram Channels">
          <div className="text-[11px] text-muted-foreground">
            Select which channels the listener should watch. Changes apply instantly and stay in sync with the Setup wizard.
          </div>
          <ChannelPicker compact />
        </Section>

        {/* Appearance */}
        <Section title="Appearance">
          <ThemeSwitcher />
        </Section>

        {/* MT5 */}
        <Section title="MetaTrader 5">
          <StatusRow on={mt5Live} label={mt5Live ? `Connected · #${account.login ?? settings.mt5_login ?? ""}` : "Not connected"} />
          {(account.account_type || settings.mt5_account_type) && (
            <span className={`inline-block mt-2 text-[10px] px-2 py-0.5 rounded-full font-semibold ${(account.account_type || settings.mt5_account_type) === "live" ? "bg-success/15 text-success" : "bg-warning/15 text-warning"}`}>
              {(account.account_type || settings.mt5_account_type)!.toUpperCase()}
            </span>
          )}
          {account.balance != null && <div className="text-2xl font-bold text-gold tabular mt-2">${Number(account.balance).toFixed(2)}</div>}
          <Link to="/setup" className="text-xs text-gold flex items-center gap-1 mt-2"><ExternalLink className="size-3" /> Update MT5 details</Link>
        </Section>

        {/* Instrument */}
        <Section title="Instrument">
          <div className="text-[11px] text-muted-foreground mb-2">
            The symbol every signal will be opened on. Use your broker's exact name (Exness gold is usually <code>XAUUSDm</code>).
          </div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              defaultValue={settings.instrument ?? ""}
              placeholder="XAUUSDm"
              onBlur={(e) => { const v = e.target.value.trim(); if (v && v !== settings.instrument) patch({ instrument: v }); }}
              className="flex-1 px-2 py-1.5 rounded-md bg-input border border-border text-sm tabular focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <button
              onClick={refreshSymbols}
              disabled={refreshingSymbols}
              className="text-xs px-2 py-1.5 rounded-md border border-border bg-card hover:bg-accent flex items-center gap-1 disabled:opacity-50"
            >
              <RefreshCw className={`size-3 ${refreshingSymbols ? "animate-spin" : ""}`} /> Refresh
            </button>
          </div>
          {symbols.length > 0 && (
            <div className="mt-2">
              <div className="text-[10px] text-muted-foreground mb-1">Broker symbols (tap to select):</div>
              <div className="flex flex-wrap gap-1.5 max-h-40 overflow-auto">
                {symbols.map((sym) => (
                  <button
                    key={sym}
                    onClick={() => patch({ instrument: sym })}
                    className={`text-[10px] px-2 py-1 rounded-md border tabular ${settings.instrument === sym ? "border-gold bg-gold/15 text-gold" : "border-border bg-card hover:bg-accent"}`}
                  >{sym}</button>
                ))}
              </div>
            </div>
          )}
          {symbols.length === 0 && (
            <div className="text-[10px] text-muted-foreground mt-2">Tap <b>Refresh</b> to pull the live list of symbols available on your broker.</div>
          )}
        </Section>

        {/* Last execution issue */}
        {lastError && (
          <Section title="Last MT5 Execution Issue">
            <div className="text-[11px] text-muted-foreground">{new Date(lastError.created_at).toLocaleString()}</div>
            <div className="text-xs text-warning break-words">{lastError.error || "Unknown error"}</div>
            {lastError.result && (
              <pre className="text-[10px] text-foreground/70 bg-card border border-border rounded p-2 overflow-auto max-h-40">
{JSON.stringify(lastError.result, null, 2)}
              </pre>
            )}
            <div className="text-[10px] text-muted-foreground">
              If you see <code>symbol_not_found</code>, change the Instrument above (Exness gold is <code>XAUUSDm</code>). For <code>10030/Unsupported filling mode</code> or <code>10018 Market closed</code>, the bridge already retries automatically.
            </div>
          </Section>
        )}


        <Section title="Execution Mode">
          <div className="text-[11px] text-muted-foreground">
            How orders reach MT5 when a valid signal arrives.
          </div>
          <RadioRow checked={(settings.execution_mode ?? "limit") === "instant"} onClick={() => patch({ execution_mode: "instant" } as any)}
            title="Instant (market)" body="Executes immediately at the best available market price. Every position uses the signal's exact SL and TP." />
          <RadioRow checked={(settings.execution_mode ?? "limit") !== "instant"} onClick={() => patch({ execution_mode: "limit" } as any)}
            title="Limit orders" body="Places pending limit orders at the entry prices the moment the signal arrives — never fills at market. Every order uses the signal's exact SL and TP." />
        </Section>

        <Section title="Trading Mode">
          <RadioRow checked={settings.trading_mode === "quick_100"} onClick={() => patch({ trading_mode: "quick_100" })}
            title="Quick 100 Pips" body="Split dual entries 50/50 with the signal TP. Closes everything and cancels pendings once the group is the target pips in profit." />
          <RadioRow checked={settings.trading_mode === "hybrid"} onClick={() => patch({ trading_mode: "hybrid" })}
            title="Hybrid" body="All positions carry the signal TP. At the pip trigger, half is collected and the rest move to your break-even offset." />
          <RadioRow checked={settings.trading_mode === "scalping"} onClick={() => patch({ trading_mode: "scalping" })}
            title="Scalping" body="Open N positions at the first entry with the signal TP. Closes the group at the scalping pip target. Time-based exit + trailing SL." />
          <RadioRow checked={settings.trading_mode === "channel_follow"} onClick={() => patch({ trading_mode: "channel_follow" as any })}
            title="Channel Follow" body="Split 50/50 across entries with the signal's final TP. When price reaches TP1, half is collected and the rest move to your break-even offset." />
        </Section>

        <Section title="Position Management">
          <div className="text-[11px] text-muted-foreground">
            When half the positions are collected and where the stop moves afterwards.
          </div>
          <RadioRow checked={((settings as any).half_close_mode ?? "auto") === "auto"} onClick={() => patch({ half_close_mode: "auto" } as any)}
            title="Auto — follow the channel" body="Waits for the channel instruction (e.g. “COLLECT HALF SET BREAKEVEN — HOLD FOR TP”). Closes the first-entry positions, moves the rest to break-even and lets them run to TP." />
          <RadioRow checked={((settings as any).half_close_mode ?? "auto") === "manual"} onClick={() => patch({ half_close_mode: "manual" } as any)}
            title="Manual — at my pip target" body="Collects half automatically as soon as the signal is this many pips in profit, then moves the rest to break-even. Channel instructions are still honoured if they arrive first." />
          {((settings as any).half_close_mode ?? "auto") === "manual" && (
            <Inline label="Collect half at (pips profit)" value={(settings as any).half_close_pips ?? 40} step={5}
              onSave={(v) => patch({ half_close_pips: Math.max(1, Math.round(v)) } as any)} />
          )}
          <div className="flex items-center justify-between text-sm">
            <span>Move SL to break-even</span>
            <Toggle on={(settings as any).breakeven_enabled ?? true} onChange={(v) => patch({ breakeven_enabled: v } as any)} />
          </div>
          {((settings as any).breakeven_enabled ?? true) && (
            <Inline label="Break-even offset (pips in profit)" value={(settings as any).breakeven_offset_pips ?? 5} step={1}
              onSave={(v) => patch({ breakeven_offset_pips: Math.max(0, v) } as any)} />
          )}
        </Section>

        <Section title="Position Sizing">
          <Inline label="Lot size" value={settings.lot_size} step={0.01} onSave={(v) => patch({ lot_size: v })} />
          {settings.trading_mode === "scalping" ? (
            <>
              <Inline label="Scalping positions (10/15/20)" value={settings.scalping_position_count ?? 10} step={1} onSave={(v) => patch({ scalping_position_count: Math.max(1, Math.round(v)) })} />
              <Inline label="Scalping pip target" value={settings.scalping_pip_target ?? 50} step={5} onSave={(v) => patch({ scalping_pip_target: Math.max(1, v) })} />
              <Inline label="Time exit (minutes)" value={settings.scalping_time_exit_minutes ?? 10} step={1} onSave={(v) => patch({ scalping_time_exit_minutes: Math.max(0, Math.round(v)) } as any)} />
            </>
          ) : (
            <Inline label="Positions per signal" value={settings.position_count} step={1} onSave={(v) => patch({ position_count: Math.round(v) })} />
          )}
          {settings.trading_mode === "quick_100" && (
            <Inline label="Quick 100 pip target" value={(settings as any).quick_pip_target ?? 100} step={10} onSave={(v) => patch({ quick_pip_target: Math.max(10, Math.round(v)) } as any)} />
          )}
          {settings.trading_mode === "hybrid" && (
            <Inline label="Hybrid pip trigger (collect half)" value={settings.hybrid_pip_target ?? 100} step={10} onSave={(v) => patch({ hybrid_pip_target: Math.max(10, v) })} />
          )}
        </Section>

        <Section title="Layering">
          <div className="flex items-center justify-between gap-3 text-sm">
            <div>
              <div>Layering</div>
              <div className="text-[11px] text-muted-foreground">Splits your positions evenly across the signal's entry range to improve the average entry. BUY fills from the top down, SELL from the bottom up.</div>
            </div>
            <Toggle on={!!settings.layering_enabled} onChange={(v) => patch({ layering_enabled: v } as any)} />
          </div>
          {settings.layering_enabled && (
            <div className="text-[10px] text-muted-foreground">
              Uses your {settings.trading_mode === "scalping" ? "scalping positions" : "positions per signal"} and lot size — the total never changes. Signals with a single entry price trade as normal.
            </div>
          )}
        </Section>

        <Section title="Marginal Entry">
          <div className="flex items-center justify-between gap-3 text-sm">
            <div>
              <div>Marginal Entry</div>
              <div className="text-[11px] text-muted-foreground">Lets a trade go in when a fast market comes within this distance of the entry but doesn't quite touch it. Works with or without Layering.</div>
            </div>
            <Toggle on={!!settings.marginal_entry_enabled} onChange={(v) => patch({ marginal_entry_enabled: v } as any)} />
          </div>
          <div className={settings.marginal_entry_enabled ? "" : "pointer-events-none opacity-50"}>
            <Inline label="Marginal distance (pips)" value={settings.marginal_entry_pips ?? 5} step={1}
              onSave={(v) => patch({ marginal_entry_pips: Math.max(0, Math.min(500, v)) } as any)} />
          </div>
          <div className="text-[10px] text-muted-foreground">
            Instant: waits until price is within this distance of the entry, then buys/sells at market. Limit orders: each pending order is placed this much closer to the market — it always stays a limit order.
          </div>
        </Section>

        {settings.trading_mode === "scalping" && (
          <Section title="Scalping — Trailing Stop">
            <div className="flex items-center justify-between text-sm">
              <span>Enable trailing</span>
              <Toggle on={!!settings.scalping_trail_enabled} onChange={(v) => patch({ scalping_trail_enabled: v } as any)} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(["atr", "ema", "structure"] as const).map((s) => (
                <button key={s} onClick={() => patch({ scalping_trail_style: s } as any)}
                  className={`px-2 py-2 rounded-md border text-xs capitalize ${settings.scalping_trail_style === s ? "border-gold bg-gold/10 text-gold" : "border-border bg-card hover:bg-accent"}`}>{s}</button>
              ))}
            </div>
            {settings.scalping_trail_style === "ema" && (
              <Inline label="EMA period" value={settings.scalping_trail_ema_period ?? 21} step={1} onSave={(v) => patch({ scalping_trail_ema_period: Math.max(2, Math.round(v)) } as any)} />
            )}
            <Inline label="Aggressive trail trigger (× risk)" value={settings.scalping_trail_aggressive_multiplier ?? 3} step={0.5} onSave={(v) => patch({ scalping_trail_aggressive_multiplier: Math.max(1, v) } as any)} />
            <Inline label="Break-even offset (pips)" value={settings.scalping_trail_be_offset_pips ?? 10} step={1} onSave={(v) => patch({ scalping_trail_be_offset_pips: Math.max(0, v) } as any)} />
            <div className="text-[10px] text-muted-foreground">
              <b>Structure</b> (recommended) — trails to last confirmed swing. <b>ATR</b> — trails behind average pullback. <b>EMA</b> — trails at the moving-average line. First move is always to break-even after price moves 1× risk in your favour.
            </div>
          </Section>
        )}

        <Section title="Goals & Confidence">
          <Inline label="Weekly goal (USD)" value={settings.weekly_goal_usd} step={50} onSave={(v) => patch({ weekly_goal_usd: v })} />
          <Inline label="Min signal confidence (0-1)" value={settings.min_confidence} step={0.05} onSave={(v) => patch({ min_confidence: Math.max(0, Math.min(1, v)) })} />
        </Section>

        <Section title="Notifications">
          <div className="flex items-center justify-between">
            <span className="text-sm">Trade alerts</span>
            <Toggle on={!!settings.notifications_enabled} onChange={(v) => patch({ notifications_enabled: v })} />
          </div>
        </Section>

        <Section title="VPS Scripts">
          <p className="text-xs text-muted-foreground mb-2">
            Download the ZIP on your Windows VPS, extract it, then double-click <b>1_START_HERE.bat</b>. It installs the required Python libraries and opens Telegram + MT5 automatically.
          </p>
          <p className="text-[11px] text-muted-foreground mb-3">
            You do <b>not</b> need to edit any file — credentials, selected channels, and MT5 account changes are read live by the scripts.
          </p>
          <DownloadBtn href="/scripts/goldcopier-vps.zip" label="Download VPS ZIP — extract, then click 1_START_HERE.bat" featured />
          <div className="mt-3 rounded-md bg-success/10 border border-success/30 p-3 text-[11px] text-foreground/80">
            <b className="text-success">Updated — please re-download once:</b> the new ZIP starts one MT5 bridge per enabled account on the Brokers page and respects each account's copying switch. After this, account, password and ON/OFF changes apply live — no new ZIP needed (only re-run 1_START_HERE.bat after adding a new account).
          </div>
        </Section>

        {saving && <div className="text-xs text-muted-foreground text-center"><Loader2 className="size-3 inline animate-spin" /> Saving…</div>}
      </div>
    </AppShell>
  );
}

function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="grid grid-cols-2 gap-2">
      <button
        onClick={() => setTheme("dark")}
        className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm transition-all ${theme === "dark" ? "border-primary bg-primary/5 text-primary" : "border-border bg-card hover:bg-accent text-foreground"}`}
      >
        <Moon className="size-4" /> Dark
      </button>
      <button
        onClick={() => setTheme("light")}
        className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm transition-all ${theme === "light" ? "border-primary bg-primary/5 text-primary" : "border-border bg-card hover:bg-accent text-foreground"}`}
      >
        <Sun className="size-4" /> Light
      </button>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="surface-card p-4 space-y-3">
      <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h2>
      <div className="space-y-2">{children}</div>
    </section>
  );
}
function StatusRow({ on, label }: { on: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      {on ? <CheckCircle2 className="size-4 text-success" /> : <AlertCircle className="size-4 text-warning" />}
      <span>{label}</span>
    </div>
  );
}
function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} className={`relative w-11 h-6 rounded-full transition-colors ${on ? "bg-gold" : "bg-muted"}`}>
      <span className={`absolute top-0.5 size-5 rounded-full bg-background transition-transform ${on ? "translate-x-5" : "translate-x-0.5"}`} />
    </button>
  );
}
function RadioRow({ checked, onClick, title, body }: any) {
  return (
    <button onClick={onClick} className={`w-full text-left p-3 rounded-lg border transition-all ${checked ? "border-gold bg-gold/5" : "border-border bg-card hover:bg-accent"}`}>
      <div className="flex items-center gap-2">
        <span className={`size-4 rounded-full border-2 ${checked ? "border-gold" : "border-border"} flex items-center justify-center`}>
          {checked && <span className="size-2 rounded-full bg-gold" />}
        </span>
        <span className="font-medium text-sm">{title}</span>
      </div>
      <div className="text-[11px] text-muted-foreground mt-1 pl-6">{body}</div>
    </button>
  );
}
function Inline({ label, value, step, onSave }: { label: string; value: number; step: number; onSave: (v: number) => void }) {
  const [v, setV] = useState(String(value ?? ""));
  useEffect(() => { setV(String(value ?? "")); }, [value]);
  return (
    <label className="flex items-center justify-between gap-3 text-sm">
      <span className="flex-1">{label}</span>
      <input
        type="number" step={step} value={v}
        onChange={(e) => setV(e.target.value)}
        onBlur={() => { const n = parseFloat(v); if (!isNaN(n) && n !== value) onSave(n); }}
        className="w-28 px-2 py-1.5 rounded-md bg-input border border-border text-right tabular text-sm focus:outline-none focus:ring-1 focus:ring-ring"
      />
    </label>
  );
}
function DownloadBtn({ href, label, featured = false }: { href: string; label: string; featured?: boolean }) {
  return (
    <a href={href} download className={`flex items-center gap-2 rounded-md border transition-colors ${featured ? "p-3 border-gold bg-gold/10 text-sm hover:bg-gold/15" : "p-2.5 border-border bg-card text-xs hover:bg-accent"}`}>
      <Download className={`${featured ? "size-4" : "size-3.5"} text-gold shrink-0`} />
      <span className={`${featured ? "font-semibold" : "truncate font-mono"}`}>{label}</span>
    </a>
  );
}
