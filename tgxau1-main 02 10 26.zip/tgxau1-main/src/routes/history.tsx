import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { useRealtimeRows } from "@/lib/hooks";
import type { Trade } from "@/lib/types";
import { fmtUSD, fmtPips, pnlClass, fmtDateAST } from "@/lib/format";
import { useMemo, useState } from "react";
import { Download } from "lucide-react";

export const Route = createFileRoute("/history")({
  head: () => ({ meta: [{ title: "Trade History — GoldCopier Pro" }, { name: "description", content: "Filter your closed trades and export a PDF report." }] }),
  component: HistoryPage,
});

type Range = "today" | "7d" | "30d" | "90d" | "all";
const RANGE_LABELS: Record<Range, string> = {
  today: "Today",
  "7d": "7 Days",
  "30d": "30 Days",
  "90d": "90 Days",
  all: "All Time",
};

function HistoryPage() {
  const all = useRealtimeRows<Trade>("trades", { col: "opened_at" }, 1000);
  const [range, setRange] = useState<Range>("today");

  const filtered = useMemo(() => {
    if (range === "today") {
      const start = new Date(); start.setHours(0, 0, 0, 0);
      const cutoff = start.getTime();
      return all.filter((t) => {
        const ts = t.closed_at ? new Date(t.closed_at).getTime() : new Date(t.opened_at).getTime();
        return ts >= cutoff;
      });
    }
    const closed = all.filter((t) => t.status === "closed");
    if (range === "all") return closed;
    const days = range === "7d" ? 7 : range === "30d" ? 30 : 90;
    const cutoff = Date.now() - days * 86400_000;
    return closed.filter((t) => t.closed_at && new Date(t.closed_at).getTime() > cutoff);
  }, [all, range]);

  const totals = useMemo(() => {
    const pnl = filtered.reduce((s, t) => s + (t.pnl_usd ?? 0), 0);
    const pips = filtered.reduce((s, t) => s + (t.pnl_pips ?? 0), 0);
    const wins = filtered.filter((t) => (t.pnl_usd ?? 0) > 0).length;
    const open = filtered.filter((t) => t.status !== "closed").length;
    return { pnl, pips, wins, open, count: filtered.length, winRate: filtered.length ? (wins / filtered.length) * 100 : 0 };
  }, [filtered]);

  const channelBreakdown = useMemo(() => {
    if (range !== "today") return [];
    const byChannel = new Map<string, { count: number; pnl: number; pips: number; wins: number }>();
    for (const t of filtered) {
      const key = t.channel_name || "Unknown";
      const cur = byChannel.get(key) || { count: 0, pnl: 0, pips: 0, wins: 0 };
      cur.count += 1;
      cur.pnl += t.pnl_usd ?? 0;
      cur.pips += t.pnl_pips ?? 0;
      if ((t.pnl_usd ?? 0) > 0) cur.wins += 1;
      byChannel.set(key, cur);
    }
    return Array.from(byChannel.entries()).map(([name, v]) => ({ name, ...v })).sort((a, b) => b.pnl - a.pnl);
  }, [filtered, range]);

  const exportPdf = () => {
    const html = buildPdfHtml(filtered, range, totals);
    const w = window.open("", "_blank");
    if (!w) return;
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  };

  return (
    <AppShell>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-display font-bold">History</h1>
          <button onClick={exportPdf} disabled={!filtered.length} className="text-xs px-3 py-1.5 rounded-md bg-gold-gradient text-primary-foreground font-semibold disabled:opacity-50 flex items-center gap-1">
            <Download className="size-3" /> PDF
          </button>
        </div>

        <div className="flex gap-1.5 text-xs overflow-x-auto pb-1 -mx-1 px-1">
          {(Object.keys(RANGE_LABELS) as Range[]).map((r) => (
            <button key={r} onClick={() => setRange(r)}
              className={`shrink-0 px-3 py-1.5 rounded-full border ${range === r ? "border-gold bg-gold/10 text-gold" : "border-border text-muted-foreground"}`}>
              {RANGE_LABELS[r]}
            </button>
          ))}
        </div>

        {range === "today" && channelBreakdown.length > 0 && (
          <div className="surface-card p-4 space-y-2">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">By Channel — Today</div>
            {channelBreakdown.map((c) => (
              <div key={c.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-medium truncate max-w-[140px]">{c.name}</span>
                  <span className="text-muted-foreground tabular">{c.count}t · {c.wins}W</span>
                </div>
                <div className="flex items-center gap-2 tabular">
                  <span className={pnlClass(c.pips)}>{fmtPips(c.pips)}</span>
                  <span className={`font-semibold ${pnlClass(c.pnl)}`}>{fmtUSD(c.pnl, { sign: true })}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="surface-card p-4 grid grid-cols-2 gap-3 text-center">
          <div>
            <div className="text-[10px] uppercase text-muted-foreground">Net P&L</div>
            <div className={`text-xl font-bold tabular ${pnlClass(totals.pnl)}`}>{fmtUSD(totals.pnl, { sign: true })}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-muted-foreground">Net Pips</div>
            <div className={`text-xl font-bold tabular ${pnlClass(totals.pips)}`}>{fmtPips(totals.pips)}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-muted-foreground">Trades</div>
            <div className="text-xl font-bold tabular">{totals.count}</div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-muted-foreground">{range === "today" ? "Open" : "Win Rate"}</div>
            <div className="text-xl font-bold tabular">{range === "today" ? totals.open : `${totals.winRate.toFixed(0)}%`}</div>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="surface-card p-10 text-center text-sm text-muted-foreground">No trades in this range yet.</div>
        ) : (
          <div className="space-y-2">{filtered.map((t) => <TradeRow key={t.id} t={t} />)}</div>
        )}
      </div>
    </AppShell>
  );
}

function TradeRow({ t }: { t: Trade }) {
  const dirCls = t.direction === "BUY" ? "text-pnl-pos" : "text-pnl-neg";
  return (
    <div className="surface-card p-3 space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm">
          <span className={`font-semibold ${dirCls}`}>{t.direction}</span>
          <span className="tabular text-foreground/80">{t.instrument}</span>
          <span className="text-[10px] text-muted-foreground">{t.lot_size} lot</span>
        </div>
        <div className={`text-right tabular ${pnlClass(t.pnl_usd)}`}>
          <div className="font-bold text-sm">{fmtUSD(t.pnl_usd, { sign: true })}</div>
          <div className="text-[10px]">{fmtPips(t.pnl_pips)}</div>
        </div>
      </div>
      <div className="text-[11px] text-muted-foreground tabular flex items-center gap-3 flex-wrap">
        <span>Entry {t.entry_price.toFixed(2)} → Close {t.close_price?.toFixed(2) ?? "—"}</span>
        {t.close_reason && <span className="px-1.5 py-0.5 rounded bg-muted/50 text-[10px] font-medium">{t.close_reason}</span>}
        {t.channel_name && <span className="px-1.5 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-medium">{t.channel_name}</span>}
      </div>
      <div className="text-[10px] text-muted-foreground/70">{fmtDateAST(t.opened_at)} → {t.closed_at ? fmtDateAST(t.closed_at) : "—"}</div>
    </div>
  );
}

function buildPdfHtml(trades: Trade[], range: Range, totals: { pnl: number; pips: number; count: number; winRate: number }) {
  const rows = trades.map((t) => `
    <tr>
      <td>${t.direction}</td><td>${t.instrument}</td>
      <td class="r">${t.entry_price.toFixed(2)}</td><td class="r">${t.close_price?.toFixed(2) ?? "—"}</td>
      <td class="r">${t.lot_size}</td>
      <td class="r ${(t.pnl_usd ?? 0) >= 0 ? "pos" : "neg"}">${fmtUSD(t.pnl_usd, { sign: true })}</td>
      <td class="r ${(t.pnl_pips ?? 0) >= 0 ? "pos" : "neg"}">${fmtPips(t.pnl_pips)}</td>
      <td>${t.close_reason ?? "—"}</td>
      <td>${fmtDateAST(t.opened_at)}</td>
      <td>${t.closed_at ? fmtDateAST(t.closed_at) : "—"}</td>
    </tr>`).join("");
  return `<!doctype html><html><head><meta charset="utf-8"><title>GoldCopier Pro — Trade Report</title>
<style>
body { font-family: -apple-system, system-ui, sans-serif; margin: 24px; color: #111; }
h1 { color: #b8860b; margin: 0 0 4px; }
.brand { font-size: 12px; color: #666; margin-bottom: 16px; }
.summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 16px 0; }
.sb { border: 1px solid #ddd; border-radius: 6px; padding: 10px; }
.sb .l { font-size: 9px; text-transform: uppercase; color: #888; }
.sb .v { font-size: 16px; font-weight: 700; }
table { width: 100%; border-collapse: collapse; font-size: 10px; }
th, td { padding: 6px 8px; border-bottom: 1px solid #eee; text-align: left; }
th { background: #faf6e8; color: #555; font-weight: 600; }
.r { text-align: right; font-variant-numeric: tabular-nums; }
.pos { color: #138a3f; }
.neg { color: #c4324a; }
@media print { body { margin: 12mm; } }
</style></head><body>
<h1>GoldCopier Pro — Trade Report</h1>
<div class="brand">${RANGE_LABELS[range]} · Generated ${new Date().toLocaleString()}</div>
<div class="summary">
  <div class="sb"><div class="l">Net P&amp;L</div><div class="v ${totals.pnl >= 0 ? "pos" : "neg"}">${fmtUSD(totals.pnl, { sign: true })}</div></div>
  <div class="sb"><div class="l">Net Pips</div><div class="v ${totals.pips >= 0 ? "pos" : "neg"}">${fmtPips(totals.pips)}</div></div>
  <div class="sb"><div class="l">Trades</div><div class="v">${totals.count}</div></div>
  <div class="sb"><div class="l">Win Rate</div><div class="v">${totals.winRate.toFixed(0)}%</div></div>
</div>
<table>
<thead><tr><th>Dir</th><th>Pair</th><th class="r">Entry</th><th class="r">Close</th><th class="r">Lots</th><th class="r">P&amp;L</th><th class="r">Pips</th><th>Reason</th><th>Opened</th><th>Closed</th></tr></thead>
<tbody>${rows}</tbody></table>
</body></html>`;
}
