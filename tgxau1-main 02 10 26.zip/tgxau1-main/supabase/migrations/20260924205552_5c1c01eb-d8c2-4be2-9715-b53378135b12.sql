REVOKE EXECUTE ON FUNCTION public.sync_primary_broker_to_settings() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.enforce_broker_account_limit() FROM PUBLIC, anon, authenticated;