ALTER TABLE public.settings
  ADD COLUMN IF NOT EXISTS marginal_entry_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS marginal_entry_pips numeric NOT NULL DEFAULT 5;
UPDATE public.settings SET marginal_entry_enabled = layer_tolerance_enabled, marginal_entry_pips = layer_tolerance_pips WHERE id = 1;
CREATE INDEX IF NOT EXISTS idx_pending_actions_status_created ON public.pending_actions (status, created_at);