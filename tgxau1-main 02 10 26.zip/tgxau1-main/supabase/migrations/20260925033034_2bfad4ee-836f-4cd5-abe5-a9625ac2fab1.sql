DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['account','broker_accounts','channel_brokers','channel_broker_config','channels','settings','signals','trades','positions','bridge_heartbeat','market_prices','pending_actions','execution_audit','signal_events','copier_engine_events','copier_log_events','backtest_runs','account_stats_daily']
  LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename=t) THEN
      EXECUTE format('ALTER PUBLICATION supabase_realtime ADD TABLE public.%I', t);
    END IF;
  END LOOP;
END $$;