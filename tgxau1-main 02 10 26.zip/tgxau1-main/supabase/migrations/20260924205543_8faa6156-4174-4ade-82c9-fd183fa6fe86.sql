-- 1) Seed the single-row config tables the whole app depends on (they were empty after the remix,
--    so every "save" updated zero rows and silently lost the data).
INSERT INTO public.settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
INSERT INTO public.account (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- 2) The app is a single-operator dashboard with no sign-in; account tables must follow the same
--    access model as settings/channels, otherwise inserts were rejected.
ALTER TABLE public.broker_accounts ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.channel_brokers ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.channel_broker_config ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.channel_config_presets ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.broker_accounts ADD COLUMN IF NOT EXISTS terminal_path text;
ALTER TABLE public.broker_accounts ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;

DROP POLICY IF EXISTS "own broker_accounts" ON public.broker_accounts;
DROP POLICY IF EXISTS "own channel_brokers" ON public.channel_brokers;
DROP POLICY IF EXISTS "own channel_broker_config" ON public.channel_broker_config;
DROP POLICY IF EXISTS "own presets" ON public.channel_config_presets;
CREATE POLICY "app_all broker_accounts" ON public.broker_accounts FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "app_all channel_brokers" ON public.channel_brokers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "app_all channel_broker_config" ON public.channel_broker_config FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "app_all presets" ON public.channel_config_presets FOR ALL USING (true) WITH CHECK (true);

-- 3) Account limit counts all accounts (single operator).
CREATE OR REPLACE FUNCTION public.enforce_broker_account_limit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF (SELECT count(*) FROM public.broker_accounts) >= 5 THEN
    RAISE EXCEPTION 'Maximum of 5 broker accounts reached';
  END IF;
  RETURN NEW;
END; $$;

-- 4) broker_accounts is the single source of truth. settings.mt5_* is a derived mirror of the
--    primary (oldest) account, kept for the primary bridge/status bar.
CREATE OR REPLACE FUNCTION public.sync_primary_broker_to_settings()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE p record;
BEGIN
  SELECT login, password_encrypted, server INTO p
  FROM public.broker_accounts ORDER BY created_at ASC, id ASC LIMIT 1;
  IF FOUND THEN
    UPDATE public.settings SET mt5_login = p.login, mt5_password = p.password_encrypted, mt5_server = p.server
    WHERE id = 1 AND (mt5_login IS DISTINCT FROM p.login OR mt5_password IS DISTINCT FROM p.password_encrypted OR mt5_server IS DISTINCT FROM p.server);
  ELSE
    UPDATE public.settings SET mt5_login = NULL, mt5_password = NULL, mt5_server = NULL, mt5_connected = false WHERE id = 1;
  END IF;
  RETURN NULL;
END; $$;
DROP TRIGGER IF EXISTS trg_broker_primary_sync ON public.broker_accounts;
CREATE TRIGGER trg_broker_primary_sync AFTER INSERT OR UPDATE OF login, password_encrypted, server OR DELETE
ON public.broker_accounts FOR EACH STATEMENT EXECUTE FUNCTION public.sync_primary_broker_to_settings();