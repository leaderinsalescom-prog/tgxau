ALTER TABLE public.settings
  ADD COLUMN IF NOT EXISTS layering_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS layer_tolerance_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS layer_tolerance_pips numeric NOT NULL DEFAULT 5;

CREATE TABLE public.signal_layers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  signal_id uuid NOT NULL,
  sig8 text,
  account_key text NOT NULL,
  broker_account_id uuid,
  channel_name text,
  symbol text NOT NULL,
  direction text NOT NULL,
  entry_low numeric NOT NULL,
  entry_high numeric NOT NULL,
  layer_no integer NOT NULL,
  total_layers integer NOT NULL,
  layer_price numeric NOT NULL,
  lot_size numeric NOT NULL,
  filled_volume numeric,
  fill_price numeric,
  sl numeric,
  tp numeric,
  tolerance_pips numeric,
  execution_mode text NOT NULL,
  trading_mode text,
  order_ticket bigint,
  position_ticket bigint,
  status text NOT NULL DEFAULT 'planned',
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (signal_id, account_key, layer_no)
);
GRANT SELECT, INSERT, UPDATE ON public.signal_layers TO anon, authenticated;
GRANT ALL ON public.signal_layers TO service_role;
ALTER TABLE public.signal_layers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "app_read" ON public.signal_layers FOR SELECT USING (true);
CREATE POLICY "app_insert" ON public.signal_layers FOR INSERT WITH CHECK (true);
CREATE POLICY "app_update" ON public.signal_layers FOR UPDATE USING (true) WITH CHECK (true);
CREATE INDEX signal_layers_open_idx ON public.signal_layers (account_key, status);
CREATE TRIGGER trg_signal_layers_updated BEFORE UPDATE ON public.signal_layers
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();