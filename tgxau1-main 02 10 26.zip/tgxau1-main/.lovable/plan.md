## GoldCopier — TSCopier-Inspired Rebuild (Final Plan, 25 screenshots catalogued)

---

## Navigation (final)

Left drawer — **only these sections**:

- **General**: Dashboard, Brokers, Trades
- **Signals**: Channels, Backtest, Copier Engine, Copier Logs, Manage Signals, Performance
- **Trading Tools**: Market News, Economic Calendar

Membership and Help sections are **removed** per user request.

Top bar: hamburger, "Copier Running" status pill, search, language selector (EN default, no-op), theme toggle, notifications bell, user avatar chip. Brand "GoldCopier".

---

## Pages (final list)

### Dashboard (`/`)
- KPI grid: Balance, Today's Profit, Trades Today, Open PnL, Active Channels, Open Trades, Accounts Connected, Trades Copied Today.
- Charts: Trade Outcome bar (7d), Profit by channel horizontal bar (7d).
- Copier Engine live feed card + Copier Logs table.
- Linked Accounts footer.

### Brokers (`/brokers`)
- Header + Add account (opens Connect dialog), counter (X/5), search, broker filter.
- Account card: platform icon, label, Connected/Healthy/MT5/broker badges, Copy trades toggle, Configure, delete. Body: Login, Account Type, Server, Signal Channels, Balance, Equity.
- Pagination.

### Broker Detail (screenshot 21 — dashboard drawer view)
- Header: broker · login, refresh, close.
- Grid: Initial Balance, Current Balance, Current Equity, Total P/L, Profit Today, Win Rate, Max Drawdown, ROI, Closed Deals.
- **Connected signal channels** list with per-channel realized P/L and trade count (sorted best → worst).
- No open positions state.
- **Last signal trade** card: channel, symbol, signal total P/L, close time, "See all" link.

### Connect New Account dialog (screenshot 22–23)
- Title "Connect a new MT5 account" + Upload accounts + close.
- Platform toggle: MT5 / MT4.
- **Account 1** group: Account label (optional), MT login, Password, Broker server (searchable). Manual-entry note.
- + Add more (adds Account 2, Account 3…).
- Connect account primary + Cancel.

### Trades (`/trades`)
- Tabs All/Open/Closed with counts, Refresh, last-synced.
- Table: Symbol (#ticket), Direction, Broker, Entry, SL, TP, Lots, PnL, Date & Time, Status.
- Pagination + row → detail drawer.

### Channels (`/channels`)
- **Your Telegram channels** card: connected/copier-live badges, Collapse/Disconnect, search, channel rows with Added/Add chip.
- **Active channels** section: rows with on/off toggle, trash, expanded connected brokers chips + link-broker button.

### Backtest (`/backtest`)
- Form (channel chip picker, From/To, Pull button).
- Running/progress state.
- Results view (KPI row + paginated signal list).
- Detail modal (screenshot 18): outcome banner, Pips/R:R/Duration tiles, price replay chart, Play/1x/2x/4x, event timeline.
- History button top-right → past runs list.

### Copier Engine (`/copier-engine`)
- Tabs All/Successful/Skipped/Failed.
- Event rows with type, status chip, message, timestamp + channel chip.

### Copier Logs (`/copier-logs`)
- Tabs All/Executed/Skipped/Failed/Pending.
- Table: Status, Reason, Channel, Symbol, Message, Type, Time.

### Manage Signals (`/manage-signals`, screenshot 24)
- KPI grid: Signals today, Last 7 days, Last 30 days, All time.
- Filter row: All channels dropdown, From/To dates, All time preset, Reset filters button.
- Table: Channel (name + symbol), Signal (direction chip + Buy/Sell on SYMBOL · SL · TP), Status pill (CLOSED etc.), Time.

### Performance (`/performance`, screenshot 25)
- Header + period tabs (7 days / 30 days / 90 days / All time), Updated timestamp, Refresh.
- KPI cards: Realized P/L, Win rate (Won X · Lost Y), Profit factor, Avg ROI, Max drawdown.
- **Account growth (7 days)** line chart, per-account.
- **Daily outcomes** bar chart (Loss/Profit per day).
- **Deep dive** grid: Best day, Worst day, Highest equity, Lowest equity, Best trade, Worst trade.
- **Profit by signal channel** horizontal bar chart with hover card.
- **Symbol distribution** horizontal bar chart.
- **Account breakdown** table: Account, Broker, Equity, ROI, Win Rate, Max DD, Configure link.

### Configure Trading drawer (per broker × channel or "all channels")
- Header: broker · login · Demo/Live · Balance · channel name.
- Left channel list (search, Connected chips, + / edit / × icons).
- Right tabs: **Symbols / Instructions / Risk / Targets / Management / Filters** (all six from batches 1–2).
- Footer: Cancel · Apply preset · presets dropdown · Save as preset · Save. Unsaved-changes banner. Disclaimer.

### Trading Tools stubs (Market News, Economic Calendar)
- Simple placeholder pages with header + "Coming soon" empty state. No data yet.

---

## Data model (final)

New tables:
- `broker_accounts` (id, user_id, label, platform mt4/mt5, login, password_encrypted, server, broker_name, is_active, health_status, initial_balance, current_balance, current_equity, timestamps)
- `channel_brokers` (channel_id, broker_account_id) — many-to-many link
- `channel_broker_config` (channel_id, broker_account_id, symbol_prefix, symbol_suffix, symbols_allow[], symbols_avoid[], instruction_map jsonb, trade_style, risk_mode, fixed_lot, dynamic_percent, single_tp_target, use_signal_entry, tp_distribution jsonb, profit_targets jsonb, max_loss jsonb, override_sl, override_tps, be_trigger_kind, be_trigger_value, be_offset_pips, be_type, trailing_stop_enabled, reverse_signal, add_new_trade_existing, close_on_opposite_signal, rr_fallback_sl, rr_fallback_tp, pending_expiry_hours, order_comments_enabled, time_filter jsonb, days_filter jsonb, news_filter jsonb, timestamps)
- `channel_config_presets` (id, user_id, name, config jsonb)
- `copier_log_events` (id, user_id, status, reason, channel_id, symbol, message, type, created_at)
- `copier_engine_events` (id, user_id, type, status, message, channel_id, created_at)
- `backtest_runs` (id, user_id, channel_ids[], from_date, to_date, total_pips, win_rate, wins, losses, signal_count, created_at)
- `backtest_signals` (id, run_id, symbol, direction, entry, sl, tps[], outcome, pips, rr, duration_seconds, opened_at, closed_at, events jsonb)
- `manage_signals_view` (either denormalized table or view over `signals`)
- `account_stats_daily` (broker_account_id, date, realized_pnl, wins, losses, trades, equity_close) — feeds Performance

RLS: user-scoped via `auth.uid()`. Grants for `authenticated` + `service_role`.

---

## Bridge / EA responsibilities

- Multi-account routing (broker_accounts).
- Per-channel × broker config resolver from `channel_broker_config`.
- Instruction allow-map enforcement.
- TP distribution executor + override SL/TPs.
- BE engine (Pips/R:R/$ Profit/TP hit triggers) + Trailing stop.
- Signal-behavior: reverse, add-new, close-on-opposite.
- Pending order expiry sweep.
- Filters: time-of-day, weekday, news pause window.
- Daily stats snapshot writer → `account_stats_daily`.
- Emit `copier_engine_events` + `copier_log_events` in real time.

---

## Build order

1. **Migrations** — all tables above + grants + RLS + trigger to touch updated_at.
2. **Global shell** — new sidebar (only 3 sections), topbar, layout, theme.
3. **Dashboard** rebuild with KPI cards + charts + live cards.
4. **Brokers** page + Connect dialog + Broker detail drawer.
5. **Configure Trading drawer** — all 6 tabs, presets, unsaved-changes banner.
6. **Channels** rebuild (Telegram channels + active with per-broker config).
7. **Trades** (rename from history), **Manage Signals**, **Copier Engine**, **Copier Logs**.
8. **Backtest** list + detail modal + history.
9. **Performance** with all charts.
10. **Market News + Economic Calendar** stubs.
11. **Bridge (Python) + MQL5 EA** update pass for new config schema.
12. **Regression audit**: existing trading_mode column keeps working as a fallback preset while per-channel config is the primary path.

---

Ready to start with step 1 (migrations). Kicking off now.
